from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.main import bp
from app.models import Link, Team, Category, User, AppConfig
from app import db
from sqlalchemy import func, desc
import json

@bp.route('/')
def index():
    """Strona główna aplikacji"""
    if not current_user.is_authenticated:
        return redirect(url_for('auth.login'))
    
    # Get recent links
    recent_links = Link.query.filter_by(is_active=True).order_by(desc(Link.created_at)).limit(5).all()
    
    # Get user teams
    user_teams = []
    if current_user.is_authenticated:
        user_teams = current_user.teams
    
    # Get application statistics
    stats = {
        'links_count': Link.query.filter_by(is_active=True).count(),
        'categories_count': Category.query.filter_by(is_active=True).count(),
        'teams_count': Team.query.filter_by(is_active=True).count(),
        'assets_count': 0  # Default value
    }
    
    # Try to get assets count if the infrastructure module is available
    try:
        from app.models.infrastructure import Asset
        stats['assets_count'] = Asset.query.filter_by(status='ACTIVE').count()
    except (ImportError, AttributeError):
        pass  # Assets table not available
    
    return render_template('index.html', 
                          title='Dashboard',
                          recent_links=recent_links,
                          user_teams=user_teams,
                          stats=stats)

@bp.route('/search')
@login_required
def search():
    """Wyszukiwarka globalna"""
    query = request.args.get('q', '')
    if not query or len(query) < 3:
        flash('Zapytanie wyszukiwania musi mieć co najmniej 3 znaki.', 'warning')
        return redirect(url_for('main.index'))
    
    # Search in links
    links = Link.query.filter(
        Link.is_active == True,
        (Link.title.ilike(f'%{query}%') | 
         Link.description.ilike(f'%{query}%') |
         Link.url.ilike(f'%{query}%'))
    ).all()
    
    # Search in categories
    categories = Category.query.filter(
        Category.is_active == True,
        (Category.name.ilike(f'%{query}%') | 
         Category.description.ilike(f'%{query}%'))
    ).all()
    
    # Search in teams
    teams = Team.query.filter(
        Team.is_active == True,
        (Team.name.ilike(f'%{query}%') | 
         Team.description.ilike(f'%{query}%'))
    ).all()
    
    # Try to search in assets if available
    assets = []
    try:
        from app.models.infrastructure import Asset
        assets = Asset.query.filter(
            Asset.name.ilike(f'%{query}%') | 
            Asset.description.ilike(f'%{query}%')
        ).all()
    except (ImportError, AttributeError):
        pass  # Assets table not available
    
    return render_template('main/search_results.html',
                          title=f'Wyniki wyszukiwania: {query}',
                          query=query,
                          links=links,
                          categories=categories,
                          teams=teams,
                          assets=assets)

@bp.route('/about')
def about():
    """Strona o aplikacji"""
    app_version = AppConfig.get_value('APP_VERSION', '1.0.0')
    return render_template('main/about.html', title='O aplikacji', app_version=app_version)

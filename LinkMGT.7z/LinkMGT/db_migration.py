"""
Skrypt do dodania brakujących kolumn w bazie danych.
Uruchom z wiersza poleceń: python db_migration.py
"""
from flask import Flask
from sqlalchemy import create_engine, text, MetaData, Table, Column, Integer, ForeignKey, Boolean
import os
from dotenv import load_dotenv

def add_owner_team_id_column():
    """Dodaje kolumnę owner_team_id do tabeli links jeśli nie istnieje"""
    load_dotenv()
    
    # Pobierz connection string z pliku .env lub użyj domyślnego
    db_url = os.environ.get('DATABASE_URL', 'sqlite:///app.db')
    
    # Utwórz silnik
    engine = create_engine(db_url)
    
    try:
        # Sprawdź czy kolumna istnieje
        with engine.connect() as conn:
            meta = MetaData()
            meta.reflect(bind=engine)
            
            if 'links' in meta.tables:
                links_table = meta.tables['links']
                
                if 'owner_team_id' not in links_table.columns:
                    print("Kolumna 'owner_team_id' nie istnieje w tabeli 'links'. Dodaję...")
                    
                    # Dodaj kolumnę w bazie PostgreSQL
                    if db_url.startswith('postgresql'):
                        stmt = text("ALTER TABLE links ADD COLUMN owner_team_id INTEGER REFERENCES teams(id)")
                        conn.execute(stmt)
                    # Dodaj kolumnę w bazie SQLite
                    elif db_url.startswith('sqlite'):
                        stmt = text("ALTER TABLE links ADD COLUMN owner_team_id INTEGER REFERENCES teams(id)")
                        conn.execute(stmt)
                    # Dodaj kolumnę w bazie MySQL
                    elif db_url.startswith(('mysql', 'mariadb')):
                        stmt = text("ALTER TABLE links ADD COLUMN owner_team_id INTEGER, ADD FOREIGN KEY (owner_team_id) REFERENCES teams(id)")
                        conn.execute(stmt)
                    
                    conn.commit()
                    print("Kolumna 'owner_team_id' została dodana do tabeli 'links'.")
                else:
                    print("Kolumna 'owner_team_id' już istnieje w tabeli 'links'.")
            else:
                print("Tabela 'links' nie istnieje.")
                
            # Podobnie dla tabeli categories
            if 'categories' in meta.tables:
                categories_table = meta.tables['categories']
                
                if 'owner_team_id' not in categories_table.columns:
                    print("Kolumna 'owner_team_id' nie istnieje w tabeli 'categories'. Dodaję...")
                    
                    # Dodaj kolumnę w zależności od rodzaju bazy
                    if db_url.startswith('postgresql'):
                        stmt = text("ALTER TABLE categories ADD COLUMN owner_team_id INTEGER REFERENCES teams(id)")
                        conn.execute(stmt)
                    elif db_url.startswith('sqlite'):
                        stmt = text("ALTER TABLE categories ADD COLUMN owner_team_id INTEGER REFERENCES teams(id)")
                        conn.execute(stmt)
                    elif db_url.startswith(('mysql', 'mariadb')):
                        stmt = text("ALTER TABLE categories ADD COLUMN owner_team_id INTEGER, ADD FOREIGN KEY (owner_team_id) REFERENCES teams(id)")
                        conn.execute(stmt)
                    
                    conn.commit()
                    print("Kolumna 'owner_team_id' została dodana do tabeli 'categories'.")
                else:
                    print("Kolumna 'owner_team_id' już istnieje w tabeli 'categories'.")
            else:
                print("Tabela 'categories' nie istnieje.")
    
    except Exception as e:
        print(f"Wystąpił błąd: {str(e)}")

def add_global_admin_column():
    """Dodaje kolumnę is_global_admin do tabeli users jeśli nie istnieje"""
    load_dotenv()
    
    # Pobierz connection string z pliku .env lub użyj domyślnego
    db_url = os.environ.get('DATABASE_URL', 'sqlite:///app.db')
    
    # Utwórz silnik
    engine = create_engine(db_url)
    
    try:
        # Sprawdź czy kolumna istnieje
        with engine.connect() as conn:
            meta = MetaData()
            meta.reflect(bind=engine)
            
            if 'users' in meta.tables:
                users_table = meta.tables['users']
                
                if 'is_global_admin' not in users_table.columns:
                    print("Kolumna 'is_global_admin' nie istnieje w tabeli 'users'. Dodaję...")
                    
                    # Dodaj kolumnę w bazie PostgreSQL
                    if db_url.startswith('postgresql'):
                        stmt = text("ALTER TABLE users ADD COLUMN is_global_admin BOOLEAN DEFAULT FALSE")
                        conn.execute(stmt)
                    # Dodaj kolumnę w bazie SQLite
                    elif db_url.startswith('sqlite'):
                        stmt = text("ALTER TABLE users ADD COLUMN is_global_admin BOOLEAN DEFAULT 0")
                        conn.execute(stmt)
                    # Dodaj kolumnę w bazie MySQL
                    elif db_url.startswith(('mysql', 'mariadb')):
                        stmt = text("ALTER TABLE users ADD COLUMN is_global_admin BOOLEAN DEFAULT FALSE")
                        conn.execute(stmt)
                    
                    conn.commit()
                    print("Kolumna 'is_global_admin' została dodana do tabeli 'users'.")
                else:
                    print("Kolumna 'is_global_admin' już istnieje w tabeli 'users'.")
            else:
                print("Tabela 'users' nie istnieje.")
    
    except Exception as e:
        print(f"Wystąpił błąd: {str(e)}")

if __name__ == "__main__":
    add_owner_team_id_column()
    add_global_admin_column()  # Make sure this function is called
    print("Skrypt zakończył działanie.")

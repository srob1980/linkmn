import os
import sys
from datetime import datetime, timedelta

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def initialize_application():
    """Complete initialization of the LinkMGT application"""
    
    try:
        print("🚀 Initializing LinkMGT application...")
        
        # Import the application
        from app import create_app, db
        
        # Create the application
        app = create_app()
        
        with app.app_context():
            print("📦 Creating database tables...")
            
            # Create all database tables
            db.create_all()
            
            # Import models
            from app.models.user import User
            from app.models.team import Team
            from app.models.link import Category, Link, Tag, LinkClick
            from app.models.config import AppConfig
            from app.models import user_team, link_category, link_tag, link_team
            
            # Try to import infrastructure models
            try:
                from app.models.infrastructure import (
                    Asset, AssetType, AssetStatus, Location, Vendor, 
                    License, SupportContract, MaintenanceLog
                )
                infrastructure_available = True
            except ImportError:
                infrastructure_available = False
                print("⚠️ Infrastructure models not available")
            
            # Check if admin user already exists
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                print("👤 Creating admin account...")
                admin = User(
                    username='admin',
                    email='admin@example.com',
                    first_name='Admin',
                    last_name='User',
                    is_admin=True,
                    is_active=True
                )
                admin.set_password('admin')
                db.session.add(admin)
                db.session.commit()
                print("✅ Admin user created: admin/admin")
            else:
                print("ℹ️ Admin account already exists")
            
            # Create initial configuration
            if AppConfig.query.count() == 0:
                print("⚙️ Creating initial configuration...")
                configs = [
                    ('APP_NAME', 'LinkMGT', 'Application name'),
                    ('APP_VERSION', '1.0.0', 'Application version'),
                    ('ENABLE_REGISTRATION', 'true', 'Allow new user registration'),
                    ('ALLOW_PASSWORD_RESET', 'true', 'Allow users to reset passwords')
                ]
                
                for key, value, description in configs:
                    config = AppConfig(key=key, value=value, description=description)
                    db.session.add(config)
                db.session.commit()
                print("✅ Initial configuration created")
            
            # Create sample categories if none exist
            if Category.query.count() == 0:
                print("📂 Creating sample categories...")
                categories = [
                    ('Development', 'Development tools and resources', '#007bff', 'fas fa-code'),
                    ('Documentation', 'Documentation and knowledge base', '#28a745', 'fas fa-book'),
                    ('Infrastructure', 'Infrastructure and server resources', '#dc3545', 'fas fa-server')
                ]
                
                for name, description, color, icon in categories:
                    category = Category(
                        name=name,
                        description=description,
                        color=color,
                        icon=icon,
                        is_active=True,
                        created_by=admin.id
                    )
                    db.session.add(category)
                db.session.commit()
                print("✅ Sample categories created")
            
            # Create sample teams if none exist
            if Team.query.count() == 0:
                print("👥 Creating sample teams...")
                teams = [
                    ('IT Department', 'Information Technology team', '#0066cc'),
                    ('Development', 'Software development team', '#339933'),
                    ('Operations', 'Operations team', '#ff9900')
                ]
                
                for name, description, color in teams:
                    team = Team(
                        name=name,
                        description=description,
                        color=color,
                        is_active=True,
                        created_by=admin.id
                    )
                    team.members.append(admin)
                    db.session.add(team)
                db.session.commit()
                print("✅ Sample teams created")
            
            # Create infrastructure data if enabled
            if infrastructure_available and AssetType.query.count() == 0:
                print("🖥️ Creating infrastructure data...")
                
                # Create asset types
                asset_types = [
                    ('Server', 'Server hardware', 'fas fa-server'),
                    ('Workstation', 'Desktop computers', 'fas fa-desktop'),
                    ('Laptop', 'Laptop computers', 'fas fa-laptop'),
                    ('Network', 'Network equipment', 'fas fa-network-wired'),
                    ('Printer', 'Printers and scanners', 'fas fa-print')
                ]
                
                for name, description, icon in asset_types:
                    asset_type = AssetType(
                        name=name,
                        description=description,
                        icon=icon
                    )
                    db.session.add(asset_type)
                
                # Create asset statuses
                asset_statuses = [
                    ('ACTIVE', 'Active asset', '#10b981'),
                    ('INACTIVE', 'Inactive asset', '#6b7280'),
                    ('MAINTENANCE', 'Under maintenance', '#f59e0b'),
                    ('DECOMMISSIONED', 'Decommissioned asset', '#ef4444')
                ]
                
                for name, description, color in asset_statuses:
                    status = AssetStatus(
                        name=name,
                        description=description,
                        color=color
                    )
                    db.session.add(status)
                
                # Create a default location
                location = Location(
                    name='Main Office',
                    address='123 Main Street',
                    city='New York',
                    country='USA',
                    postal_code='10001',
                    is_active=True
                )
                db.session.add(location)
                
                db.session.commit()
                print("✅ Infrastructure data created")
            
            print("✅ Application initialization complete!")
            print("\n📋 Login information:")
            print("Username: admin")
            print("Password: admin")
            print("\n🌐 Run the application:")
            print("python run.py")
            
            return True
            
    except Exception as e:
        print(f"❌ Error during initialization: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    initialize_application()

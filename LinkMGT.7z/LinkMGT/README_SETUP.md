# LinkMGT - Instrukcja uruchomienia

## Wymagania

- Python 3.8+
- PostgreSQL 12+ (lub SQLite dla rozwoju)
- pip

## Szybkie uruchomienie

1. **Klonuj projekt i przejdź do folderu:**
```bash
cd d:\Projekty\LinkMGT
```

2. **Utwórz i aktywuj środowisko wirtualne:**
```bash
python -m venv venv
venv\Scripts\activate  # Windows
```

3. **Zainstaluj zależności:**
```bash
pip install -r requirements.txt
```

4. **Skonfiguruj bazę danych (edytuj .env):**
```env
DATABASE_URL=postgresql://postgres:password@localhost/linkmgt
SECRET_KEY=your-secret-key-here
FLASK_DEBUG=True
```

5. **Zainicjalizuj aplikację:**
```bash
python initialize_complete.py
```

6. **Uruchom aplikację:**
```bash
python run.py
```

7. **Otwórz przeglądarkę:**
```
http://localhost:5000
```

## Logowanie

- **Administrator:** admin / admin123
- **Zmień hasło** po pierwszym logowaniu!

## Struktura aplikacji

- **Dashboard** - strona główna z statystykami
- **Linki** - zarządzanie linkami
- **Zespoły** - organizacja użytkowników
- **Administracja** - konfiguracja systemu

## Problemy?

Jeśli aplikacja nie działa:

1. Sprawdź czy PostgreSQL działa
2. Sprawdź konfigurację w pliku .env
3. Uruchom ponownie: `python initialize_complete.py`

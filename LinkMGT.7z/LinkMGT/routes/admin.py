# Dodaj do istniejącego pliku routingu dla admina

from flask import Blueprint, flash, redirect, render_template, url_for, request
from flask_login import login_required, current_user
from functools import wraps
from app.models import AppConfig
from app import db
from app.forms.admin import NetworkConfigForm

bp = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            flash('Wymagane uprawnienia administratora.', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

def get_config(key, default=None):
    """Pobierz konfigurację z bazy danych"""
    config = AppConfig.query.filter_by(key=key).first()
    return config.value if config else default

def save_config(key, value, description=None):
    """Zapisz konfigurację do bazy danych"""
    config = AppConfig.query.filter_by(key=key).first()
    if config:
        config.value = str(value)
        if description:
            config.description = description
    else:
        config = AppConfig(key=key, value=str(value), description=description)
        db.session.add(config)
    db.session.commit()

@bp.route('/network_config', methods=['GET', 'POST'])
@login_required
@admin_required
def network_config():
    form = NetworkConfigForm()
    
    if request.method == 'GET':
        # Załaduj obecne ustawienia
        form.http_port.data = int(get_config('HTTP_PORT', '5000'))
        form.https_enabled.data = get_config('HTTPS_ENABLED', 'False').lower() == 'true'
        form.https_port.data = int(get_config('HTTPS_PORT', '5443'))
        form.ssl_cert_path.data = get_config('SSL_CERT_PATH', 'certificate/cert.pem')
        form.ssl_key_path.data = get_config('SSL_KEY_PATH', 'certificate/key.pem')
    
    if form.validate_on_submit():
        # Zapisz ustawienia
        save_config('HTTP_PORT', form.http_port.data, 'Port HTTP')
        save_config('HTTPS_ENABLED', 'True' if form.https_enabled.data else 'False', 'Włącz HTTPS')
        save_config('HTTPS_PORT', form.https_port.data, 'Port HTTPS')
        save_config('SSL_CERT_PATH', form.ssl_cert_path.data, 'Ścieżka do certyfikatu SSL')
        save_config('SSL_KEY_PATH', form.ssl_key_path.data, 'Ścieżka do klucza SSL')
        
        flash('Ustawienia sieci zostały zapisane. Uruchom ponownie aplikację, aby zastosować zmiany.', 'success')
        return redirect(url_for('admin.network_config'))
    
    return render_template('admin/network_config.html', 
                          title='Konfiguracja sieci', 
                          form=form)
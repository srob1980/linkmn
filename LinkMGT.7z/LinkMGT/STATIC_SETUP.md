# LinkMGT Static Files Setup

This document explains how to set up the static files for the LinkMGT application.

## Required Static Files

The application requires the following static files:

1. **Bootstrap 5 CSS and JS**
   - `app/static/css/bootstrap.min.css`
   - `app/static/js/bootstrap.bundle.min.js`

2. **Font Awesome**
   - `app/static/css/fontawesome/all.min.css`
   - `app/static/css/fontawesome/webfonts/...` (various font files)

3. **Custom CSS and JS**
   - `app/static/css/styles.css` (custom styles for the application)
   - `app/static/js/scripts.js` (custom JavaScript functions)
   - `app/static/js/utilities.js` (utility JavaScript functions)

4. **Error Page Images**
   - `app/static/img/401.svg`
   - `app/static/img/403.svg`
   - `app/static/img/404.svg`
   - `app/static/img/500.svg`

## Automatic Setup

Run the provided setup script to automatically download and set up all required static files:

```bash
python setup_static.py
```

This script will:
1. Download Bootstrap 5 and extract the required files
2. Download Font Awesome and extract the required files
3. Create placeholder SVG images for error pages
4. Create the custom JavaScript file if it doesn't exist

## Manual Setup

If you prefer to set up the static files manually, follow these steps:

### 1. Bootstrap 5

Download Bootstrap 5 from the official website: https://getbootstrap.com/docs/5.3/getting-started/download/

Extract the following files:
- Copy `bootstrap.min.css` to `app/static/css/`
- Copy `bootstrap.bundle.min.js` to `app/static/js/`

### 2. Font Awesome

Download Font Awesome from: https://fontawesome.com/download

Extract the following files:
- Copy `all.min.css` to `app/static/css/fontawesome/`
- Copy all files from the `webfonts` directory to `app/static/css/fontawesome/webfonts/`

### 3. Create Custom Files

Create the custom CSS and JS files:
- Create `app/static/css/styles.css` with your custom styles
- Create `app/static/js/scripts.js` with your custom JavaScript functions
- Create `app/static/js/utilities.js` with utility JavaScript functions

## Checking Setup

After setting up the static files, start your Flask application and check the browser's developer tools to ensure all static files are being loaded correctly.

You should see successful requests for:
- `/static/css/bootstrap.min.css`
- `/static/css/fontawesome/all.min.css`
- `/static/css/styles.css`
- `/static/js/bootstrap.bundle.min.js`
- `/static/js/scripts.js`
- `/static/js/utilities.js`

If any of these files are missing, you'll see 404 errors in the browser's developer tools.

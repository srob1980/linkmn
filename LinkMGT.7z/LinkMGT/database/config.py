"""
Database configuration for different database systems
"""

import os
from urllib.parse import quote_plus

class DatabaseConfig:
    """Base database configuration"""
    
    # PostgreSQL configuration
    POSTGRESQL_CONFIG = {
        'driver': 'postgresql+psycopg2',
        'host': os.environ.get('POSTGRES_HOST', 'localhost'),
        'port': os.environ.get('POSTGRES_PORT', '5432'),
        'database': os.environ.get('POSTGRES_DB', 'linkmgt'),
        'username': os.environ.get('POSTGRES_USER', 'postgres'),
        'password': os.environ.get('POSTGRES_PASSWORD', 'postgres'),
        'options': {
            'sslmode': os.environ.get('POSTGRES_SSLMODE', 'prefer'),
            'connect_timeout': '30',
            'application_name': 'LinkMGT'
        }
    }
    
    # Oracle configuration
    ORACLE_CONFIG = {
        'driver': 'oracle+cx_oracle',
        'host': os.environ.get('ORACLE_HOST', 'localhost'),
        'port': os.environ.get('ORACLE_PORT', '1521'),
        'service_name': os.environ.get('ORACLE_SERVICE', 'XEPDB1'),
        'username': os.environ.get('ORACLE_USER', 'linkmgt'),
        'password': os.environ.get('ORACLE_PASSWORD', 'password'),
        'options': {
            'encoding': 'UTF-8',
            'nencoding': 'UTF-8'
        }
    }
    
    # MariaDB/MySQL configuration
    MARIADB_CONFIG = {
        'driver': 'mysql+pymysql',
        'host': os.environ.get('MARIADB_HOST', 'localhost'),
        'port': os.environ.get('MARIADB_PORT', '3306'),
        'database': os.environ.get('MARIADB_DB', 'linkmgt'),
        'username': os.environ.get('MARIADB_USER', 'root'),
        'password': os.environ.get('MARIADB_PASSWORD', 'password'),
        'options': {
            'charset': 'utf8mb4',
            'connect_timeout': '30',
            'autocommit': 'true'
        }
    }
    
    @classmethod
    def get_database_url(cls, db_type='postgresql'):
        """Generate database URL for SQLAlchemy"""
        
        if db_type.lower() == 'postgresql':
            config = cls.POSTGRESQL_CONFIG
            password = quote_plus(config['password'])
            url = f"{config['driver']}://{config['username']}:{password}@{config['host']}:{config['port']}/{config['database']}"
            
        elif db_type.lower() == 'oracle':
            config = cls.ORACLE_CONFIG
            password = quote_plus(config['password'])
            url = f"{config['driver']}://{config['username']}:{password}@{config['host']}:{config['port']}/{config['service_name']}"
            
        elif db_type.lower() in ['mariadb', 'mysql']:
            config = cls.MARIADB_CONFIG
            password = quote_plus(config['password'])
            url = f"{config['driver']}://{config['username']}:{password}@{config['host']}:{config['port']}/{config['database']}"
            options = '&'.join([f"{k}={v}" for k, v in config['options'].items()])
            url = f"{url}?{options}"
            
        else:
            raise ValueError(f"Unsupported database type: {db_type}")
        
        return url
    
    @classmethod
    def get_sqlalchemy_config(cls, db_type='postgresql'):
        """Get SQLAlchemy configuration"""
        
        base_config = {
            'SQLALCHEMY_DATABASE_URI': cls.get_database_url(db_type),
            'SQLALCHEMY_TRACK_MODIFICATIONS': False,
            'SQLALCHEMY_RECORD_QUERIES': True,
            'SQLALCHEMY_ENGINE_OPTIONS': {}
        }
        
        if db_type.lower() == 'postgresql':
            base_config['SQLALCHEMY_ENGINE_OPTIONS'].update({
                'pool_size': 10,
                'pool_timeout': 30,
                'pool_recycle': 3600,
                'connect_args': {
                    'connect_timeout': 30,
                    'application_name': 'LinkMGT'
                }
            })
            
        elif db_type.lower() == 'oracle':
            base_config['SQLALCHEMY_ENGINE_OPTIONS'].update({
                'pool_size': 5,
                'pool_timeout': 30,
                'pool_recycle': 3600,
                'connect_args': {
                    'encoding': 'UTF-8',
                    'nencoding': 'UTF-8'
                }
            })
            
        elif db_type.lower() in ['mariadb', 'mysql']:
            base_config['SQLALCHEMY_ENGINE_OPTIONS'].update({
                'pool_size': 10,
                'pool_timeout': 30,
                'pool_recycle': 3600,
                'connect_args': {
                    'charset': 'utf8mb4',
                    'connect_timeout': 30
                }
            })
        
        return base_config
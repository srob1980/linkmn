-- MySQL/MariaDB database schema for LinkMGT

-- Create database
CREATE DATABASE IF NOT EXISTS linkmgt
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- Use the database
USE linkmgt;

-- Users table
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  ad_dn VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL,
  is_active BOOLEAN DEFAULT TRUE,
  is_admin BOOLEAN DEFAULT FALSE,
  login_count INT DEFAULT 0,
  failed_login_attempts INT DEFAULT 0,
  locked_until TIMESTAMP NULL
) ENGINE=InnoDB;

-- Teams table
CREATE TABLE teams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  description TEXT,
  color VARCHAR(7) DEFAULT '#007bff',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  created_by INT,
  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- User-Team association table
CREATE TABLE user_team (
  user_id INT,
  team_id INT,
  role INT DEFAULT 0,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, team_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Categories table
CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  description TEXT,
  parent_id INT,
  color VARCHAR(7) DEFAULT '#2563eb',
  icon VARCHAR(50) DEFAULT 'fas fa-folder',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  created_by INT,
  FOREIGN KEY (parent_id) REFERENCES categories(id),
  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- Tags table
CREATE TABLE tags (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(32) NOT NULL UNIQUE,
  color VARCHAR(7) DEFAULT '#64748b',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Links table
CREATE TABLE links (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  url VARCHAR(500) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  creator_id INT,
  is_active BOOLEAN DEFAULT TRUE,
  is_public BOOLEAN DEFAULT FALSE,
  last_accessed TIMESTAMP NULL,
  favicon_url VARCHAR(500),
  status_code INT DEFAULT 200,
  last_checked TIMESTAMP NULL,
  FOREIGN KEY (creator_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- Link-Category association table
CREATE TABLE link_category (
  link_id INT,
  category_id INT,
  PRIMARY KEY (link_id, category_id),
  FOREIGN KEY (link_id) REFERENCES links(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Link-Tag association table
CREATE TABLE link_tag (
  link_id INT,
  tag_id INT,
  PRIMARY KEY (link_id, tag_id),
  FOREIGN KEY (link_id) REFERENCES links(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Link-Team association table
CREATE TABLE link_team (
  link_id INT,
  team_id INT,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (link_id, team_id),
  FOREIGN KEY (link_id) REFERENCES links(id) ON DELETE CASCADE,
  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- App Configuration table
CREATE TABLE app_config (
  id INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(64) NOT NULL UNIQUE,
  value VARCHAR(512) NOT NULL,
  description VARCHAR(256),
  category VARCHAR(50) DEFAULT 'general',
  is_sensitive BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_links_creator ON links(creator_id);
CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_app_config_category ON app_config(category);

-- Insert default admin user with password 'admin'
INSERT INTO users (username, email, password_hash, first_name, last_name, is_admin, is_active)
VALUES ('admin', 'admin@example.com', 
        'pbkdf2:sha256:150000$FVsNzmT2$9d78ce24733d37ec25ae8f78b2c82d6a80c7494467adc3229ac8b598c46a28e8',
        'Admin', 'User', TRUE, TRUE);

-- Insert default application configuration
INSERT INTO app_config (`key`, value, description, category)
VALUES 
  ('APP_NAME', 'LinkMGT', 'Application name', 'general'),
  ('APP_VERSION', '1.0.0', 'Application version', 'general'),
  ('ENABLE_REGISTRATION', 'true', 'Allow new user registration', 'security'),
  ('ALLOW_PASSWORD_RESET', 'true', 'Allow users to reset passwords', 'security');

-- Show created tables
SHOW TABLES;
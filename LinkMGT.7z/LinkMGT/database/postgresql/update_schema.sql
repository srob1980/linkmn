-- Add missing columns to app_config
DO $$ 
BEGIN
    -- Add type column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='app_config' AND column_name='type') THEN
        ALTER TABLE app_config 
        ADD COLUMN type varchar(20) DEFAULT 'string',
        ADD COLUMN is_sensitive boolean DEFAULT false,
        ADD COLUMN created_at timestamp DEFAULT CURRENT_TIMESTAMP,
        ADD COLUMN updated_at timestamp DEFAULT CURRENT_TIMESTAMP;
    END IF;

    -- Add trigger for updated_at
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_app_config_modtime') THEN
        CREATE TRIGGER update_app_config_modtime 
            BEFORE UPDATE ON app_config
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- Create activity_logs table
CREATE TABLE IF NOT EXISTS activity_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(50) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent VARCHAR(200),
    module VARCHAR(50),
    severity VARCHAR(20) DEFAULT 'INFO',
    status INTEGER DEFAULT 200,
    request_path VARCHAR(500),
    request_method VARCHAR(10),
    response_time FLOAT
);

-- Create indexes for activity_logs
CREATE INDEX IF NOT EXISTS idx_activity_logs_timestamp ON activity_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_action ON activity_logs(action);

-- Create system_logs table
CREATE TABLE IF NOT EXISTS system_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    level VARCHAR(20) NOT NULL,
    source VARCHAR(100),
    message TEXT NOT NULL,
    details JSONB,
    hostname VARCHAR(255),
    process_id INTEGER,
    thread_id VARCHAR(50),
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Create indexes for system_logs
CREATE INDEX IF NOT EXISTS idx_system_logs_timestamp ON system_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_system_logs_level ON system_logs(level);
CREATE INDEX IF NOT EXISTS idx_system_logs_source ON system_logs(source);

-- Create function for updating updated_at columns
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Update existing tables with updated_at triggers
DO $$ 
DECLARE
    t text;
BEGIN
    FOR t IN 
        SELECT table_name 
        FROM information_schema.columns 
        WHERE column_name = 'updated_at'
    LOOP
        EXECUTE format('
            DROP TRIGGER IF EXISTS update_%I_modtime ON %I;
            CREATE TRIGGER update_%I_modtime
                BEFORE UPDATE ON %I
                FOR EACH ROW
                EXECUTE FUNCTION update_updated_at_column();
        ', t, t, t, t);
    END LOOP;
END $$;

-- Add comments for documentation
COMMENT ON TABLE system_logs IS 'System-level logs for application monitoring';
COMMENT ON TABLE activity_logs IS 'User activity logs for auditing';
COMMENT ON TABLE app_config IS 'Application configuration settings';

-- Refresh materialized view if exists
REFRESH MATERIALIZED VIEW IF EXISTS mv_active_users;

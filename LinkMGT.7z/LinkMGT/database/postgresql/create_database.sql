-- PostgreSQL Database Schema for LinkMGT
-- Version: 1.0
-- Author: LinkMGT Team

-- Create database (run as superuser)
-- CREATE DATABASE linkmgt OWNER postgres ENCODING 'UTF8';

-- Connect to the database before running the following commands
-- \c linkmgt;

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";

-- Create custom types
CREATE TYPE user_role AS ENUM ('USER', 'EDITOR', 'ADMIN');

-- ==============================================
-- TABLES CREATION
-- ==============================================

-- App Configuration Table
CREATE TABLE app_config (
    id SERIAL PRIMARY KEY,
    key VARCHAR(64) UNIQUE NOT NULL,
    value VARCHAR(256) NOT NULL,
    description VARCHAR(256),
    is_sensitive BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    ad_dn VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    is_admin BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP,
    login_count INTEGER DEFAULT 0
);

-- Teams Table
CREATE TABLE teams (
    id SERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INTEGER REFERENCES users(id)
);

-- Categories Table (with hierarchical support)
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    description TEXT,
    parent_id INTEGER REFERENCES categories(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    color VARCHAR(7) DEFAULT '#2563eb' -- Hex color code
);

-- Tags Table
CREATE TABLE tags (
    id SERIAL PRIMARY KEY,
    name VARCHAR(32) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    color VARCHAR(7) DEFAULT '#64748b'
);

-- Links Table
CREATE TABLE links (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    url VARCHAR(500) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    creator_id INTEGER REFERENCES users(id),
    is_active BOOLEAN DEFAULT TRUE,
    click_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP,
    favicon_url VARCHAR(500),
    status_code INTEGER DEFAULT 200,
    last_checked TIMESTAMP
);

-- ==============================================
-- ASSOCIATION TABLES (Many-to-Many relationships)
-- ==============================================

-- User-Team Association with roles
CREATE TABLE user_team (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    role INTEGER DEFAULT 0, -- 0=USER, 1=EDITOR, 2=ADMIN
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, team_id)
);

-- Link-Team Association
CREATE TABLE link_team (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (link_id, team_id)
);

-- Link-Category Association
CREATE TABLE link_category (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, category_id)
);

-- Link-Tag Association
CREATE TABLE link_tag (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, tag_id)
);

-- ==============================================
-- AUDIT TABLES (for tracking changes)
-- ==============================================

-- Audit Log Table
CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    table_name VARCHAR(64) NOT NULL,
    record_id INTEGER NOT NULL,
    action VARCHAR(10) NOT NULL, -- INSERT, UPDATE, DELETE
    old_values JSONB,
    new_values JSONB,
    changed_by INTEGER REFERENCES users(id),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address INET,
    user_agent TEXT
);

-- ==============================================
-- INDEXES for better performance
-- ==============================================

-- Users indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_active ON users(is_active);
CREATE INDEX idx_users_created_at ON users(created_at);

-- Teams indexes
CREATE INDEX idx_teams_name ON teams(name);
CREATE INDEX idx_teams_is_active ON teams(is_active);

-- Categories indexes
CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_categories_parent_id ON categories(parent_id);
CREATE INDEX idx_categories_sort_order ON categories(sort_order);

-- Links indexes
CREATE INDEX idx_links_title ON links(title);
CREATE INDEX idx_links_url ON links(url);
CREATE INDEX idx_links_creator_id ON links(creator_id);
CREATE INDEX idx_links_created_at ON links(created_at);
CREATE INDEX idx_links_is_active ON links(is_active);
CREATE INDEX idx_links_click_count ON links(click_count);

-- Tags indexes
CREATE INDEX idx_tags_name ON tags(name);

-- Association table indexes
CREATE INDEX idx_user_team_role ON user_team(role);
CREATE INDEX idx_user_team_joined_at ON user_team(joined_at);

-- Full-text search indexes
CREATE INDEX idx_links_fulltext ON links USING gin(to_tsvector('english', title || ' ' || COALESCE(description, '')));

-- ==============================================
-- TRIGGERS for automatic timestamp updates
-- ==============================================

-- Function to update timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to tables with updated_at column
CREATE TRIGGER trigger_users_update_timestamp
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_teams_update_timestamp
    BEFORE UPDATE ON teams
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_categories_update_timestamp
    BEFORE UPDATE ON categories
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_links_update_timestamp
    BEFORE UPDATE ON links
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_app_config_update_timestamp
    BEFORE UPDATE ON app_config
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- ==============================================
-- VIEWS for common queries
-- ==============================================

-- User statistics view
CREATE VIEW v_user_stats AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.is_admin,
    u.is_active,
    u.created_at,
    u.last_login,
    u.login_count,
    COUNT(DISTINCT ut.team_id) as team_count,
    COUNT(DISTINCT l.id) as link_count
FROM users u
LEFT JOIN user_team ut ON u.id = ut.user_id
LEFT JOIN links l ON u.id = l.creator_id
GROUP BY u.id, u.username, u.email, u.is_admin, u.is_active, u.created_at, u.last_login, u.login_count;

-- Team statistics view
CREATE VIEW v_team_stats AS
SELECT 
    t.id,
    t.name,
    t.description,
    t.created_at,
    t.is_active,
    COUNT(DISTINCT ut.user_id) as member_count,
    COUNT(DISTINCT lt.link_id) as link_count,
    COUNT(DISTINCT CASE WHEN ut.role = 2 THEN ut.user_id END) as admin_count
FROM teams t
LEFT JOIN user_team ut ON t.id = ut.team_id
LEFT JOIN link_team lt ON t.id = lt.team_id
GROUP BY t.id, t.name, t.description, t.created_at, t.is_active;

-- Category statistics view
CREATE VIEW v_category_stats AS
SELECT 
    c.id,
    c.name,
    c.description,
    c.parent_id,
    c.sort_order,
    c.is_active,
    COUNT(DISTINCT lc.link_id) as link_count,
    COUNT(DISTINCT sub.id) as subcategory_count
FROM categories c
LEFT JOIN link_category lc ON c.id = lc.category_id
LEFT JOIN categories sub ON c.id = sub.parent_id
GROUP BY c.id, c.name, c.description, c.parent_id, c.sort_order, c.is_active;

-- ==============================================
-- FUNCTIONS for common operations
-- ==============================================

-- Function to get user role in team
CREATE OR REPLACE FUNCTION get_user_role_in_team(user_id_param INTEGER, team_id_param INTEGER)
RETURNS INTEGER AS $$
DECLARE
    user_role INTEGER;
BEGIN
    SELECT role INTO user_role
    FROM user_team
    WHERE user_id = user_id_param AND team_id = team_id_param;
    
    RETURN COALESCE(user_role, -1); -- -1 means not in team
END;
$$ LANGUAGE plpgsql;

-- Function to count links by user
CREATE OR REPLACE FUNCTION count_user_links(user_id_param INTEGER)
RETURNS INTEGER AS $$
DECLARE
    link_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO link_count
    FROM links
    WHERE creator_id = user_id_param AND is_active = TRUE;
    
    RETURN COALESCE(link_count, 0);
END;
$$ LANGUAGE plpgsql;

-- ==============================================
-- INITIAL DATA
-- ==============================================

-- Insert default app configuration
INSERT INTO app_config (key, value, description, is_sensitive) VALUES
('AUTH_USE_AD', 'False', 'Use Active Directory authentication', FALSE),
('AUTH_ALLOW_REGISTRATION', 'True', 'Allow user registration', FALSE),
('AUTH_AD_FALLBACK', 'True', 'Fallback to database auth if AD fails', FALSE),
('HTTP_PORT', '5000', 'HTTP port for the application', FALSE),
('HTTPS_ENABLED', 'False', 'Enable HTTPS', FALSE),
('HTTPS_PORT', '5443', 'HTTPS port for the application', FALSE),
('SSL_CERT_PATH', 'certificate/cert.pem', 'Path to SSL certificate', FALSE),
('SSL_KEY_PATH', 'certificate/key.pem', 'Path to SSL private key', FALSE),
('MAX_UPLOAD_SIZE', '10485760', 'Maximum file upload size in bytes (10MB)', FALSE),
('SESSION_TIMEOUT', '43200', 'Session timeout in seconds (12 hours)', FALSE),
('PASSWORD_MIN_LENGTH', '8', 'Minimum password length', FALSE),
('LOGIN_ATTEMPTS_LIMIT', '5', 'Maximum login attempts before lockout', FALSE);

-- Insert default admin user
INSERT INTO users (username, email, password_hash, is_admin, is_active) VALUES
('admin', 'admin@linkmgt.com', 'pbkdf2:sha256:600000$default$hash', TRUE, TRUE);

-- Insert default categories
INSERT INTO categories (name, description, sort_order, color) VALUES
('Dokumentacja', 'Dokumenty, instrukcje i przewodniki', 1, '#3b82f6'),
('Narzędzia', 'Narzędzia deweloperskie i administracyjne', 2, '#10b981'),
('Zasoby', 'Zasoby zewnętrzne i referencje', 3, '#f59e0b'),
('Projekty', 'Linki związane z projektami', 4, '#8b5cf6'),
('Monitorowanie', 'Narzędzia do monitorowania i logowania', 5, '#ef4444');

-- Insert default tags
INSERT INTO tags (name, color) VALUES
('ważne', '#dc2626'),
('nowe', '#16a34a'),
('dokumentacja', '#2563eb'),
('narzędzie', '#9333ea'),
('zewnętrzne', '#ea580c');

-- ==============================================
-- PERMISSIONS AND SECURITY
-- ==============================================

-- Create roles for different access levels
CREATE ROLE linkmgt_reader;
CREATE ROLE linkmgt_editor;
CREATE ROLE linkmgt_admin;

-- Grant permissions to reader role
GRANT SELECT ON ALL TABLES IN SCHEMA public TO linkmgt_reader;

-- Grant permissions to editor role
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO linkmgt_editor;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO linkmgt_editor;

-- Grant permissions to admin role
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO linkmgt_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO linkmgt_admin;

-- Create application user (example)
-- CREATE USER linkmgt_app WITH PASSWORD 'your_secure_password';
-- GRANT linkmgt_editor TO linkmgt_app;

COMMENT ON DATABASE linkmgt IS 'LinkMGT - System zarządzania linkami';
COMMENT ON TABLE users IS 'Tabela użytkowników systemu';
COMMENT ON TABLE teams IS 'Tabela zespołów projektowych';
COMMENT ON TABLE categories IS 'Tabela kategorii z obsługą hierarchii';
COMMENT ON TABLE links IS 'Tabela linków z metadanymi';
COMMENT ON TABLE audit_log IS 'Tabela audytu zmian w systemie';
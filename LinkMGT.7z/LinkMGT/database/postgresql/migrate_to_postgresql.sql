-- PostgreSQL Migration Script for LinkMGT
-- Version: 1.0
-- Author: LinkMGT Team
-- Description: Complete database migration script for PostgreSQL

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";

-- ==============================================
-- DROP EXISTING TABLES (if they exist)
-- ==============================================

-- Drop tables in reverse order to handle foreign key constraints
DROP TABLE IF EXISTS maintenance_logs CASCADE;
DROP TABLE IF EXISTS license_assets CASCADE;
DROP TABLE IF EXISTS contract_assets CASCADE;
DROP TABLE IF EXISTS support_contracts CASCADE;
DROP TABLE IF EXISTS licenses CASCADE;
DROP TABLE IF EXISTS assets CASCADE;
DROP TABLE IF EXISTS vendors CASCADE;
DROP TABLE IF EXISTS locations CASCADE;
DROP TABLE IF EXISTS link_clicks CASCADE;
DROP TABLE IF EXISTS link_tags CASCADE;
DROP TABLE IF EXISTS link_categories CASCADE;
DROP TABLE IF EXISTS link_teams CASCADE;
DROP TABLE IF EXISTS user_teams CASCADE;
DROP TABLE IF EXISTS links CASCADE;
DROP TABLE IF EXISTS tags CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS teams CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS app_config CASCADE;

-- Drop custom types if they exist
DROP TYPE IF EXISTS user_role CASCADE;
DROP TYPE IF EXISTS asset_type CASCADE;
DROP TYPE IF EXISTS asset_status CASCADE;
DROP TYPE IF EXISTS priority CASCADE;
DROP TYPE IF EXISTS contract_status CASCADE;
DROP TYPE IF EXISTS license_type CASCADE;
DROP TYPE IF EXISTS maintenance_type CASCADE;

-- ==============================================
-- CREATE CUSTOM TYPES
-- ==============================================

-- User roles for team membership
CREATE TYPE user_role AS ENUM ('USER', 'EDITOR', 'ADMIN');

-- Asset types
CREATE TYPE asset_type AS ENUM (
    'SERVER', 'STORAGE', 'SAN', 'NETWORK', 'SWITCH', 'ROUTER', 'FIREWALL',
    'UPS', 'WORKSTATION', 'LAPTOP', 'DESKTOP', 'MONITOR', 'PRINTER', 
    'SCANNER', 'TABLET', 'PHONE', 'ACCESS_POINT', 'CAMERA', 'OTHER'
);

-- Asset status
CREATE TYPE asset_status AS ENUM (
    'PLANNING', 'ORDERED', 'DELIVERED', 'INSTALLED', 'ACTIVE', 
    'MAINTENANCE', 'RETIRED', 'DISPOSED', 'BROKEN'
);

-- Priority levels
CREATE TYPE priority AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');

-- Contract status
CREATE TYPE contract_status AS ENUM ('ACTIVE', 'EXPIRED', 'PENDING', 'CANCELLED');

-- License types
CREATE TYPE license_type AS ENUM (
    'OEM', 'RETAIL', 'VOLUME', 'SUBSCRIPTION', 'PERPETUAL', 
    'TRIAL', 'EDUCATIONAL', 'NFR'
);

-- Maintenance types
CREATE TYPE maintenance_type AS ENUM (
    'PREVENTIVE', 'CORRECTIVE', 'UPGRADE', 'REPLACEMENT', 'INSPECTION'
);

-- ==============================================
-- CORE TABLES
-- ==============================================

-- App Configuration Table
CREATE TABLE app_config (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT,
    description TEXT,
    is_sensitive BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    avatar VARCHAR(200),
    bio TEXT,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE NOT NULL,
    email_verified BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    login_count INTEGER DEFAULT 0
);

-- Teams Table
CREATE TABLE teams (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    color VARCHAR(7) DEFAULT '#2563eb',
    is_public BOOLEAN DEFAULT FALSE,
    max_members INTEGER DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Categories Table (with hierarchical support)
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'fas fa-folder',
    color VARCHAR(7) DEFAULT '#2563eb',
    parent_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Tags Table
CREATE TABLE tags (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    color VARCHAR(7) DEFAULT '#64748b',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Links Table
CREATE TABLE links (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    url TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    click_count INTEGER DEFAULT 0,
    last_checked TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    creator_id INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================
-- INFRASTRUCTURE TABLES
-- ==============================================

-- Locations Table
CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) UNIQUE,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    postal_code VARCHAR(20),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Vendors Table
CREATE TABLE vendors (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) DEFAULT 'supplier',
    contact_person VARCHAR(100),
    email VARCHAR(120),
    phone VARCHAR(20),
    website VARCHAR(200),
    address TEXT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Assets Table
CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    asset_tag VARCHAR(50) UNIQUE,
    asset_type asset_type NOT NULL,
    status asset_status NOT NULL DEFAULT 'PLANNING',
    
    -- Basic information
    manufacturer VARCHAR(100),
    model VARCHAR(100),
    part_number VARCHAR(100),
    serial_number VARCHAR(100),
    
    -- Location and assignment
    location INTEGER REFERENCES locations(id) ON DELETE SET NULL,
    assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
    
    -- Purchase information
    purchase_date DATE,
    purchase_cost DECIMAL(12,2),
    supplier VARCHAR(100),
    purchase_order VARCHAR(50),
    invoice_number VARCHAR(50),
    
    -- Warranty information
    warranty_start DATE,
    warranty_end DATE,
    warranty_type VARCHAR(50),
    
    -- Technical specifications (JSON for flexibility)
    cpu_model VARCHAR(100),
    cpu_cores INTEGER,
    ram_gb INTEGER,
    storage_gb INTEGER,
    network_ports INTEGER,
    power_consumption INTEGER,
    operating_system VARCHAR(100),
    ip_address INET,
    mac_address VARCHAR(17),
    
    -- Additional information
    description TEXT,
    notes TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Licenses Table
CREATE TABLE licenses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    license_type license_type NOT NULL DEFAULT 'PERPETUAL',
    
    -- License details
    software_name VARCHAR(100) NOT NULL,
    version VARCHAR(50),
    license_key TEXT,
    seats_total INTEGER DEFAULT 1,
    seats_used INTEGER DEFAULT 0,
    
    -- Vendor and purchase information
    vendor_id INTEGER REFERENCES vendors(id) ON DELETE SET NULL,
    purchase_date DATE,
    purchase_cost DECIMAL(12,2),
    order_number VARCHAR(50),
    
    -- Validity period
    valid_from DATE,
    valid_until DATE,
    
    -- Compliance and tracking
    compliance_notes TEXT,
    renewal_date DATE,
    auto_renewal BOOLEAN DEFAULT FALSE,
    
    -- Metadata
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Support Contracts Table
CREATE TABLE support_contracts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contract_number VARCHAR(50) UNIQUE,
    
    -- Contract details
    vendor_id INTEGER REFERENCES vendors(id) ON DELETE SET NULL,
    service_level VARCHAR(50),
    response_time VARCHAR(50),
    
    -- Contract period
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    
    -- Financial information
    cost DECIMAL(12,2),
    billing_frequency VARCHAR(20) DEFAULT 'annual',
    
    -- Status and renewal
    status contract_status DEFAULT 'ACTIVE',
    auto_renewal BOOLEAN DEFAULT FALSE,
    renewal_notice_days INTEGER DEFAULT 90,
    
    -- Contact information
    contact_person VARCHAR(100),
    contact_email VARCHAR(120),
    contact_phone VARCHAR(20),
    
    -- Additional information
    description TEXT,
    terms_and_conditions TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Maintenance Logs Table
CREATE TABLE maintenance_logs (
    id SERIAL PRIMARY KEY,
    asset_id INTEGER REFERENCES assets(id) ON DELETE CASCADE,
    
    -- Maintenance details
    maintenance_type maintenance_type NOT NULL,
    priority priority DEFAULT 'MEDIUM',
    
    -- Schedule and completion
    scheduled_date DATE,
    completed_date DATE,
    duration_hours DECIMAL(4,2),
    
    -- Personnel and costs
    performed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    technician_notes TEXT,
    cost DECIMAL(10,2),
    
    -- Parts and documentation
    parts_used TEXT,
    work_description TEXT NOT NULL,
    
    -- Follow-up
    next_maintenance_date DATE,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Link Clicks Table (for analytics)
CREATE TABLE link_clicks (
    id SERIAL PRIMARY KEY,
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    ip_address INET,
    user_agent TEXT,
    clicked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================
-- ASSOCIATION TABLES (Many-to-Many relationships)
-- ==============================================

-- User-Team Association with roles
CREATE TABLE user_teams (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    role user_role DEFAULT 'USER',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, team_id)
);

-- Link-Team Association
CREATE TABLE link_teams (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, team_id)
);

-- Link-Category Association
CREATE TABLE link_categories (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, category_id)
);

-- Link-Tag Association
CREATE TABLE link_tags (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, tag_id)
);

-- License-Asset Association
CREATE TABLE license_assets (
    license_id INTEGER REFERENCES licenses(id) ON DELETE CASCADE,
    asset_id INTEGER REFERENCES assets(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (license_id, asset_id)
);

-- Contract-Asset Association
CREATE TABLE contract_assets (
    contract_id INTEGER REFERENCES support_contracts(id) ON DELETE CASCADE,
    asset_id INTEGER REFERENCES assets(id) ON DELETE CASCADE,
    PRIMARY KEY (contract_id, asset_id)
);

-- ==============================================
-- INDEXES for performance optimization
-- ==============================================

-- Users indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_active ON users(is_active);
CREATE INDEX idx_users_created_at ON users(created_at);

-- Teams indexes
CREATE INDEX idx_teams_name ON teams(name);
CREATE INDEX idx_teams_is_public ON teams(is_public);
CREATE INDEX idx_teams_created_by ON teams(created_by);

-- Categories indexes
CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_categories_parent_id ON categories(parent_id);
CREATE INDEX idx_categories_created_by ON categories(created_by);

-- Tags indexes
CREATE INDEX idx_tags_name ON tags(name);

-- Links indexes
CREATE INDEX idx_links_title ON links(title);
CREATE INDEX idx_links_is_active ON links(is_active);
CREATE INDEX idx_links_created_at ON links(created_at);
CREATE INDEX idx_links_creator_id ON links(creator_id);
CREATE INDEX idx_links_click_count ON links(click_count);

-- Assets indexes
CREATE INDEX idx_assets_name ON assets(name);
CREATE INDEX idx_assets_asset_tag ON assets(asset_tag);
CREATE INDEX idx_assets_asset_type ON assets(asset_type);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_assets_serial_number ON assets(serial_number);
CREATE INDEX idx_assets_location ON assets(location);
CREATE INDEX idx_assets_assigned_to ON assets(assigned_to);
CREATE INDEX idx_assets_created_at ON assets(created_at);

-- Licenses indexes
CREATE INDEX idx_licenses_software_name ON licenses(software_name);
CREATE INDEX idx_licenses_license_type ON licenses(license_type);
CREATE INDEX idx_licenses_valid_until ON licenses(valid_until);
CREATE INDEX idx_licenses_vendor_id ON licenses(vendor_id);

-- Support contracts indexes
CREATE INDEX idx_contracts_name ON support_contracts(name);
CREATE INDEX idx_contracts_status ON support_contracts(status);
CREATE INDEX idx_contracts_end_date ON support_contracts(end_date);
CREATE INDEX idx_contracts_vendor_id ON support_contracts(vendor_id);

-- Maintenance logs indexes
CREATE INDEX idx_maintenance_asset_id ON maintenance_logs(asset_id);
CREATE INDEX idx_maintenance_scheduled_date ON maintenance_logs(scheduled_date);
CREATE INDEX idx_maintenance_completed_date ON maintenance_logs(completed_date);
CREATE INDEX idx_maintenance_type ON maintenance_logs(maintenance_type);

-- Link clicks indexes
CREATE INDEX idx_link_clicks_link_id ON link_clicks(link_id);
CREATE INDEX idx_link_clicks_user_id ON link_clicks(user_id);
CREATE INDEX idx_link_clicks_clicked_at ON link_clicks(clicked_at);

-- Association table indexes
CREATE INDEX idx_user_teams_user_id ON user_teams(user_id);
CREATE INDEX idx_user_teams_team_id ON user_teams(team_id);
CREATE INDEX idx_link_teams_link_id ON link_teams(link_id);
CREATE INDEX idx_link_teams_team_id ON link_teams(team_id);
CREATE INDEX idx_link_categories_link_id ON link_categories(link_id);
CREATE INDEX idx_link_categories_category_id ON link_categories(category_id);
CREATE INDEX idx_link_tags_link_id ON link_tags(link_id);
CREATE INDEX idx_link_tags_tag_id ON link_tags(tag_id);

-- ==============================================
-- TRIGGERS for automatic timestamp updates
-- ==============================================

-- Function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to tables with updated_at columns
CREATE TRIGGER update_app_config_updated_at BEFORE UPDATE ON app_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_teams_updated_at BEFORE UPDATE ON teams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_links_updated_at BEFORE UPDATE ON links FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_assets_updated_at BEFORE UPDATE ON assets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_licenses_updated_at BEFORE UPDATE ON licenses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_support_contracts_updated_at BEFORE UPDATE ON support_contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_locations_updated_at BEFORE UPDATE ON locations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vendors_updated_at BEFORE UPDATE ON vendors FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ==============================================
-- VIEWS for common queries
-- ==============================================

-- User statistics view
CREATE VIEW v_user_stats AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.is_active,
    u.is_admin,
    COALESCE(team_counts.team_count, 0) as team_count,
    COALESCE(link_counts.link_count, 0) as link_count,
    COALESCE(asset_counts.asset_count, 0) as asset_count,
    u.created_at,
    u.last_login
FROM users u
LEFT JOIN (
    SELECT user_id, COUNT(*) as team_count
    FROM user_teams 
    GROUP BY user_id
) team_counts ON u.id = team_counts.user_id
LEFT JOIN (
    SELECT creator_id, COUNT(*) as link_count
    FROM links 
    WHERE is_active = true
    GROUP BY creator_id
) link_counts ON u.id = link_counts.creator_id
LEFT JOIN (
    SELECT assigned_to, COUNT(*) as asset_count
    FROM assets 
    WHERE status = 'ACTIVE'
    GROUP BY assigned_to
) asset_counts ON u.id = asset_counts.assigned_to;

-- Team statistics view
CREATE VIEW v_team_stats AS
SELECT 
    t.id,
    t.name,
    t.description,
    t.color,
    t.is_public,
    COALESCE(member_counts.member_count, 0) as member_count,
    COALESCE(link_counts.link_count, 0) as link_count,
    t.created_at
FROM teams t
LEFT JOIN (
    SELECT team_id, COUNT(*) as member_count
    FROM user_teams 
    GROUP BY team_id
) member_counts ON t.id = member_counts.team_id
LEFT JOIN (
    SELECT team_id, COUNT(*) as link_count
    FROM link_teams 
    GROUP BY team_id
) link_counts ON t.id = link_counts.team_id;

-- Asset summary view
CREATE VIEW v_asset_summary AS
SELECT 
    a.id,
    a.name,
    a.asset_tag,
    a.asset_type,
    a.status,
    a.manufacturer,
    a.model,
    a.serial_number,
    l.name as location_name,
    u.username as assigned_to_username,
    a.warranty_end,
    CASE 
        WHEN a.warranty_end < CURRENT_DATE THEN 'EXPIRED'
        WHEN a.warranty_end <= CURRENT_DATE + INTERVAL '90 days' THEN 'EXPIRING'
        ELSE 'VALID'
    END as warranty_status,
    a.created_at
FROM assets a
LEFT JOIN locations l ON a.location = l.id
LEFT JOIN users u ON a.assigned_to = u.id;

-- License summary view
CREATE VIEW v_license_summary AS
SELECT 
    l.id,
    l.name,
    l.software_name,
    l.license_type,
    l.seats_total,
    l.seats_used,
    (l.seats_total - l.seats_used) as seats_available,
    l.valid_until,
    CASE 
        WHEN l.valid_until IS NULL THEN 'PERPETUAL'
        WHEN l.valid_until < CURRENT_DATE THEN 'EXPIRED'
        WHEN l.valid_until <= CURRENT_DATE + INTERVAL '90 days' THEN 'EXPIRING'
        ELSE 'VALID'
    END as license_status,
    v.name as vendor_name,
    l.created_at
FROM licenses l
LEFT JOIN vendors v ON l.vendor_id = v.id;

-- ==============================================
-- INSERT DEFAULT DATA
-- ==============================================

-- Default application configurations
INSERT INTO app_config (key, value, description, is_sensitive) VALUES
('APP_NAME', 'LinkMGT', 'Application name', false),
('APP_VERSION', '1.0.0', 'Application version', false),
('DATABASE_TYPE', 'postgresql', 'Database type', false),
('MAX_LINKS_PER_USER', '100', 'Maximum links per user', false),
('ENABLE_USER_REGISTRATION', 'true', 'Enable user registration', false),
('DEFAULT_THEME', 'light', 'Default UI theme', false),
('HTTP_PORT', '5000', 'HTTP port', false),
('HTTPS_ENABLED', 'false', 'Enable HTTPS', false),
('HTTPS_PORT', '5443', 'HTTPS port', false),
('SSL_CERT_PATH', 'certificate/cert.pem', 'SSL certificate path', true),
('SSL_KEY_PATH', 'certificate/key.pem', 'SSL key path', true),
('SESSION_TIMEOUT', '3600', 'Session timeout in seconds', false),
('MAX_FILE_SIZE', '16777216', 'Maximum file upload size in bytes', false),
('BACKUP_RETENTION_DAYS', '30', 'Backup retention period in days', false),
('MAINTENANCE_MODE', 'false', 'Maintenance mode flag', false);

-- Default admin user (password: admin123)
INSERT INTO users (username, email, password_hash, first_name, last_name, is_admin, is_active, email_verified, created_at) VALUES
('admin', 'admin@linkmgt.local', 'pbkdf2:sha256:600000$salt$hash', 'Administrator', 'Systemu', true, true, true, CURRENT_TIMESTAMP);

-- Default demo user (password: demo123)
INSERT INTO users (username, email, password_hash, first_name, last_name, is_admin, is_active, email_verified, created_at) VALUES
('demo', 'demo@linkmgt.local', 'pbkdf2:sha256:600000$salt$hash', 'Demo', 'User', false, true, true, CURRENT_TIMESTAMP);

-- Default location
INSERT INTO locations (name, code, address, city, country, description, is_active) VALUES
('Biuro główne', 'HQ01', 'ul. Przykładowa 123', 'Warszawa', 'Polska', 'Główna siedziba firmy', true),
('Centrum danych', 'DC01', 'ul. Serwerowa 456', 'Kraków', 'Polska', 'Główne centrum danych', true);

-- Default vendors
INSERT INTO vendors (name, type, email, website, description, is_active) VALUES
('Dell Technologies', 'manufacturer', 'support@dell.com', 'https://www.dell.com', 'Producent sprzętu komputerowego', true),
('Microsoft', 'software', 'support@microsoft.com', 'https://www.microsoft.com', 'Producent oprogramowania', true),
('VMware', 'software', 'support@vmware.com', 'https://www.vmware.com', 'Oprogramowanie do wirtualizacji', true);

-- Default categories
INSERT INTO categories (name, description, icon, color, sort_order, created_by) VALUES
('Dokumentacja', 'Dokumenty i instrukcje', 'fas fa-file-alt', '#2563eb', 1, 1),
('Narzędzia', 'Narzędzia programistyczne', 'fas fa-tools', '#059669', 2, 1),
('Monitoring', 'Systemy monitorowania', 'fas fa-chart-line', '#dc2626', 3, 1),
('Backup', 'Systemy kopii zapasowych', 'fas fa-hdd', '#ca8a04', 4, 1);

-- Default tags
INSERT INTO tags (name, color) VALUES
('praca', '#2563eb'),
('ważne', '#dc2626'),
('dokumentacja', '#059669'),
('narzędzia', '#ca8a04'),
('monitoring', '#9333ea');

-- ==============================================
-- FUNCTIONS for common operations
-- ==============================================

-- Function to get asset warranty status
CREATE OR REPLACE FUNCTION get_asset_warranty_status(asset_id INTEGER)
RETURNS TEXT AS $$
DECLARE
    warranty_end_date DATE;
BEGIN
    SELECT warranty_end INTO warranty_end_date FROM assets WHERE id = asset_id;
    
    IF warranty_end_date IS NULL THEN
        RETURN 'UNKNOWN';
    ELSIF warranty_end_date < CURRENT_DATE THEN
        RETURN 'EXPIRED';
    ELSIF warranty_end_date <= CURRENT_DATE + INTERVAL '90 days' THEN
        RETURN 'EXPIRING';
    ELSE
        RETURN 'VALID';
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to get license usage percentage
CREATE OR REPLACE FUNCTION get_license_usage_percentage(license_id INTEGER)
RETURNS DECIMAL AS $$
DECLARE
    total_seats INTEGER;
    used_seats INTEGER;
BEGIN
    SELECT seats_total, seats_used INTO total_seats, used_seats 
    FROM licenses WHERE id = license_id;
    
    IF total_seats = 0 THEN
        RETURN 0;
    ELSE
        RETURN ROUND((used_seats::DECIMAL / total_seats::DECIMAL) * 100, 2);
    END IF;
END;
$$ LANGUAGE plpgsql;

-- ==============================================
-- COMMENTS for documentation
-- ==============================================

COMMENT ON TABLE app_config IS 'Konfiguracja aplikacji';
COMMENT ON TABLE users IS 'Użytkownicy systemu';
COMMENT ON TABLE teams IS 'Zespoły użytkowników';
COMMENT ON TABLE categories IS 'Kategorie hierarchiczne dla linków';
COMMENT ON TABLE tags IS 'Tagi dla linków';
COMMENT ON TABLE links IS 'Linki zarządzane przez system';
COMMENT ON TABLE locations IS 'Lokalizacje fizyczne zasobów';
COMMENT ON TABLE vendors IS 'Dostawcy sprzętu i oprogramowania';
COMMENT ON TABLE assets IS 'Zasoby IT (sprzęt komputerowy)';
COMMENT ON TABLE licenses IS 'Licencje oprogramowania';
COMMENT ON TABLE support_contracts IS 'Kontrakty wsparcia technicznego';
COMMENT ON TABLE maintenance_logs IS 'Dziennik konserwacji zasobów';
COMMENT ON TABLE link_clicks IS 'Historia kliknięć w linki';

-- Column comments for important fields
COMMENT ON COLUMN users.password_hash IS 'Hash hasła użytkownika (pbkdf2:sha256)';
COMMENT ON COLUMN assets.ip_address IS 'Adres IP zasobu (jeśli dotyczy)';
COMMENT ON COLUMN assets.mac_address IS 'Adres MAC interfejsu sieciowego';
COMMENT ON COLUMN licenses.license_key IS 'Klucz licencyjny (zaszyfrowany)';
COMMENT ON COLUMN support_contracts.renewal_notice_days IS 'Dni przed wygaśnięciem do powiadomienia o odnowieniu';

-- ==============================================
-- MIGRATION COMPLETED
-- ==============================================

-- Set ownership and permissions
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO linkmgt;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO linkmgt;

-- Display summary
SELECT 'PostgreSQL migration completed successfully!' as status,
       COUNT(*) as tables_created
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_type = 'BASE TABLE';

-- Display table sizes (for monitoring)
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
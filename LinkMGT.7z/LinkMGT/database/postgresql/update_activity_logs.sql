-- Add missing columns to activity_logs table
DO $$ 
BEGIN
    -- Add user_agent column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='user_agent') THEN
        ALTER TABLE activity_logs ADD COLUMN user_agent varchar(200);
    END IF;

    -- Add ip_address column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='ip_address') THEN
        ALTER TABLE activity_logs ADD COLUMN ip_address varchar(45);
    END IF;

    -- Add module column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='module') THEN
        ALTER TABLE activity_logs ADD COLUMN module varchar(50);
    END IF;

    -- Add severity column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='severity') THEN
        ALTER TABLE activity_logs ADD COLUMN severity varchar(20) DEFAULT 'INFO';
    END IF;

    -- Add status column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='status') THEN
        ALTER TABLE activity_logs ADD COLUMN status integer DEFAULT 200;
    END IF;

    -- Add request_path column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='request_path') THEN
        ALTER TABLE activity_logs ADD COLUMN request_path varchar(500);
    END IF;

    -- Add request_method column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='request_method') THEN
        ALTER TABLE activity_logs ADD COLUMN request_method varchar(10);
    END IF;

    -- Add response_time column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                  WHERE table_name='activity_logs' AND column_name='response_time') THEN
        ALTER TABLE activity_logs ADD COLUMN response_time float;
    END IF;

END $$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_activity_logs_timestamp ON activity_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_action ON activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_activity_logs_severity ON activity_logs(severity);

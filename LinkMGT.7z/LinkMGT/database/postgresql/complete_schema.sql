-- Complete PostgreSQL Database Schema for LinkMGT
-- Version: 2.0
-- Author: LinkMGT Team
-- Description: Complete database structure with all tables, indexes, triggers, and initial data

-- ==========================================
-- DATABASE CREATION (run as superuser)
-- ==========================================
-- CREATE DATABASE linkmgt OWNER postgres ENCODING 'UTF8';
-- \c linkmgt;

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Drop existing objects if they exist
DROP TABLE IF EXISTS audit_log CASCADE;
DROP TABLE IF EXISTS link_tag CASCADE;
DROP TABLE IF EXISTS link_category CASCADE;
DROP TABLE IF EXISTS link_team CASCADE;
DROP TABLE IF EXISTS user_team CASCADE;
DROP TABLE IF EXISTS maintenance_log CASCADE;
DROP TABLE IF EXISTS support_contracts CASCADE;
DROP TABLE IF EXISTS licenses CASCADE;
DROP TABLE IF EXISTS assets CASCADE;
DROP TABLE IF EXISTS asset_types CASCADE;
DROP TABLE IF EXISTS vendors CASCADE;
DROP TABLE IF EXISTS locations CASCADE;
DROP TABLE IF EXISTS links CASCADE;
DROP TABLE IF EXISTS tags CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS teams CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS app_config CASCADE;

-- Drop views if they exist
DROP VIEW IF EXISTS v_user_stats CASCADE;
DROP VIEW IF EXISTS v_team_stats CASCADE;
DROP VIEW IF EXISTS v_category_stats CASCADE;
DROP VIEW IF EXISTS v_asset_stats CASCADE;

-- Drop functions if they exist
DROP FUNCTION IF EXISTS update_timestamp() CASCADE;
DROP FUNCTION IF EXISTS get_user_role_in_team(INTEGER, INTEGER) CASCADE;
DROP FUNCTION IF EXISTS count_user_links(INTEGER) CASCADE;

-- Drop types if they exist
DROP TYPE IF EXISTS user_role CASCADE;
DROP TYPE IF EXISTS asset_status CASCADE;
DROP TYPE IF EXISTS priority_level CASCADE;
DROP TYPE IF EXISTS contract_status CASCADE;

-- ==========================================
-- CUSTOM TYPES
-- ==========================================
CREATE TYPE user_role AS ENUM ('USER', 'EDITOR', 'ADMIN');
CREATE TYPE asset_status AS ENUM ('ACTIVE', 'INACTIVE', 'MAINTENANCE', 'DECOMMISSIONED');
CREATE TYPE priority_level AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');
CREATE TYPE contract_status AS ENUM ('ACTIVE', 'EXPIRED', 'PENDING', 'CANCELLED');

-- ==========================================
-- CORE TABLES
-- ==========================================

-- App Configuration Table
CREATE TABLE app_config (
    id SERIAL PRIMARY KEY,
    key VARCHAR(64) UNIQUE NOT NULL,
    value VARCHAR(512) NOT NULL,
    description VARCHAR(256),
    category VARCHAR(50) DEFAULT 'general',
    is_sensitive BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    ad_dn VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    is_admin BOOLEAN DEFAULT FALSE,
    login_count INTEGER DEFAULT 0,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP
);

-- Teams Table
CREATE TABLE teams (
    id SERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    description TEXT,
    color VARCHAR(7) DEFAULT '#007bff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Categories Table (with hierarchical support)
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    description TEXT,
    parent_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    color VARCHAR(7) DEFAULT '#2563eb',
    icon VARCHAR(50) DEFAULT 'fas fa-folder',
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Tags Table
CREATE TABLE tags (
    id SERIAL PRIMARY KEY,
    name VARCHAR(32) UNIQUE NOT NULL,
    color VARCHAR(7) DEFAULT '#64748b',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Links Table
CREATE TABLE links (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    url VARCHAR(500) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    creator_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_public BOOLEAN DEFAULT FALSE,
    click_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP,
    favicon_url VARCHAR(500),
    status_code INTEGER DEFAULT 200,
    last_checked TIMESTAMP
);

-- ==========================================
-- INFRASTRUCTURE TABLES
-- ==========================================

-- Locations Table
CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT,
    city VARCHAR(50),
    country VARCHAR(50),
    postal_code VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Vendors Table
CREATE TABLE vendors (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(120),
    phone VARCHAR(30),
    address TEXT,
    city VARCHAR(50),
    country VARCHAR(50),
    website VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Asset Types Table
CREATE TABLE asset_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'fas fa-server',
    color VARCHAR(7) DEFAULT '#6b7280',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Assets Table
CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    asset_tag VARCHAR(50) UNIQUE,
    serial_number VARCHAR(100),
    model VARCHAR(100),
    manufacturer VARCHAR(100),
    asset_type_id INTEGER REFERENCES asset_types(id),
    location_id INTEGER REFERENCES locations(id),
    vendor_id INTEGER REFERENCES vendors(id),
    status asset_status DEFAULT 'ACTIVE',
    purchase_date DATE,
    warranty_end DATE,
    value DECIMAL(10,2),
    description TEXT,
    ip_address INET,
    mac_address MACADDR,
    operating_system VARCHAR(100),
    cpu VARCHAR(100),
    memory_gb INTEGER,
    storage_gb INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Licenses Table
CREATE TABLE licenses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    software VARCHAR(100) NOT NULL,
    license_key TEXT,
    license_type VARCHAR(50),
    vendor_id INTEGER REFERENCES vendors(id),
    purchase_date DATE,
    expiry_date DATE,
    seats INTEGER DEFAULT 1,
    used_seats INTEGER DEFAULT 0,
    cost DECIMAL(10,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Support Contracts Table
CREATE TABLE support_contracts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    vendor_id INTEGER REFERENCES vendors(id),
    contract_number VARCHAR(50),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status contract_status DEFAULT 'ACTIVE',
    cost DECIMAL(10,2),
    description TEXT,
    contact_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Maintenance Log Table
CREATE TABLE maintenance_log (
    id SERIAL PRIMARY KEY,
    asset_id INTEGER REFERENCES assets(id) ON DELETE CASCADE,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    maintenance_type VARCHAR(50),
    priority priority_level DEFAULT 'MEDIUM',
    scheduled_date TIMESTAMP,
    completed_date TIMESTAMP,
    performed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    cost DECIMAL(10,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- ==========================================
-- ASSOCIATION TABLES (Many-to-Many relationships)
-- ==========================================

-- User-Team Association with roles
CREATE TABLE user_team (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    role INTEGER DEFAULT 0, -- 0=USER, 1=EDITOR, 2=ADMIN
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, team_id)
);

-- Link-Team Association
CREATE TABLE link_team (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (link_id, team_id)
);

-- Link-Category Association
CREATE TABLE link_category (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, category_id)
);

-- Link-Tag Association
CREATE TABLE link_tag (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, tag_id)
);

-- ==========================================
-- AUDIT TABLE
-- ==========================================

-- Audit Log Table
CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    table_name VARCHAR(64) NOT NULL,
    record_id INTEGER NOT NULL,
    action VARCHAR(10) NOT NULL, -- INSERT, UPDATE, DELETE
    old_values JSONB,
    new_values JSONB,
    changed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address INET,
    user_agent TEXT
);

-- ==========================================
-- INDEXES for better performance
-- ==========================================

-- Core table indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_active ON users(is_active);
CREATE INDEX idx_users_created_at ON users(created_at);
CREATE INDEX idx_users_is_admin ON users(is_admin);

CREATE INDEX idx_teams_name ON teams(name);
CREATE INDEX idx_teams_is_active ON teams(is_active);
CREATE INDEX idx_teams_created_by ON teams(created_by);

CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_categories_parent_id ON categories(parent_id);
CREATE INDEX idx_categories_sort_order ON categories(sort_order);
CREATE INDEX idx_categories_is_active ON categories(is_active);

CREATE INDEX idx_links_title ON links(title);
CREATE INDEX idx_links_url ON links(url);
CREATE INDEX idx_links_creator_id ON links(creator_id);
CREATE INDEX idx_links_created_at ON links(created_at);
CREATE INDEX idx_links_is_active ON links(is_active);
CREATE INDEX idx_links_is_public ON links(is_public);
CREATE INDEX idx_links_click_count ON links(click_count);

CREATE INDEX idx_tags_name ON tags(name);

-- Infrastructure indexes
CREATE INDEX idx_assets_asset_tag ON assets(asset_tag);
CREATE INDEX idx_assets_serial_number ON assets(serial_number);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_assets_location_id ON assets(location_id);
CREATE INDEX idx_assets_vendor_id ON assets(vendor_id);
CREATE INDEX idx_assets_asset_type_id ON assets(asset_type_id);

CREATE INDEX idx_licenses_software ON licenses(software);
CREATE INDEX idx_licenses_expiry_date ON licenses(expiry_date);
CREATE INDEX idx_licenses_vendor_id ON licenses(vendor_id);

CREATE INDEX idx_support_contracts_status ON support_contracts(status);
CREATE INDEX idx_support_contracts_end_date ON support_contracts(end_date);
CREATE INDEX idx_support_contracts_vendor_id ON support_contracts(vendor_id);

CREATE INDEX idx_maintenance_log_asset_id ON maintenance_log(asset_id);
CREATE INDEX idx_maintenance_log_priority ON maintenance_log(priority);
CREATE INDEX idx_maintenance_log_scheduled_date ON maintenance_log(scheduled_date);

-- Association table indexes
CREATE INDEX idx_user_team_role ON user_team(role);
CREATE INDEX idx_user_team_joined_at ON user_team(joined_at);

-- App config indexes
CREATE INDEX idx_app_config_key ON app_config(key);
CREATE INDEX idx_app_config_category ON app_config(category);

-- Audit log indexes
CREATE INDEX idx_audit_log_table_record ON audit_log(table_name, record_id);
CREATE INDEX idx_audit_log_changed_at ON audit_log(changed_at);
CREATE INDEX idx_audit_log_changed_by ON audit_log(changed_by);

-- Full-text search indexes
CREATE INDEX idx_links_fulltext ON links USING gin(to_tsvector('english', title || ' ' || COALESCE(description, '')));
CREATE INDEX idx_assets_fulltext ON assets USING gin(to_tsvector('english', name || ' ' || COALESCE(description, '')));

-- ==========================================
-- TRIGGERS for automatic timestamp updates
-- ==========================================

-- Function to update timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to tables with updated_at column
CREATE TRIGGER trigger_users_update_timestamp
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_teams_update_timestamp
    BEFORE UPDATE ON teams
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_categories_update_timestamp
    BEFORE UPDATE ON categories
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_links_update_timestamp
    BEFORE UPDATE ON links
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_app_config_update_timestamp
    BEFORE UPDATE ON app_config
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_assets_update_timestamp
    BEFORE UPDATE ON assets
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_licenses_update_timestamp
    BEFORE UPDATE ON licenses
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_support_contracts_update_timestamp
    BEFORE UPDATE ON support_contracts
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_maintenance_log_update_timestamp
    BEFORE UPDATE ON maintenance_log
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_locations_update_timestamp
    BEFORE UPDATE ON locations
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_vendors_update_timestamp
    BEFORE UPDATE ON vendors
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- ==========================================
-- VIEWS for common queries
-- ==========================================

-- User statistics view
CREATE VIEW v_user_stats AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.first_name,
    u.last_name,
    u.is_admin,
    u.is_active,
    u.created_at,
    u.last_login,
    u.login_count,
    COUNT(DISTINCT ut.team_id) as team_count,
    COUNT(DISTINCT l.id) as link_count,
    COUNT(DISTINCT a.id) as asset_count
FROM users u
LEFT JOIN user_team ut ON u.id = ut.user_id
LEFT JOIN links l ON u.id = l.creator_id AND l.is_active = TRUE
LEFT JOIN assets a ON u.id = a.created_by
GROUP BY u.id, u.username, u.email, u.first_name, u.last_name, u.is_admin, u.is_active, u.created_at, u.last_login, u.login_count;

-- Team statistics view
CREATE VIEW v_team_stats AS
SELECT 
    t.id,
    t.name,
    t.description,
    t.color,
    t.created_at,
    t.is_active,
    COUNT(DISTINCT ut.user_id) as member_count,
    COUNT(DISTINCT lt.link_id) as link_count,
    COUNT(DISTINCT CASE WHEN ut.role = 2 THEN ut.user_id END) as admin_count
FROM teams t
LEFT JOIN user_team ut ON t.id = ut.team_id
LEFT JOIN link_team lt ON t.id = lt.team_id
GROUP BY t.id, t.name, t.description, t.color, t.created_at, t.is_active;

-- Category statistics view
CREATE VIEW v_category_stats AS
SELECT 
    c.id,
    c.name,
    c.description,
    c.parent_id,
    c.sort_order,
    c.color,
    c.icon,
    c.is_active,
    COUNT(DISTINCT lc.link_id) as link_count,
    COUNT(DISTINCT sub.id) as subcategory_count
FROM categories c
LEFT JOIN link_category lc ON c.id = lc.category_id
LEFT JOIN links l ON lc.link_id = l.id AND l.is_active = TRUE
LEFT JOIN categories sub ON c.id = sub.parent_id AND sub.is_active = TRUE
GROUP BY c.id, c.name, c.description, c.parent_id, c.sort_order, c.color, c.icon, c.is_active;

-- Asset statistics view
CREATE VIEW v_asset_stats AS
SELECT 
    at.id as asset_type_id,
    at.name as asset_type_name,
    COUNT(a.id) as total_assets,
    COUNT(CASE WHEN a.status = 'ACTIVE' THEN 1 END) as active_assets,
    COUNT(CASE WHEN a.status = 'MAINTENANCE' THEN 1 END) as maintenance_assets,
    COUNT(CASE WHEN a.status = 'DECOMMISSIONED' THEN 1 END) as decommissioned_assets,
    AVG(a.value) as avg_value,
    SUM(a.value) as total_value
FROM asset_types at
LEFT JOIN assets a ON at.id = a.asset_type_id
GROUP BY at.id, at.name;

-- ==========================================
-- FUNCTIONS for common operations
-- ==========================================

-- Function to get user role in team
CREATE OR REPLACE FUNCTION get_user_role_in_team(user_id_param INTEGER, team_id_param INTEGER)
RETURNS INTEGER AS $$
DECLARE
    user_role INTEGER;
BEGIN
    SELECT role INTO user_role
    FROM user_team
    WHERE user_id = user_id_param AND team_id = team_id_param;
    
    RETURN COALESCE(user_role, -1); -- -1 means not in team
END;
$$ LANGUAGE plpgsql;

-- Function to count links by user
CREATE OR REPLACE FUNCTION count_user_links(user_id_param INTEGER)
RETURNS INTEGER AS $$
DECLARE
    link_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO link_count
    FROM links
    WHERE creator_id = user_id_param AND is_active = TRUE;
    
    RETURN COALESCE(link_count, 0);
END;
$$ LANGUAGE plpgsql;

-- Function to check expiring licenses
CREATE OR REPLACE FUNCTION get_expiring_licenses(days_ahead INTEGER DEFAULT 30)
RETURNS TABLE(
    id INTEGER,
    name VARCHAR,
    software VARCHAR,
    expiry_date DATE,
    days_until_expiry INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        l.id,
        l.name,
        l.software,
        l.expiry_date,
        (l.expiry_date - CURRENT_DATE)::INTEGER as days_until_expiry
    FROM licenses l
    WHERE l.expiry_date IS NOT NULL 
    AND l.expiry_date <= CURRENT_DATE + INTERVAL '%s days' % days_ahead
    AND l.expiry_date >= CURRENT_DATE
    ORDER BY l.expiry_date ASC;
END;
$$ LANGUAGE plpgsql;

-- Function to check assets without maintenance
CREATE OR REPLACE FUNCTION get_assets_needing_maintenance()
RETURNS TABLE(
    asset_id INTEGER,
    asset_name VARCHAR,
    last_maintenance_date TIMESTAMP,
    days_since_maintenance INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.name,
        MAX(ml.completed_date) as last_maintenance_date,
        COALESCE(CURRENT_DATE - MAX(ml.completed_date)::DATE, 365) as days_since_maintenance
    FROM assets a
    LEFT JOIN maintenance_log ml ON a.id = ml.asset_id AND ml.completed_date IS NOT NULL
    WHERE a.status = 'ACTIVE'
    GROUP BY a.id, a.name
    HAVING COALESCE(CURRENT_DATE - MAX(ml.completed_date)::DATE, 365) > 90
    ORDER BY days_since_maintenance DESC;
END;
$$ LANGUAGE plpgsql;

-- ==========================================
-- INITIAL DATA
-- ==========================================

-- Insert default app configuration
INSERT INTO app_config (key, value, description, category, is_sensitive) VALUES
-- General settings
('APP_NAME', 'LinkMGT', 'Nazwa aplikacji', 'general', FALSE),
('APP_VERSION', '2.0.0', 'Wersja aplikacji', 'general', FALSE),
('ENABLE_USER_REGISTRATION', 'true', 'Czy włączyć rejestrację użytkowników', 'auth', FALSE),
('DEFAULT_THEME', 'light', 'Domyślny motyw interfejsu', 'ui', FALSE),
('MAX_LINKS_PER_USER', '100', 'Maksymalna liczba linków na użytkownika', 'limits', FALSE),

-- Authentication settings
('AUTH_USE_AD', 'false', 'Używaj uwierzytelniania Active Directory', 'auth', FALSE),
('AUTH_ALLOW_REGISTRATION', 'true', 'Zezwalaj na rejestrację użytkowników', 'auth', FALSE),
('AUTH_AD_FALLBACK', 'true', 'Fallback do bazy danych jeśli AD nie działa', 'auth', FALSE),
('PASSWORD_MIN_LENGTH', '8', 'Minimalna długość hasła', 'auth', FALSE),
('LOGIN_ATTEMPTS_LIMIT', '5', 'Maksymalna liczba prób logowania', 'auth', FALSE),

-- Network settings
('HTTP_PORT', '5000', 'Port HTTP dla aplikacji', 'network', FALSE),
('HTTPS_ENABLED', 'false', 'Włącz HTTPS', 'network', FALSE),
('HTTPS_PORT', '5443', 'Port HTTPS dla aplikacji', 'network', FALSE),
('SSL_CERT_PATH', 'certificate/cert.pem', 'Ścieżka do certyfikatu SSL', 'network', FALSE),
('SSL_KEY_PATH', 'certificate/key.pem', 'Ścieżka do klucza prywatnego SSL', 'network', FALSE),

-- Database settings
('DATABASE_TYPE', 'postgresql', 'Typ bazy danych', 'database', FALSE),
('DATABASE_BACKUP_ENABLED', 'true', 'Włącz automatyczne kopie zapasowe', 'database', FALSE),
('DATABASE_BACKUP_RETENTION_DAYS', '30', 'Dni przechowywania kopii zapasowych', 'database', FALSE),

-- Application limits
('MAX_UPLOAD_SIZE', '10485760', 'Maksymalny rozmiar pliku (10MB)', 'limits', FALSE),
('SESSION_TIMEOUT', '43200', 'Timeout sesji w sekundach (12 godzin)', 'limits', FALSE),
('API_RATE_LIMIT', '1000', 'Limit zapytań API na godzinę', 'limits', FALSE);

-- Insert default admin user
INSERT INTO users (username, email, password_hash, first_name, last_name, is_admin, is_active) VALUES
('admin', 'admin@linkmgt.com', 'pbkdf2:sha256:600000$salt$hash', 'Administrator', 'Systemu', TRUE, TRUE);

-- Insert demo user
INSERT INTO users (username, email, password_hash, first_name, last_name, is_admin, is_active) VALUES
('demo', 'demo@linkmgt.com', 'pbkdf2:sha256:600000$salt$hash', 'Demo', 'User', FALSE, TRUE);

-- Insert default asset types
INSERT INTO asset_types (name, description, icon, color) VALUES
('Server', 'Serwery fizyczne i wirtualne', 'fas fa-server', '#3b82f6'),
('Network Equipment', 'Urządzenia sieciowe', 'fas fa-network-wired', '#10b981'),
('Workstation', 'Stacje robocze', 'fas fa-desktop', '#f59e0b'),
('Laptop', 'Laptopy służbowe', 'fas fa-laptop', '#8b5cf6'),
('Mobile Device', 'Urządzenia mobilne', 'fas fa-mobile-alt', '#ef4444'),
('Storage', 'Urządzenia przechowywania danych', 'fas fa-hdd', '#6b7280'),
('Security', 'Urządzenia bezpieczeństwa', 'fas fa-shield-alt', '#dc2626');

-- Insert default locations
INSERT INTO locations (name, address, city, country, postal_code) VALUES
('Centrum Danych Główne', 'ul. Serwerowa 1', 'Warszawa', 'Polska', '00-001'),
('Biuro Główne', 'ul. Biurowa 10', 'Kraków', 'Polska', '30-001'),
('Oddział Północny', 'ul. Północna 5', 'Gdańsk', 'Polska', '80-001'),
('Oddział Zachodni', 'ul. Zachodnia 15', 'Wrocław', 'Polska', '50-001');

-- Insert default vendors
INSERT INTO vendors (name, contact_person, email, phone, city, country, website) VALUES
('Dell Technologies', 'Jan Kowalski', 'kontakt@dell.com', '+48 22 123 4567', 'Warszawa', 'Polska', 'https://www.dell.com'),
('HP Inc.', 'Anna Nowak', 'info@hp.com', '+48 22 234 5678', 'Warszawa', 'Polska', 'https://www.hp.com'),
('Cisco Systems', 'Piotr Wiśniewski', 'poland@cisco.com', '+48 22 345 6789', 'Warszawa', 'Polska', 'https://www.cisco.com'),
('Microsoft', 'Maria Kowalczyk', 'support@microsoft.com', '+48 22 456 7890', 'Warszawa', 'Polska', 'https://www.microsoft.com'),
('VMware', 'Tomasz Nowicki', 'info@vmware.com', '+48 22 567 8901', 'Warszawa', 'Polska', 'https://www.vmware.com');

-- Insert default teams
INSERT INTO teams (name, description, color, created_by) VALUES
('IT Infrastructure', 'Zespół zarządzający infrastrukturą IT', '#007bff', 1),
('Development', 'Zespół programistów', '#28a745', 1),
('Security', 'Zespół bezpieczeństwa IT', '#dc3545', 1),
('Network Operations', 'Zespół operacyjny sieci', '#ffc107', 1);

-- Insert default categories
INSERT INTO categories (name, description, color, icon, sort_order, created_by) VALUES
('Dokumentacja', 'Dokumenty, instrukcje i przewodniki', '#3b82f6', 'fas fa-book', 1, 1),
('Narzędzia deweloperskie', 'Narzędzia do rozwoju oprogramowania', '#10b981', 'fas fa-code', 2, 1),
('Monitorowanie', 'Systemy monitorowania infrastruktury', '#f59e0b', 'fas fa-chart-line', 3, 1),
('Bezpieczeństwo', 'Narzędzia i zasoby bezpieczeństwa', '#ef4444', 'fas fa-shield-alt', 4, 1),
('Zarządzanie', 'Narzędzia zarządzania systemami', '#8b5cf6', 'fas fa-cogs', 5, 1);

-- Insert default tags
INSERT INTO tags (name, color) VALUES
('ważne', '#dc2626'),
('nowe', '#16a34a'),
('dokumentacja', '#2563eb'),
('narzędzie', '#9333ea'),
('zewnętrzne', '#ea580c'),
('internal', '#64748b'),
('api', '#0ea5e9'),
('dashboard', '#f59e0b');

-- Insert default links
INSERT INTO links (title, url, description, creator_id, is_public) VALUES
('Google', 'https://www.google.com', 'Wyszukiwarka Google', 1, TRUE),
('GitHub', 'https://github.com', 'Platforma do hostowania kodu', 1, TRUE),
('Stack Overflow', 'https://stackoverflow.com', 'Forum programistyczne', 1, TRUE),
('PostgreSQL Documentation', 'https://www.postgresql.org/docs/', 'Oficjalna dokumentacja PostgreSQL', 1, FALSE),
('Docker Hub', 'https://hub.docker.com', 'Rejestr kontenerów Docker', 1, FALSE);

-- Add admin to all teams as admin
INSERT INTO user_team (user_id, team_id, role) VALUES
(1, 1, 2), -- IT Infrastructure
(1, 2, 2), -- Development
(1, 3, 2), -- Security
(1, 4, 2); -- Network Operations

-- Add demo user to development team
INSERT INTO user_team (user_id, team_id, role) VALUES
(2, 2, 0); -- Development as regular user

-- ==========================================
-- PERMISSIONS AND SECURITY
-- ==========================================

-- Create roles for different access levels
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'linkmgt_reader') THEN
        CREATE ROLE linkmgt_reader;
    END IF;
    
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'linkmgt_editor') THEN
        CREATE ROLE linkmgt_editor;
    END IF;
    
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'linkmgt_admin') THEN
        CREATE ROLE linkmgt_admin;
    END IF;
END $$;

-- Grant permissions to reader role
GRANT SELECT ON ALL TABLES IN SCHEMA public TO linkmgt_reader;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO linkmgt_reader;

-- Grant permissions to editor role
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO linkmgt_editor;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO linkmgt_editor;

-- Grant permissions to admin role
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO linkmgt_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO linkmgt_admin;

-- Update statistics
ANALYZE;

-- Add comments
COMMENT ON DATABASE linkmgt IS 'LinkMGT - Comprehensive IT Management System';
COMMENT ON TABLE users IS 'System users with authentication and role management';
COMMENT ON TABLE teams IS 'Project teams for organizing users and resources';
COMMENT ON TABLE categories IS 'Hierarchical categories for organizing links';
COMMENT ON TABLE links IS 'Web links with metadata and access tracking';
COMMENT ON TABLE assets IS 'IT assets and infrastructure components';
COMMENT ON TABLE licenses IS 'Software licenses and subscriptions';
COMMENT ON TABLE support_contracts IS 'Support and maintenance contracts';
COMMENT ON TABLE maintenance_log IS 'Asset maintenance history and scheduling';
COMMENT ON TABLE audit_log IS 'System audit trail for all changes';

-- Success message
DO $$
BEGIN
    RAISE NOTICE '===========================================';
    RAISE NOTICE 'LinkMGT Database Schema Creation Complete!';
    RAISE NOTICE '===========================================';
    RAISE NOTICE 'Created tables: % ', (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public');
    RAISE NOTICE 'Created indexes: % ', (SELECT count(*) FROM pg_indexes WHERE schemaname = 'public');
    RAISE NOTICE 'Created views: % ', (SELECT count(*) FROM information_schema.views WHERE table_schema = 'public');
    RAISE NOTICE 'Created functions: % ', (SELECT count(*) FROM information_schema.routines WHERE routine_schema = 'public');
    RAISE NOTICE '';
    RAISE NOTICE 'Default credentials:';
    RAISE NOTICE 'Admin: admin / admin123 (update password hash before use)';
    RAISE NOTICE 'Demo:  demo / demo123 (update password hash before use)';
    RAISE NOTICE '';
    RAISE NOTICE 'Next steps:';
    RAISE NOTICE '1. Update default password hashes';
    RAISE NOTICE '2. Create application database user';
    RAISE NOTICE '3. Configure SSL certificates if using HTTPS';
    RAISE NOTICE '4. Review and adjust configuration in app_config table';
    RAISE NOTICE '===========================================';
END $$;

# Database Setup Guide for LinkMGT

This directory contains SQL scripts for setting up LinkMGT with different database systems.

## Supported Databases

- PostgreSQL 12+
- Oracle Database 19c+
- MariaDB 10.5+ / MySQL 8.0+

## PostgreSQL Setup

### Prerequisites
```bash
# Install PostgreSQL and create database
sudo apt-get install postgresql postgresql-contrib
sudo -u postgres createdb linkmgt
```

### Installation
```bash
# Run as postgres user
sudo -u postgres psql -d linkmgt -f postgresql/create_database.sql
```

### Environment Variables
```bash
export POSTGRES_HOST=localhost
export POSTGRES_PORT=5432
export POSTGRES_DB=linkmgt
export POSTGRES_USER=postgres
export POSTGRES_PASSWORD=your_password
```

## Oracle Database Setup

### Prerequisites
```sql
-- Connect as SYSDBA
sqlplus sys/password@localhost:1521/XE as sysdba

-- Create tablespace
CREATE TABLESPACE linkmgt_data
  DATAFILE 'linkmgt_data.dbf' SIZE 100M
  AUTOEXTEND ON NEXT 10M MAXSIZE 1G;

-- Create user
CREATE USER linkmgt IDENTIFIED BY your_password
  DEFAULT TABLESPACE linkmgt_data
  QUOTA UNLIMITED ON linkmgt_data;

-- Grant privileges
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, 
      CREATE PROCEDURE, CREATE TRIGGER, CREATE SEQUENCE TO linkmgt;
```

### Installation
```bash
# Run as linkmgt user
sqlplus linkmgt/password@localhost:1521/XE @oracle/create_database.sql
```

### Environment Variables
```bash
export ORACLE_HOST=localhost
export ORACLE_PORT=1521
export ORACLE_SERVICE=XEPDB1
export ORACLE_USER=linkmgt
export ORACLE_PASSWORD=your_password
```

## MariaDB/MySQL Setup

### Prerequisites
```bash
# Install MariaDB
sudo apt-get install mariadb-server
sudo mysql_secure_installation

# Create database
mysql -u root -p -e "CREATE DATABASE linkmgt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```

### Installation
```bash
# Run the script
mysql -u root -p < mariadb/create_database.sql
```

### Environment Variables
```bash
export MARIADB_HOST=localhost
export MARIADB_PORT=3306
export MARIADB_DB=linkmgt
export MARIADB_USER=root
export MARIADB_PASSWORD=your_password
```

## Application Configuration

Update your Flask application configuration:

```python
# config.py
import os
from database.config import DatabaseConfig

class Config:
    # Choose your database type
    DB_TYPE = os.environ.get('DATABASE_TYPE', 'postgresql')
    
    # Get database configuration
    db_config = DatabaseConfig.get_sqlalchemy_config(DB_TYPE)
    
    SQLALCHEMY_DATABASE_URI = db_config['SQLALCHEMY_DATABASE_URI']
    SQLALCHEMY_TRACK_MODIFICATIONS = db_config['SQLALCHEMY_TRACK_MODIFICATIONS']
    SQLALCHEMY_ENGINE_OPTIONS = db_config['SQLALCHEMY_ENGINE_OPTIONS']
```

## Required Python Packages

Add to your requirements.txt:

```
# PostgreSQL
psycopg2-binary>=2.9.0

# Oracle
cx-Oracle>=8.3.0

# MariaDB/MySQL
PyMySQL>=1.0.0
```

## Default Credentials

After installation, use these default credentials:
- Username: `admin`
- Password: `admin123`

**Important**: Change the default password immediately after first login!

## Troubleshooting

### PostgreSQL
- Ensure PostgreSQL service is running
- Check pg_hba.conf for authentication settings
- Verify firewall settings for port 5432

### Oracle
- Ensure Oracle service is running
- Check listener.ora configuration
- Verify TNS names and connection strings

### MariaDB/MySQL
- Ensure MariaDB service is running
- Check bind-address in my.cnf
- Verify user privileges and connection limits

## Performance Tuning

### PostgreSQL
```sql
-- Recommended settings for production
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
SELECT pg_reload_conf();
```

### Oracle
```sql
-- Recommended settings
ALTER SYSTEM SET db_cache_size = 256M;
ALTER SYSTEM SET shared_pool_size = 128M;
ALTER SYSTEM SET pga_aggregate_target = 256M;
```

### MariaDB
```ini
# Add to my.cnf
[mysqld]
innodb_buffer_pool_size = 256M
query_cache_size = 32M
tmp_table_size = 32M
max_heap_table_size = 32M
```
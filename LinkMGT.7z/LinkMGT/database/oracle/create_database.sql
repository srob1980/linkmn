-- Oracle database schema for LinkMGT

-- Create tablespace
CREATE TABLESPACE linkmgt_data
  DATAFILE 'linkmgt_data.dbf' SIZE 100M
  AUTOEXTEND ON NEXT 50M MAXSIZE UNLIMITED;

-- Create user/schema
CREATE USER linkmgt IDENTIFIED BY linkmgt_password
  DEFAULT TABLESPACE linkmgt_data
  QUOTA UNLIMITED ON linkmgt_data;

-- Grant privileges
GRANT CONNECT, RESOURCE, CREATE VIEW, CREATE SYNONYM TO linkmgt;

-- Connect to the schema
CONNECT linkmgt/linkmgt_password;

-- Users table
CREATE TABLE users (
  id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  username VARCHAR2(64) NOT NULL UNIQUE,
  email VARCHAR2(120) NOT NULL UNIQUE,
  password_hash VARCHAR2(255) NOT NULL,
  first_name VARCHAR2(50),
  last_name VARCHAR2(50),
  ad_dn VARCHAR2(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP,
  is_active NUMBER(1) DEFAULT 1,
  is_admin NUMBER(1) DEFAULT 0,
  login_count NUMBER DEFAULT 0,
  failed_login_attempts NUMBER DEFAULT 0,
  locked_until TIMESTAMP
);

-- Teams table
CREATE TABLE teams (
  id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name VARCHAR2(64) NOT NULL,
  description CLOB,
  color VARCHAR2(7) DEFAULT '#007bff',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active NUMBER(1) DEFAULT 1,
  created_by NUMBER REFERENCES users(id)
);

-- User-Team association table
CREATE TABLE user_team (
  user_id NUMBER REFERENCES users(id) ON DELETE CASCADE,
  team_id NUMBER REFERENCES teams(id) ON DELETE CASCADE,
  role NUMBER DEFAULT 0,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, team_id)
);

-- Categories table
CREATE TABLE categories (
  id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name VARCHAR2(64) NOT NULL,
  description CLOB,
  parent_id NUMBER REFERENCES categories(id),
  color VARCHAR2(7) DEFAULT '#2563eb',
  icon VARCHAR2(50) DEFAULT 'fas fa-folder',
  sort_order NUMBER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active NUMBER(1) DEFAULT 1,
  created_by NUMBER REFERENCES users(id)
);

-- Tags table
CREATE TABLE tags (
  id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name VARCHAR2(32) NOT NULL UNIQUE,
  color VARCHAR2(7) DEFAULT '#64748b',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Links table
CREATE TABLE links (
  id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title VARCHAR2(100) NOT NULL,
  url VARCHAR2(500) NOT NULL,
  description CLOB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  creator_id NUMBER REFERENCES users(id),
  is_active NUMBER(1) DEFAULT 1,
  is_public NUMBER(1) DEFAULT 0,
  last_accessed TIMESTAMP,
  favicon_url VARCHAR2(500),
  status_code NUMBER DEFAULT 200,
  last_checked TIMESTAMP
);

-- Link-Category association table
CREATE TABLE link_category (
  link_id NUMBER REFERENCES links(id) ON DELETE CASCADE,
  category_id NUMBER REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (link_id, category_id)
);

-- Link-Tag association table
CREATE TABLE link_tag (
  link_id NUMBER REFERENCES links(id) ON DELETE CASCADE,
  tag_id NUMBER REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (link_id, tag_id)
);

-- Link-Team association table
CREATE TABLE link_team (
  link_id NUMBER REFERENCES links(id) ON DELETE CASCADE,
  team_id NUMBER REFERENCES teams(id) ON DELETE CASCADE,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (link_id, team_id)
);

-- App Configuration table
CREATE TABLE app_config (
  id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  key VARCHAR2(64) NOT NULL UNIQUE,
  value VARCHAR2(512) NOT NULL,
  description VARCHAR2(256),
  category VARCHAR2(50) DEFAULT 'general',
  is_sensitive NUMBER(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_links_creator ON links(creator_id);
CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_app_config_category ON app_config(category);

-- Create or replace updated_at trigger for users
CREATE OR REPLACE TRIGGER trg_users_updated_at
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
  :NEW.updated_at := CURRENT_TIMESTAMP;
END;
/

-- Create or replace updated_at trigger for teams
CREATE OR REPLACE TRIGGER trg_teams_updated_at
BEFORE UPDATE ON teams
FOR EACH ROW
BEGIN
  :NEW.updated_at := CURRENT_TIMESTAMP;
END;
/

-- Create or replace updated_at trigger for categories
CREATE OR REPLACE TRIGGER trg_categories_updated_at
BEFORE UPDATE ON categories
FOR EACH ROW
BEGIN
  :NEW.updated_at := CURRENT_TIMESTAMP;
END;
/

-- Create or replace updated_at trigger for links
CREATE OR REPLACE TRIGGER trg_links_updated_at
BEFORE UPDATE ON links
FOR EACH ROW
BEGIN
  :NEW.updated_at := CURRENT_TIMESTAMP;
END;
/

-- Create or replace updated_at trigger for app_config
CREATE OR REPLACE TRIGGER trg_app_config_updated_at
BEFORE UPDATE ON app_config
FOR EACH ROW
BEGIN
  :NEW.updated_at := CURRENT_TIMESTAMP;
END;
/

-- Insert default admin user with password 'admin'
INSERT INTO users (username, email, password_hash, first_name, last_name, is_admin, is_active)
VALUES ('admin', 'admin@example.com', 
        'pbkdf2:sha256:150000$FVsNzmT2$9d78ce24733d37ec25ae8f78b2c82d6a80c7494467adc3229ac8b598c46a28e8',
        'Admin', 'User', 1, 1);

-- Insert default application configuration
INSERT INTO app_config (key, value, description, category)
VALUES ('APP_NAME', 'LinkMGT', 'Application name', 'general');

INSERT INTO app_config (key, value, description, category)
VALUES ('APP_VERSION', '1.0.0', 'Application version', 'general');

INSERT INTO app_config (key, value, description, category)
VALUES ('ENABLE_REGISTRATION', 'true', 'Allow new user registration', 'security');

INSERT INTO app_config (key, value, description, category)
VALUES ('ALLOW_PASSWORD_RESET', 'true', 'Allow users to reset passwords', 'security');

COMMIT;

-- Show created tables
SELECT table_name FROM user_tables ORDER BY table_name;
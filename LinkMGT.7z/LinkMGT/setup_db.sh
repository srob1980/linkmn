#!/bin/bash
# filepath: d:\Projekty\LinkMGT\setup_db.sh

echo "Konfiguracja bazy danych LinkMGT"
echo "================================"

echo ""
echo "1. Tworzenie nowej bazy danych..."
python init_db.py

echo ""
echo "2. Inicjalizacja migracji..."
flask db init

echo ""
echo "3. Tworzenie pierwszej migracji..."
flask db migrate -m "Początkowa migracja - tabele podstawowe i infrastruktura"

echo ""
echo "4. Wykonywanie migracji..."
flask db upgrade

echo ""
echo "✅ Konfiguracja bazy danych zakończona!"
echo ""
echo "Domyślne konta:"
echo "- Administrator: admin / admin123"
echo "- Demo: demo / demo123"
echo ""
import os
import sys

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def setup_application():
    """Kompletne skonfigurowanie aplikacji"""
    
    try:
        print("🚀 Konfigurowanie aplikacji LinkMGT...")
        
        # Import aplikacji
        from app import create_app, db
        from app.config import config
        
        # Utwórz aplikację
        app = create_app(config['development'])
        
        with app.app_context():
            print("📦 Tworzenie tabel w bazie danych...")
            db.create_all()
            
            # Import modeli
            from app.models import User, Team, Category, Link, AppConfig, UserTeam, AuditLog
            
            # Sprawdź czy admin już istnieje
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                print("👤 Tworzenie konta administratora...")
                admin = User(
                    username='admin',
                    email='admin@linkmgt.local',
                    first_name='Administrator',
                    last_name='Systemu',
                    is_admin=True,
                    is_active=True
                )
                admin.set_password('admin123')
                db.session.add(admin)
                db.session.commit()
                print("✅ Utworzono konto administratora: admin/admin123")
            
            # Sprawdź czy istnieją podstawowe konfiguracje
            configs_needed = [
                ('APP_NAME', 'LinkMGT', 'Nazwa aplikacji'),
                ('APP_VERSION', '1.0.0', 'Wersja aplikacji'),
                ('DATABASE_TYPE', 'postgresql', 'Typ bazy danych'),
                ('HTTP_PORT', '5000', 'Port HTTP'),
                ('HTTPS_ENABLED', 'false', 'Włącz HTTPS'),
            ]
            
            print("⚙️ Konfigurowanie ustawień podstawowych...")
            for key, value, description in configs_needed:
                existing = AppConfig.query.filter_by(key=key).first()
                if not existing:
                    config_item = AppConfig(key=key, value=value, description=description)
                    db.session.add(config_item)
            
            db.session.commit()
            
            print("✅ Aplikacja została pomyślnie skonfigurowana!")
            print("\n📋 Dane logowania:")
            print("Administrator: admin / admin123")
            print("\n🔗 Uruchom aplikację używając: python run.py")
            
            return True
            
    except Exception as e:
        print(f"❌ Błąd podczas konfiguracji: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = setup_application()
    if not success:
        sys.exit(1)

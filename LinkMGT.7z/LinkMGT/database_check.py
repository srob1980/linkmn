import os
import sys
import platform
import importlib.util

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def check_database_drivers():
    """Check available database drivers"""
    print("=== Database Driver Check ===")
    
    # Check SQLite
    try:
        import sqlite3
        print(f"✅ SQLite: {sqlite3.sqlite_version}")
    except ImportError:
        print("❌ SQLite not available")
    
    # Check PostgreSQL
    try:
        import psycopg2
        print(f"✅ PostgreSQL (psycopg2): {psycopg2.__version__}")
    except ImportError:
        print("❌ PostgreSQL driver (psycopg2) not available")
        print("   Run: pip install psycopg2-binary")
    
    # Check MySQL/MariaDB
    try:
        import pymysql
        print(f"✅ MySQL/MariaDB (PyMySQL): {pymysql.__version__}")
    except ImportError:
        print("❌ MySQL driver (PyMySQL) not available")
    
    print("\n=== Environment ===")
    print(f"Python: {sys.version}")
    print(f"Platform: {platform.platform()}")
    
    # Check for DLL directories in PATH (Windows only)
    if platform.system() == 'Windows':
        print("\n=== Windows DLL Paths ===")
        paths = os.environ.get('PATH', '').split(os.pathsep)
        for path in paths:
            if os.path.exists(path) and any(f.lower().endswith('.dll') for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))):
                print(f"DLL Path: {path}")
    
    # Check database connection
    from dotenv import load_dotenv
    load_dotenv()
    
    print("\n=== Database Connection Test ===")
    db_url = os.environ.get('DATABASE_URL')
    if db_url:
        print(f"Database URL is set: {db_url.split('@')[0].split(':')[0]}:***@{db_url.split('@')[1] if '@' in db_url else db_url}")
        
        # Test PostgreSQL connection
        if db_url.startswith('postgresql'):
            try:
                import psycopg2
                conn_params = {}
                for param in db_url.split('//')[1].split('/')[0].split('@')[1].split(':'):
                    if '=' in param:
                        key, value = param.split('=')
                        conn_params[key] = value
                
                # Extract connection details from URL
                if '@' in db_url:
                    userpass, hostport = db_url.split('//')[1].split('/')[0].split('@')
                    username, password = userpass.split(':')
                    if ':' in hostport:
                        host, port = hostport.split(':')
                    else:
                        host, port = hostport, '5432'
                    dbname = db_url.split('/')[-1]
                    
                    print(f"Connecting to PostgreSQL at {host}:{port}...")
                    conn = psycopg2.connect(
                        dbname=dbname,
                        user=username,
                        password=password,
                        host=host,
                        port=port
                    )
                    conn.close()
                    print("✅ PostgreSQL connection successful!")
                else:
                    print("❌ Invalid PostgreSQL connection URL format")
            except Exception as e:
                print(f"❌ PostgreSQL connection failed: {e}")
        elif db_url.startswith('sqlite'):
            try:
                import sqlite3
                db_path = db_url.replace('sqlite:///', '')
                print(f"Connecting to SQLite at {db_path}...")
                conn = sqlite3.connect(db_path)
                conn.close()
                print("✅ SQLite connection successful!")
            except Exception as e:
                print(f"❌ SQLite connection failed: {e}")
    else:
        print("❌ DATABASE_URL environment variable not set")

if __name__ == "__main__":
    check_database_drivers()

from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectMultipleField, BooleanField, SubmitField, SelectField
from wtforms.validators import DataRequired, URL, Length, Optional
from flask_login import current_user
from flask_wtf.file import FileField, FileAllowed

class LinkForm(FlaskForm):
    """Formularz do tworzenia i edycji linków"""
    title = StringField('Tytuł', validators=[DataRequired(), Length(max=100)])
    url = StringField('URL', validators=[DataRequired(), URL(), Length(max=500)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=1000)])
    
    categories = SelectMultipleField('Kategorie', coerce=int)
    teams = SelectMultipleField('Zespoły', coerce=int)
    
    is_public = BooleanField('Publiczny', default=False)
    is_active = BooleanField('Aktywny', default=True)
    
    submit = SubmitField('Zapisz')
    
    def __init__(self, *args, **kwargs):
        super(LinkForm, self).__init__(*args, **kwargs)
        
        # Pobierz dostępne kategorie
        from app.models import Category
        self.categories.choices = [(c.id, c.name) for c in Category.query.filter_by(is_active=True).order_by(Category.name).all()]
        
        # Pobierz zespoły do których należy użytkownik
        from app.models import Team
        if current_user.is_admin:
            # Administrator widzi wszystkie zespoły
            self.teams.choices = [(t.id, t.name) for t in Team.query.filter_by(is_active=True).order_by(Team.name).all()]
        else:
            # Zwykły użytkownik widzi tylko swoje zespoły
            self.teams.choices = [(t.id, t.name) for t in current_user.teams if t.is_active]

class LinkImportForm(FlaskForm):
    """Formularz do importu linków"""
    file = FileField('Plik CSV/JSON', validators=[
        DataRequired(),
        FileAllowed(['csv', 'json'], 'Tylko pliki CSV lub JSON!')
    ])
    default_category = SelectField('Domyślna kategoria', coerce=int)
    is_public = BooleanField('Ustawić jako publiczne', default=False)
    
    submit = SubmitField('Importuj')
    
    def __init__(self, *args, **kwargs):
        super(LinkImportForm, self).__init__(*args, **kwargs)
        
        # Pobierz dostępne kategorie
        from app.models import Category
        self.default_category.choices = [(0, '-- Brak --')] + [(c.id, c.name) for c in Category.query.filter_by(is_active=True).order_by(Category.name).all()]

from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.links import bp
from app.links.forms import LinkForm, LinkImportForm
from app.models import Link, Category, Team, Tag
from app import db
from sqlalchemy import desc, or_
import csv
import json
import io

@bp.route('/')
@login_required
def index():
    """Lista linków użytkownika"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    query = request.args.get('q', '')
    category_id = request.args.get('category', type=int)
    sort = request.args.get('sort', 'created_desc')
    show_public = request.args.get('public', type=int)
    
    # Buduj query
    links_query = Link.query.filter_by(is_active=True)
    
    # Filtruj po autorze
    if not current_user.is_admin:
        links_query = links_query.filter(Link.creator_id == current_user.id)
    
    # Filtruj po wyszukiwaniu
    if query:
        links_query = links_query.filter(
            or_(
                Link.title.ilike(f'%{query}%'),
                Link.url.ilike(f'%{query}%'),
                Link.description.ilike(f'%{query}%')
            )
        )
    
    # Filtruj po kategorii
    if category_id:
        links_query = links_query.join(Link.categories).filter(Category.id == category_id)
    
    # Filtruj po publicznych
    if show_public:
        links_query = links_query.filter(Link.is_public == True)
    
    # Sortowanie
    if sort == 'created_asc':
        links_query = links_query.order_by(Link.created_at)
    elif sort == 'title_asc':
        links_query = links_query.order_by(Link.title)
    elif sort == 'title_desc':
        links_query = links_query.order_by(desc(Link.title))
    elif sort == 'clicks_desc':
        links_query = links_query.order_by(desc(Link.click_count))
    else:  # created_desc
        links_query = links_query.order_by(desc(Link.created_at))
    
    # Paginacja
    pagination = links_query.paginate(page=page, per_page=per_page)
    links = pagination.items
    
    # Pobierz wszystkie kategorie do filtrowania
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    
    return render_template('links/index.html',
                          title='Linki',
                          links=links,
                          pagination=pagination,
                          categories=categories)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Dodaj nowy link"""
    form = LinkForm()
    
    if form.validate_on_submit():
        # Tworzenie nowego linku
        link = Link(
            title=form.title.data,
            url=form.url.data,
            description=form.description.data,
            creator_id=current_user.id,
            is_public=form.is_public.data,
            is_active=form.is_active.data
        )
        
        try:
            # Dodaj link do bazy
            db.session.add(link)
            db.session.flush()  # Generuje ID dla linku
            
            # Dodaj kategorie
            if form.categories.data:
                categories = Category.query.filter(Category.id.in_(form.categories.data)).all()
                link.categories = categories
            
            # Dodaj zespoły
            if form.teams.data:
                teams = Team.query.filter(Team.id.in_(form.teams.data)).all()
                link.teams = teams
            
            db.session.commit()
            flash('Link został pomyślnie dodany.', 'success')
            return redirect(url_for('links.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania linku: {str(e)}', 'danger')
    
    return render_template('links/create.html',
                          title='Dodaj link',
                          form=form)

@bp.route('/<int:link_id>/edit', methods=['GET', 'POST'])
@login_required
def edit(link_id):
    """Edytuj link"""
    # Pobierz link z bazy
    link = Link.query.get_or_404(link_id)
    
    # Sprawdź uprawnienia
    if not current_user.is_admin and link.creator_id != current_user.id:
        flash('Nie masz uprawnień do edycji tego linku.', 'danger')
        return redirect(url_for('links.index'))
    
    form = LinkForm(obj=link)
    
    if request.method == 'GET':
        # Pobierz aktualne kategorie i zespoły
        form.categories.data = [c.id for c in link.categories]
        
        # Handle case where teams relationship might not exist
        try:
            if hasattr(link, 'teams'):
                form.teams.data = [t.id for t in link.teams]
            else:
                form.teams.data = []
                flash('Uwaga: Relacja teams nie została znaleziona. Funkcjonalność zespołów może być ograniczona.', 'warning')
        except Exception as e:
            form.teams.data = []
            flash(f'Błąd podczas ładowania zespołów: {str(e)}', 'warning')
    
    if form.validate_on_submit():
        try:
            # Aktualizuj dane linku
            link.title = form.title.data
            link.url = form.url.data
            link.description = form.description.data
            link.is_public = form.is_public.data
            link.is_active = form.is_active.data
            
            # Aktualizuj kategorie
            categories = Category.query.filter(Category.id.in_(form.categories.data)).all()
            link.categories = categories
            
            # Aktualizuj zespoły if the relationship exists
            if hasattr(link, 'teams'):
                teams = Team.query.filter(Team.id.in_(form.teams.data)).all()
                link.teams = teams
            
            db.session.commit()
            flash('Link został pomyślnie zaktualizowany.', 'success')
            return redirect(url_for('links.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji linku: {str(e)}', 'danger')
    
    return render_template('links/edit.html',
                          title='Edytuj link',
                          form=form,
                          link=link)

@bp.route('/<int:link_id>/delete', methods=['POST'])
@login_required
def delete(link_id):
    """Usuń link"""
    link = Link.query.get_or_404(link_id)
    
    # Sprawdź uprawnienia
    if not current_user.is_admin and link.creator_id != current_user.id:
        return jsonify({'success': False, 'message': 'Nie masz uprawnień do usunięcia tego linku.'})
    
    try:
        # Oznacz link jako nieaktywny zamiast usuwać go z bazy
        link.is_active = False
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

@bp.route('/by_category/<int:category_id>')
@login_required
def by_category(category_id):
    """Wyświetl linki dla danej kategorii"""
    category = Category.query.get_or_404(category_id)
    
    # Pobierz linki z tej kategorii
    links = Link.query.join(Link.categories).filter(
        Category.id == category_id,
        Link.is_active == True
    ).order_by(desc(Link.created_at)).all()
    
    return render_template('links/by_category.html',
                          title=f'Kategoria: {category.name}',
                          category=category,
                          links=links)

@bp.route('/import', methods=['GET', 'POST'])
@login_required
def import_links():
    """Import linków z pliku CSV lub JSON"""
    form = LinkImportForm()
    
    if form.validate_on_submit():
        try:
            # Pobierz plik
            file = request.files[form.file.name]
            
            # Przetwarzaj w zależności od rozszerzenia pliku
            filename = file.filename.lower()
            links_imported = 0
            
            if filename.endswith('.csv'):
                # Przetwarzaj plik CSV
                stream = io.StringIO(file.stream.read().decode("UTF8"))
                csv_reader = csv.DictReader(stream)
                
                for row in csv_reader:
                    # Tworzenie linku
                    link = Link(
                        title=row.get('title', ''),
                        url=row.get('url', ''),
                        description=row.get('description', ''),
                        creator_id=current_user.id,
                        is_public=form.is_public.data,
                        is_active=True
                    )
                    
                    db.session.add(link)
                    db.session.flush()
                    
                    # Dodaj domyślną kategorię, jeśli jest określona
                    if form.default_category.data > 0:
                        category = Category.query.get(form.default_category.data)
                        if category:
                            link.categories.append(category)
                    
                    links_imported += 1
                
            elif filename.endswith('.json'):
                # Przetwarzaj plik JSON
                json_data = json.loads(file.read())
                
                for item in json_data:
                    # Tworzenie linku
                    link = Link(
                        title=item.get('title', ''),
                        url=item.get('url', ''),
                        description=item.get('description', ''),
                        creator_id=current_user.id,
                        is_public=form.is_public.data,
                        is_active=True
                    )
                    
                    db.session.add(link)
                    db.session.flush()
                    
                    # Dodaj domyślną kategorię, jeśli jest określona
                    if form.default_category.data > 0:
                        category = Category.query.get(form.default_category.data)
                        if category:
                            link.categories.append(category)
                    
                    links_imported += 1
            
            db.session.commit()
            flash(f'Zaimportowano {links_imported} linków.', 'success')
            return redirect(url_for('links.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas importu: {str(e)}', 'danger')
    
    return render_template('links/import.html',
                          title='Import linków',
                          form=form)

@bp.route('/export', methods=['GET'])
@login_required
def export_links():
    """Eksportuj linki do formatu JSON"""
    # Pobierz linki do eksportu
    links = Link.query.filter_by(is_active=True)
    
    # Jeśli nie admin, eksportuj tylko własne linki
    if not current_user.is_admin:
        links = links.filter_by(creator_id=current_user.id)
    
    links = links.all()
    
    # Konwertuj na słownik
    links_data = []
    for link in links:
        link_data = {
            'title': link.title,
            'url': link.url,
            'description': link.description,
            'is_public': link.is_public,
            'categories': [c.name for c in link.categories],
            'teams': [t.name for t in link.teams],
            'created_at': link.created_at.isoformat() if link.created_at else None
        }
        links_data.append(link_data)
    
    # Zwróć jako JSON
    return jsonify(links_data)

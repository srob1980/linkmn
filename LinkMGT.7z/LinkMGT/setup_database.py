import os
import sys
import argparse
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def setup_database():
    """Konfiguracja bazy danych i inicjalizacja aplikacji"""
    parser = argparse.ArgumentParser(description='Konfiguracja bazy danych LinkMGT')
    parser.add_argument('--db-type', choices=['sqlite', 'postgresql', 'mysql', 'mariadb', 'oracle'],
                        default='sqlite', help='Typ bazy danych')
    parser.add_argument('--db-host', default='localhost', help='Host bazy danych')
    parser.add_argument('--db-port', help='Port bazy danych')
    parser.add_argument('--db-name', help='Nazwa bazy danych')
    parser.add_argument('--db-user', help='Użytkownik bazy danych')
    parser.add_argument('--db-password', help='Hasło bazy danych')
    parser.add_argument('--create-schema', action='store_true', help='Utwórz schemat bazy danych')
    parser.add_argument('--load-data', action='store_true', help='Załaduj przykładowe dane')
    
    args = parser.parse_args()
    
    # Ustaw domyślne wartości w zależności od typu bazy
    if args.db_type == 'sqlite':
        if not args.db_name:
            args.db_name = 'app.db'
    else:
        if not args.db_port:
            args.db_port = {
                'postgresql': '5432',
                'mysql': '3306',
                'mariadb': '3306',
                'oracle': '1521'
            }.get(args.db_type, '')
        
        if not args.db_name:
            args.db_name = 'linkmgt'
    
    # Utwórz URL bazy danych
    if args.db_type == 'sqlite':
        db_url = f"sqlite:///{args.db_name}"
    else:
        db_url = f"{args.db_type}://{args.db_user}:{args.db_password}@{args.db_host}:{args.db_port}/{args.db_name}"
    
    # Zapisz URL do zmiennej środowiskowej
    os.environ['DATABASE_URL'] = db_url
    
    # Wyświetl informacje
    print(f"Konfiguracja bazy danych: {args.db_type}")
    print(f"URL bazy danych: {db_url.split('@')[0].split(':')[0]}:***@{db_url.split('@')[1] if '@' in db_url else db_url}")
    
    try:
        # Sprawdź połączenie
        from app.utils.db_utils import test_connection
        conn_ok, conn_msg = test_connection(db_url)
        
        if not conn_ok:
            print(f"Błąd połączenia z bazą danych: {conn_msg}")
            return False
        
        print("Połączenie z bazą danych udane!")
        
        # Utwórz schemat bazy danych jeśli potrzeba
        if args.create_schema:
            print("Tworzenie schematu bazy danych...")
            
            # Różne podejścia w zależności od typu bazy
            if args.db_type == 'sqlite':
                # Dla SQLite używamy Flask-Migrate
                from app import create_app, db
                app = create_app()
                
                with app.app_context():
                    db.create_all()
                    print("Schemat SQLite utworzony pomyślnie!")
            
            else:
                # Dla innych baz wykonujemy skrypty SQL
                script_path = f"database/{args.db_type}/create_database.sql"
                
                if os.path.exists(script_path):
                    print(f"Wykonywanie skryptu SQL: {script_path}")
                    
                    if args.db_type == 'postgresql':
                        import psycopg2
                        conn = psycopg2.connect(
                            host=args.db_host,
                            port=args.db_port,
                            user=args.db_user,
                            password=args.db_password,
                            database=args.db_name
                        )
                        
                        with conn.cursor() as cursor:
                            with open(script_path, 'r') as f:
                                cursor.execute(f.read())
                            conn.commit()
                        
                        conn.close()
                        print("Schemat PostgreSQL utworzony pomyślnie!")
                    
                    elif args.db_type in ('mysql', 'mariadb'):
                        import pymysql
                        conn = pymysql.connect(
                            host=args.db_host,
                            port=int(args.db_port),
                            user=args.db_user,
                            password=args.db_password,
                            database=args.db_name
                        )
                        
                        with conn.cursor() as cursor:
                            with open(script_path, 'r') as f:
                                for statement in f.read().split(';'):
                                    if statement.strip():
                                        cursor.execute(statement)
                            conn.commit()
                        
                        conn.close()
                        print("Schemat MySQL/MariaDB utworzony pomyślnie!")
                    
                    elif args.db_type == 'oracle':
                        try:
                            import oracledb
                            conn = oracledb.connect(
                                user=args.db_user,
                                password=args.db_password,
                                dsn=f"{args.db_host}:{args.db_port}/{args.db_name}"
                            )
                        except ImportError:
                            import cx_Oracle
                            conn = cx_Oracle.connect(
                                user=args.db_user,
                                password=args.db_password,
                                dsn=f"{args.db_host}:{args.db_port}/{args.db_name}"
                            )
                        
                        with conn.cursor() as cursor:
                            with open(script_path, 'r') as f:
                                for statement in f.read().split(';'):
                                    if statement.strip():
                                        try:
                                            cursor.execute(statement)
                                        except Exception as e:
                                            print(f"Błąd wykonania zapytania: {e}")
                            conn.commit()
                        
                        conn.close()
                        print("Schemat Oracle utworzony pomyślnie!")
                
                else:
                    print(f"Skrypt SQL nie istnieje: {script_path}")
                    return False
        
        # Załaduj przykładowe dane jeśli potrzeba
        if args.load_data:
            print("Ładowanie przykładowych danych...")
            
            from app import create_app
            from initialize_complete import initialize_application
            
            app = create_app()
            with app.app_context():
                initialize_application()
        
        print("Konfiguracja bazy danych zakończona pomyślnie!")
        return True
    
    except Exception as e:
        print(f"Błąd podczas konfiguracji bazy danych: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = setup_database()
    sys.exit(0 if success else 1)

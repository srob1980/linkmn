import os
import sys

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def fix_infrastructure_tables():
    """Napraw i uzupełnij tabele infrastruktury"""
    
    from app import create_app, db
    
    app = create_app()
    
    with app.app_context():
        from sqlalchemy import text
        
        print("🔧 Sprawdzanie i naprawianie struktury tabel infrastruktury...")
        
        try:
            # Sprawdź które tabele istnieją
            result = db.session.execute(text("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name IN ('locations', 'vendors', 'assets', 'licenses', 'support_contracts', 'maintenance_logs', 'asset_types', 'asset_statuses')
            """))
            
            existing_tables = [row[0] for row in result.fetchall()]
            print(f"Istniejące tabele: {existing_tables}")
            
            # Utworz tabele infrastruktury które nie istnieją
            tables_to_create = {
                'support_contracts': """
                    CREATE TABLE IF NOT EXISTS support_contracts (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        contract_number VARCHAR(50),
                        start_date DATE,
                        end_date DATE,
                        cost NUMERIC(10, 2),
                        description TEXT,
                        vendor_id INTEGER REFERENCES vendors(id),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """,
                'maintenance_logs': """
                    CREATE TABLE IF NOT EXISTS maintenance_logs (
                        id SERIAL PRIMARY KEY,
                        asset_id INTEGER REFERENCES assets(id) NOT NULL,
                        maintenance_type VARCHAR(50),
                        description TEXT,
                        scheduled_date TIMESTAMP,
                        completed_date TIMESTAMP,
                        completed BOOLEAN DEFAULT FALSE,
                        cost NUMERIC(10, 2),
                        performed_by INTEGER REFERENCES users(id),
                        vendor_id INTEGER REFERENCES vendors(id),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """
            }
            
            for table_name, create_sql in tables_to_create.items():
                if table_name not in existing_tables:
                    print(f"Tworzenie tabeli {table_name}...")
                    try:
                        db.session.execute(text(create_sql))
                        print(f"✅ Utworzono tabelę {table_name}")
                    except Exception as e:
                        print(f"Tabela {table_name} prawdopodobnie już istnieje: {e}")
                else:
                    print(f"Tabela {table_name} już istnieje")
            
            # Sprawdź i dodaj brakujące kolumny do istniejących tabel
            print("Sprawdzanie struktury kolumn...")
            
            # Sprawdź kolumny w tabeli locations
            if 'locations' in existing_tables:
                columns_result = db.session.execute(text("""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = 'locations' AND table_schema = 'public'
                """))
                location_columns = [row[0] for row in columns_result.fetchall()]
                
                required_columns = {
                    'postal_code': 'ALTER TABLE locations ADD COLUMN IF NOT EXISTS postal_code VARCHAR(20)',
                    'created_by': 'ALTER TABLE locations ADD COLUMN IF NOT EXISTS created_by INTEGER REFERENCES users(id)'
                }
                
                for col_name, alter_sql in required_columns.items():
                    if col_name not in location_columns:
                        try:
                            db.session.execute(text(alter_sql))
                            print(f"✅ Dodano kolumnę {col_name} do tabeli locations")
                        except Exception as e:
                            print(f"Błąd dodawania kolumny {col_name}: {e}")
            
            db.session.commit()
            print("✅ Struktura tabel infrastruktury została naprawiona!")
            
            # Teraz użyj SQLAlchemy do utworzenia pozostałych tabel
            print("Tworzenie tabel przez SQLAlchemy...")
            db.create_all()
            print("✅ Wszystkie tabele zostały utworzone/zaktualizowane!")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Błąd podczas naprawiania tabel: {e}")
            return False
    
    return True

if __name__ == '__main__':
    success = fix_infrastructure_tables()
    if success:
        print("🚀 Teraz możesz uruchomić initialize_complete.py")
    else:
        sys.exit(1)

import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def create_activity_logs_table():
    """Create activity_logs table in the database"""
    print("Creating activity_logs table...")
    
    try:
        # Import Flask app and database
        from app import create_app, db
        app = create_app()
        
        with app.app_context():
            # Check if table already exists
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            
            if 'activity_logs' not in inspector.get_table_names():
                # Create table using SQLAlchemy model
                from app.models.activity_log import ActivityLog
                
                db.create_all()
                print("Activity logs table created successfully.")
                
                # Create sample log entry
                log = ActivityLog(
                    action='system_init',
                    details='Activity logging system initialized',
                    severity='INFO'
                )
                db.session.add(log)
                db.session.commit()
                print("Created sample log entry.")
            else:
                print("Activity logs table already exists.")
                
            # Show table structure
            columns = inspector.get_columns('activity_logs')
            print("\nTable structure:")
            for column in columns:
                print(f"- {column['name']} ({column['type']})")
            
    except Exception as e:
        print(f"Error creating activity_logs table: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    return True

if __name__ == "__main__":
    create_activity_logs_table()

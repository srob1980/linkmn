from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from datetime import datetime
from flask_wtf.csrf import CSRFProtect
import os

# Create extensions first
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()
csrf = CSRFProtect()

def create_app(config_class=None):
    app = Flask(__name__)
    
    # Configure app with minimal config to avoid circular imports
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost/linkmgt')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_timeout': 20,
        'pool_recycle': -1,
        'pool_pre_ping': True
    }
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)
    
    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'
    login_manager.login_message = 'Zaloguj się, aby uzyskać dostęp do tej strony.'
    
    # Template filters and context processors
    @app.template_filter('time_since')
    def time_since_filter(dt):
        if dt:
            now = datetime.utcnow()
            diff = now - dt
            
            if diff.days > 0:
                return f"{diff.days} dni temu"
            elif diff.seconds > 3600:
                hours = diff.seconds // 3600
                return f"{hours} godzin temu"
            elif diff.seconds > 60:
                minutes = diff.seconds // 60
                return f"{minutes} minut temu"
            else:
                return "przed chwilą"
        return "nieznana data"
    
    # Fix the context processor to handle missing endpoints
    @app.context_processor
    def inject_helpers():
        def get_config(key, default=None):
            """Pobierz konfigurację z bazy danych"""
            try:
                from app.models import AppConfig
                config = AppConfig.query.filter_by(key=key).first()
                return config.value if config else default
            except:
                return default
        
        def url_exists(endpoint):
            """Sprawdź czy endpoint istnieje"""
            try:
                return endpoint in app.view_functions
            except:
                return False
        
        return {
            'now': datetime.utcnow(),
            'get_config': get_config,
            'url_exists': url_exists
        }
    
    # Import models after app is configured but before registering blueprints
    with app.app_context():
        try:
            from app import models
            
            # Set up user loader for Flask-Login
            @login_manager.user_loader
            def load_user(user_id):
                from app.models import User
                try:
                    return User.query.get(int(user_id))
                except:
                    return None
                    
        except Exception as e:
            print(f"Błąd ładowania modeli: {e}")
    
    # Register blueprints with comprehensive error handling
    try:
        from app.errors import bp as errors_bp
        app.register_blueprint(errors_bp)
    except ImportError:
        print("Errors blueprint not available")
    
    try:
        from app.auth import bp as auth_bp
        app.register_blueprint(auth_bp, url_prefix='/auth')
    except ImportError:
        print("Auth blueprint not available")
    
    try:
        from app.main import bp as main_bp
        app.register_blueprint(main_bp)
    except ImportError:
        print("Main blueprint not available")
    
    try:
        from app.links import bp as links_bp
        app.register_blueprint(links_bp, url_prefix='/links')
    except ImportError:
        print("Links blueprint not available")
    
    try:
        from app.teams import bp as teams_bp
        app.register_blueprint(teams_bp, url_prefix='/teams')
    except ImportError:
        print("Teams blueprint not available")
    
    try:
        from app.users import bp as users_bp
        app.register_blueprint(users_bp, url_prefix='/users')
    except ImportError:
        print("Users blueprint not available")
    
    try:
        from app.categories import bp as categories_bp
        app.register_blueprint(categories_bp, url_prefix='/categories')
    except ImportError as e:
        print(f"Categories blueprint not available: {e}")
    
    try:
        from app.config import bp as config_bp
        app.register_blueprint(config_bp, url_prefix='/config')
    except ImportError:
        print("Config blueprint not available")
    
    # Add admin routes to the app directly instead of a separate blueprint
    try:
        from app.routes.admin import bp as admin_bp
        app.register_blueprint(admin_bp, url_prefix='/admin')
    except ImportError:
        print("Admin routes not available")
    
    try:
        from app.infrastructure import bp as infrastructure_bp
        app.register_blueprint(infrastructure_bp, url_prefix='/infrastructure')
        # Create placeholder routes if they don't exist
        if 'infrastructure.support_contracts' not in app.view_functions:
            @infrastructure_bp.route('/support_contracts')
            @login_required
            def support_contracts():
                flash('Ta funkcja jest obecnie w trakcie wdrażania.', 'info')
                return redirect(url_for('infrastructure.index'))
        
        if 'infrastructure.licenses' not in app.view_functions:
            @infrastructure_bp.route('/licenses')
            @login_required
            def licenses():
                flash('Ta funkcja jest obecnie w trakcie wdrażania.', 'info')
                return redirect(url_for('infrastructure.index'))
                
        print("✅ Infrastructure blueprint registered successfully")
    except ImportError as e:
        print(f"⚠️ Infrastructure blueprint not available: {e}")
    
    try:
        from app.database import bp as database_bp
        app.register_blueprint(database_bp, url_prefix='/database')
    except ImportError:
        print("Database blueprint not available")
    
    return app

# Don't import models here to avoid circular imports
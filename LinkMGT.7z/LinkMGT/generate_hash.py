from werkzeug.security import generate_password_hash

password = 'test123'  # Replace with your actual password
password_hash = generate_password_hash(password)
print(f"Password: {password}")
print(f"Hash: {password_hash}")
import os
import shutil
from datetime import datetime
from app import create_app, db
from app.models import AppConfig

def backup_database():
    """Utwórz kopię zapasową bazy danych"""
    
    app = create_app()
    
    with app.app_context():
        # Pobierz typ bazy danych
        db_type = AppConfig.get_config('DATABASE_TYPE', 'sqlite')
        db_uri = AppConfig.get_config('DATABASE_URI', 'sqlite:///app.db')
        
        backup_dir = 'backups'
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if db_type == 'sqlite':
            # Backup SQLite
            if ':///' in db_uri:
                db_file = db_uri.split(':///')[-1]
            else:
                db_file = 'app.db'
            
            if os.path.exists(db_file):
                backup_file = os.path.join(backup_dir, f'backup_{timestamp}.db')
                shutil.copy2(db_file, backup_file)
                print(f"✅ Backup SQLite utworzony: {backup_file}")
            else:
                print(f"❌ Plik bazy danych nie istnieje: {db_file}")
        
        elif db_type == 'postgresql':
            # Backup PostgreSQL
            import subprocess
            from urllib.parse import urlparse
            
            parsed = urlparse(db_uri)
            backup_file = os.path.join(backup_dir, f'backup_{timestamp}.sql')
            
            cmd = [
                'pg_dump',
                f'--host={parsed.hostname}',
                f'--port={parsed.port or 5432}',
                f'--username={parsed.username}',
                f'--dbname={parsed.path[1:]}',  # Remove leading slash
                f'--file={backup_file}',
                '--no-password'
            ]
            
            # Set password environment variable
            env = os.environ.copy()
            env['PGPASSWORD'] = parsed.password
            
            try:
                subprocess.run(cmd, env=env, check=True)
                print(f"✅ Backup PostgreSQL utworzony: {backup_file}")
            except subprocess.CalledProcessError as e:
                print(f"❌ Błąd podczas tworzenia backup PostgreSQL: {e}")
        
        elif db_type == 'mysql':
            # Backup MySQL/MariaDB
            import subprocess
            from urllib.parse import urlparse
            
            parsed = urlparse(db_uri)
            backup_file = os.path.join(backup_dir, f'backup_{timestamp}.sql')
            
            cmd = [
                'mysqldump',
                f'--host={parsed.hostname}',
                f'--port={parsed.port or 3306}',
                f'--user={parsed.username}',
                f'--password={parsed.password}',
                parsed.path[1:],  # Remove leading slash
                f'--result-file={backup_file}'
            ]
            
            try:
                subprocess.run(cmd, check=True)
                print(f"✅ Backup MySQL utworzony: {backup_file}")
            except subprocess.CalledProcessError as e:
                print(f"❌ Błąd podczas tworzenia backup MySQL: {e}")
        
        else:
            print(f"❌ Nieobsługiwany typ bazy danych: {db_type}")

def cleanup_old_backups(days=30):
    """Usuń stare kopie zapasowe"""
    import time
    
    backup_dir = 'backups'
    if not os.path.exists(backup_dir):
        return
    
    cutoff_time = time.time() - (days * 24 * 60 * 60)
    removed_count = 0
    
    for filename in os.listdir(backup_dir):
        file_path = os.path.join(backup_dir, filename)
        if os.path.isfile(file_path):
            if os.path.getmtime(file_path) < cutoff_time:
                os.remove(file_path)
                removed_count += 1
                print(f"Usunięto stary backup: {filename}")
    
    if removed_count > 0:
        print(f"✅ Usunięto {removed_count} starych kopii zapasowych")
    else:
        print("Brak starych kopii zapasowych do usunięcia")

if __name__ == '__main__':
    backup_database()
    cleanup_old_backups()

@echo off
REM filepath: d:\Projekty\LinkMGT\setup_db.bat

echo Konfiguracja bazy danych LinkMGT
echo ================================

echo.
echo 1. Tworzenie nowej bazy danych...
python init_db.py

echo.
echo 2. Inicjalizacja migracji...
flask db init

echo.
echo 3. Tworzenie pierwszej migracji...
flask db migrate -m "Początkowa migracja - tabele podstawowe i infrastruktura"

echo.
echo 4. Wykonywanie migracji...
flask db upgrade

echo.
echo ✅ Konfiguracja bazy danych zakończona!
echo.
echo Domyślne konta:
echo - Administrator: admin / admin123
echo - Demo: demo / demo123
echo.
pause
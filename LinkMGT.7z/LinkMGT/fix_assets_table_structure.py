import os
import sys

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def fix_assets_table():
    """Napraw strukturę tabeli assets"""
    
    from app import create_app, db
    
    app = create_app()
    
    with app.app_context():
        from sqlalchemy import text
        
        print("🔧 Naprawianie struktury tabeli assets...")
        
        try:
            # Sprawdź obecną strukturę tabeli assets
            result = db.session.execute(text("""
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns 
                WHERE table_name = 'assets' AND table_schema = 'public'
                ORDER BY ordinal_position
            """))
            
            current_columns = {row[0]: (row[1], row[2]) for row in result.fetchall()}
            print(f"Obecne kolumny w tabeli assets: {list(current_columns.keys())}")
            
            # Definicja wymaganych kolumn
            required_columns = {
                'id': 'SERIAL PRIMARY KEY',
                'name': 'VARCHAR(100) NOT NULL',
                'asset_type': 'VARCHAR(50) DEFAULT \'server\'',
                'status': 'VARCHAR(20) DEFAULT \'active\'',
                'serial_number': 'VARCHAR(100)',
                'model': 'VARCHAR(100)',
                'manufacturer': 'VARCHAR(100)',
                'description': 'TEXT',
                'cost': 'NUMERIC(10, 2)',
                'purchase_date': 'DATE',
                'warranty_expiry': 'DATE',
                'location_id': 'INTEGER',
                'vendor_id': 'INTEGER',
                'assigned_to': 'INTEGER',
                'created_at': 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
                'updated_at': 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
                'created_by': 'INTEGER'
            }
            
            # Dodaj brakujące kolumny
            for col_name, col_definition in required_columns.items():
                if col_name not in current_columns:
                    try:
                        print(f"Dodawanie kolumny {col_name}...")
                        if col_name == 'id':
                            continue  # ID już powinno istnieć
                        
                        alter_sql = f"ALTER TABLE assets ADD COLUMN {col_name} {col_definition}"
                        db.session.execute(text(alter_sql))
                        print(f"✅ Dodano kolumnę {col_name}")
                        
                    except Exception as e:
                        print(f"Błąd dodawania kolumny {col_name}: {e}")
            
            # Sprawdź czy tabela ma dane
            result = db.session.execute(text("SELECT COUNT(*) FROM assets"))
            count = result.scalar()
            print(f"Tabela assets zawiera {count} rekordów")
            
            # Dodaj foreign keys jeśli nie istnieją
            foreign_keys = [
                "ALTER TABLE assets ADD CONSTRAINT fk_assets_location FOREIGN KEY (location_id) REFERENCES locations(id)",
                "ALTER TABLE assets ADD CONSTRAINT fk_assets_vendor FOREIGN KEY (vendor_id) REFERENCES vendors(id)",
                "ALTER TABLE assets ADD CONSTRAINT fk_assets_assigned FOREIGN KEY (assigned_to) REFERENCES users(id)",
                "ALTER TABLE assets ADD CONSTRAINT fk_assets_created FOREIGN KEY (created_by) REFERENCES users(id)"
            ]
            
            for fk_sql in foreign_keys:
                try:
                    db.session.execute(text(fk_sql))
                except Exception as e:
                    # Foreign key prawdopodobnie już istnieje
                    pass
            
            db.session.commit()
            print("✅ Struktura tabeli assets została naprawiona!")
            
            # Sprawdź finalną strukturę
            result = db.session.execute(text("""
                SELECT column_name
                FROM information_schema.columns 
                WHERE table_name = 'assets' AND table_schema = 'public'
                ORDER BY ordinal_position
            """))
            
            final_columns = [row[0] for row in result.fetchall()]
            print(f"Finalna struktura tabeli assets: {final_columns}")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Błąd podczas naprawiania tabeli assets: {e}")
            return False
    
    return True

if __name__ == '__main__':
    success = fix_assets_table()
    if success:
        print("🚀 Tabela assets została naprawiona! Możesz teraz uruchomić aplikację.")
    else:
        sys.exit(1)

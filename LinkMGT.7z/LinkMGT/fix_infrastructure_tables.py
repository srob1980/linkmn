import os
import sys

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def fix_infrastructure_tables():
    """Napraw strukturę tabel infrastruktury"""
    
    from app import create_app, db
    
    app = create_app()
    
    with app.app_context():
        from sqlalchemy import text
        
        print("🔧 Sprawdzanie i naprawianie struktury tabel infrastruktury...")
        
        try:
            # Sprawdź które tabele istnieją
            result = db.session.execute(text("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name LIKE '%location%' OR table_name LIKE '%vendor%' 
                OR table_name LIKE '%asset%' OR table_name LIKE '%license%'
            """))
            
            existing_tables = [row[0] for row in result.fetchall()]
            print(f"Istniejące tabele: {existing_tables}")
            
            # Utwórz podstawowe tabele infrastruktury jeśli nie istnieją
            if 'locations' not in existing_tables:
                print("Tworzenie tabeli locations...")
                db.session.execute(text("""
                    CREATE TABLE locations (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        address VARCHAR(200),
                        city VARCHAR(100),
                        country VARCHAR(100),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        is_active BOOLEAN DEFAULT TRUE
                    )
                """))
            else:
                # Sprawdź strukturę istniejącej tabeli
                columns_result = db.session.execute(text("""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = 'locations' AND table_schema = 'public'
                """))
                existing_columns = [row[0] for row in columns_result.fetchall()]
                print(f"Kolumny w tabeli locations: {existing_columns}")
                
                # Usuń niepotrzebne kolumny jeśli istnieją
                problematic_columns = ['contact_person', 'contact_phone', 'contact_email']
                for col in problematic_columns:
                    if col in existing_columns:
                        try:
                            print(f"Usuwanie kolumny {col} z tabeli locations...")
                            db.session.execute(text(f"ALTER TABLE locations DROP COLUMN IF EXISTS {col}"))
                        except Exception as e:
                            print(f"Błąd przy usuwaniu kolumny {col}: {e}")
            
            if 'vendors' not in existing_tables:
                print("Tworzenie tabeli vendors...")
                db.session.execute(text("""
                    CREATE TABLE vendors (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        address VARCHAR(200),
                        city VARCHAR(100),
                        country VARCHAR(100),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        is_active BOOLEAN DEFAULT TRUE
                    )
                """))
            
            if 'assets' not in existing_tables:
                print("Tworzenie tabeli assets...")
                db.session.execute(text("""
                    CREATE TABLE assets (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        asset_type VARCHAR(50) DEFAULT 'server',
                        status VARCHAR(20) DEFAULT 'active',
                        serial_number VARCHAR(100),
                        model VARCHAR(100),
                        manufacturer VARCHAR(100),
                        description TEXT,
                        cost NUMERIC(10, 2),
                        purchase_date DATE,
                        warranty_expiry DATE,
                        location_id INTEGER REFERENCES locations(id),
                        vendor_id INTEGER REFERENCES vendors(id),
                        assigned_to INTEGER REFERENCES users(id),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by INTEGER REFERENCES users(id)
                    )
                """))
            
            if 'licenses' not in existing_tables:
                print("Tworzenie tabeli licenses...")
                db.session.execute(text("""
                    CREATE TABLE licenses (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        license_type VARCHAR(50),
                        quantity INTEGER DEFAULT 1,
                        license_key TEXT,
                        cost NUMERIC(10, 2),
                        purchase_date DATE,
                        expiry_date DATE,
                        vendor_id INTEGER REFERENCES vendors(id),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """))
            
            if 'support_contracts' not in existing_tables:
                print("Tworzenie tabeli support_contracts...")
                db.session.execute(text("""
                    CREATE TABLE support_contracts (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        contract_number VARCHAR(50),
                        start_date DATE,
                        end_date DATE,
                        cost NUMERIC(10, 2),
                        description TEXT,
                        vendor_id INTEGER REFERENCES vendors(id),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """))
            
            if 'maintenance_logs' not in existing_tables:
                print("Tworzenie tabeli maintenance_logs...")
                db.session.execute(text("""
                    CREATE TABLE maintenance_logs (
                        id SERIAL PRIMARY KEY,
                        asset_id INTEGER REFERENCES assets(id) NOT NULL,
                        maintenance_type VARCHAR(50),
                        description TEXT,
                        scheduled_date TIMESTAMP,
                        completed_date TIMESTAMP,
                        completed BOOLEAN DEFAULT FALSE,
                        cost NUMERIC(10, 2),
                        performed_by INTEGER REFERENCES users(id),
                        vendor_id INTEGER REFERENCES vendors(id),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """))
            
            db.session.commit()
            print("✅ Struktura tabel infrastruktury została naprawiona!")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Błąd podczas naprawiania tabel: {e}")
            return False
    
    return True

if __name__ == '__main__':
    success = fix_infrastructure_tables()
    if success:
        print("🚀 Teraz możesz uruchomić initialize_complete.py")
    else:
        sys.exit(1)

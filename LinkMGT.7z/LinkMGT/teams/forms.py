from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, Optional

class TeamForm(FlaskForm):
    """Formularz do tworzenia i edycji zespołu"""
    name = StringField('Nazwa zespołu', 
                      validators=[DataRequired(), Length(max=64)],
                      render_kw={'placeholder': 'Wprowadź nazwę zespołu'})
    
    description = TextAreaField('Opis', 
                               validators=[Optional(), Length(max=500)],
                               render_kw={'placeholder': 'Opcjonalny opis zespołu', 'rows': 3})
    
    color = StringField('Kolor', 
                       validators=[Optional(), Length(max=7)],
                       default='#3b82f6')
    
    submit = SubmitField('Zapisz')

class AddMemberForm(FlaskForm):
    """Formularz do dodawania członków do zespołu"""
    user_id = SelectField('Użytkownik', 
                         coerce=int,
                         validators=[DataRequired()])
    
    role = SelectField('Rola', choices=[
        (0, 'Użytkownik'),
        (1, 'Edytor'),
        (2, 'Administrator')
    ], 
    coerce=int, 
    validators=[DataRequired()])
    
    submit = SubmitField('Dodaj do zespołu')
    
    def __init__(self, *args, **kwargs):
        super(AddMemberForm, self).__init__(*args, **kwargs)
        
        # Pobierz użytkowników do wyboru
        from app.models import User
        users = User.query.filter_by(is_active=True).order_by(User.username).all()
        self.user_id.choices = [(u.id, f"{u.username} ({u.email})") for u in users]

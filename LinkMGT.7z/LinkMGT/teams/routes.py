from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.teams import bp
from app.teams.forms import TeamForm, AddMemberForm
from app.models import Team, User
from app import db
from sqlalchemy import desc, or_
from app.auth.decorators import admin_required

@bp.route('/')
@login_required
def index():
    """Lista zespołów"""
    # Administratorzy widzą wszystkie zespoły
    if current_user.is_admin:
        teams = Team.query.filter_by(is_active=True).order_by(Team.name).all()
    else:
        # Zwykli użytkownicy widzą tylko swoje zespoły
        teams = current_user.teams
    
    return render_template('teams/index.html',
                          title='Zespoły',
                          teams=teams)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create():
    """Utwórz nowy zespół"""
    form = TeamForm()
    
    if form.validate_on_submit():
        # Utwórz nowy zespół
        team = Team(
            name=form.name.data,
            description=form.description.data,
            color=form.color.data,
            created_by=current_user.id
        )
        
        try:
            db.session.add(team)
            db.session.flush()  # Generuje ID dla zespołu
            
            # Dodaj twórcę jako administratora zespołu
            team.members.append(current_user)
            
            # Dodaj wpis w tabeli user_team z rolą administratora
            from app.models import user_team
            db.session.execute(
                user_team.insert().values(
                    user_id=current_user.id,
                    team_id=team.id,
                    role=2  # 2 = Admin
                )
            )
            
            db.session.commit()
            flash(f'Zespół "{team.name}" został utworzony.', 'success')
            return redirect(url_for('teams.view', team_id=team.id))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas tworzenia zespołu: {str(e)}', 'danger')
    
    return render_template('teams/create.html',
                          title='Nowy zespół',
                          form=form)

@bp.route('/<int:team_id>')
@login_required
def view(team_id):
    """Szczegóły zespołu"""
    team = Team.query.get_or_404(team_id)
    
    # Sprawdź czy użytkownik jest członkiem zespołu lub administratorem
    if not current_user.is_admin and current_user not in team.members:
        flash('Nie masz dostępu do tego zespołu.', 'danger')
        return redirect(url_for('teams.index'))
    
    # Przygotuj formularz dodawania członków
    add_member_form = AddMemberForm()
    
    # Pobierz członków zespołu z ich rolami
    members_with_roles = []
    for member in team.members:
        # Pobierz rolę użytkownika w zespole
        from app.models import user_team
        result = db.session.execute(
            db.select([user_team.c.role]).where(
                (user_team.c.user_id == member.id) & 
                (user_team.c.team_id == team.id)
            )
        ).fetchone()
        
        role = result[0] if result else 0
        members_with_roles.append({
            'user': member,
            'role': role,
            'role_name': ['Użytkownik', 'Edytor', 'Administrator'][role]
        })
    
    # Pobierz linki zespołu
    links = team.links
    
    return render_template('teams/view.html',
                          title=f'Zespół: {team.name}',
                          team=team,
                          members=members_with_roles,
                          links=links,
                          add_member_form=add_member_form)

@bp.route('/<int:team_id>/edit', methods=['GET', 'POST'])
@login_required
def edit(team_id):
    """Edytuj zespół"""
    team = Team.query.get_or_404(team_id)
    
    # Sprawdź czy użytkownik jest administratorem zespołu lub globalnym administratorem
    from app.models import user_team
    result = db.session.execute(
        db.select([user_team.c.role]).where(
            (user_team.c.user_id == current_user.id) & 
            (user_team.c.team_id == team.id)
        )
    ).fetchone()
    
    is_team_admin = result and result[0] == 2
    if not (current_user.is_admin or is_team_admin):
        flash('Nie masz uprawnień do edycji tego zespołu.', 'danger')
        return redirect(url_for('teams.view', team_id=team.id))
    
    form = TeamForm(obj=team)
    
    if form.validate_on_submit():
        # Aktualizuj zespół
        team.name = form.name.data
        team.description = form.description.data
        team.color = form.color.data
        
        try:
            db.session.commit()
            flash(f'Zespół "{team.name}" został zaktualizowany.', 'success')
            return redirect(url_for('teams.view', team_id=team.id))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji zespołu: {str(e)}', 'danger')
    
    return render_template('teams/edit.html',
                          title=f'Edytuj zespół: {team.name}',
                          form=form,
                          team=team)

@bp.route('/<int:team_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete(team_id):
    """Usuń zespół"""
    team = Team.query.get_or_404(team_id)
    
    try:
        # Oznacz jako nieaktywny zamiast usuwać fizycznie
        team.is_active = False
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

@bp.route('/<int:team_id>/add_member', methods=['POST'])
@login_required
def add_member(team_id):
    """Dodaj członka do zespołu"""
    team = Team.query.get_or_404(team_id)
    
    # Sprawdź czy użytkownik jest administratorem zespołu lub globalnym administratorem
    from app.models import user_team
    result = db.session.execute(
        db.select([user_team.c.role]).where(
            (user_team.c.user_id == current_user.id) & 
            (user_team.c.team_id == team.id)
        )
    ).fetchone()
    
    is_team_admin = result and result[0] == 2
    if not (current_user.is_admin or is_team_admin):
        flash('Nie masz uprawnień do zarządzania członkami tego zespołu.', 'danger')
        return redirect(url_for('teams.view', team_id=team.id))
    
    form = AddMemberForm()
    
    if form.validate_on_submit():
        user_id = form.user_id.data
        role = form.role.data
        
        # Sprawdź czy użytkownik istnieje
        user = User.query.get(user_id)
        if not user:
            flash('Wybrany użytkownik nie istnieje.', 'danger')
            return redirect(url_for('teams.view', team_id=team.id))
        
        # Sprawdź czy użytkownik jest już w zespole
        if user in team.members:
            # Aktualizuj rolę
            db.session.execute(
                user_team.update().where(
                    (user_team.c.user_id == user.id) & 
                    (user_team.c.team_id == team.id)
                ).values(role=role)
            )
            db.session.commit()
            flash(f'Rola użytkownika {user.username} została zaktualizowana.', 'success')
        else:
            # Dodaj użytkownika do zespołu
            team.members.append(user)
            
            # Ustaw rolę użytkownika
            db.session.execute(
                user_team.update().where(
                    (user_team.c.user_id == user.id) & 
                    (user_team.c.team_id == team.id)
                ).values(role=role)
            )
            db.session.commit()
            flash(f'Użytkownik {user.username} został dodany do zespołu.', 'success')
        
        return redirect(url_for('teams.view', team_id=team.id))
    
    for field, errors in form.errors.items():
        for error in errors:
            flash(f'Błąd w polu {getattr(form, field).label.text}: {error}', 'danger')
    
    return redirect(url_for('teams.view', team_id=team.id))

@bp.route('/<int:team_id>/remove_member/<int:user_id>', methods=['POST'])
@login_required
def remove_member(team_id, user_id):
    """Usuń członka z zespołu"""
    team = Team.query.get_or_404(team_id)
    user = User.query.get_or_404(user_id)
    
    # Sprawdź czy użytkownik jest administratorem zespołu lub globalnym administratorem
    from app.models import user_team
    result = db.session.execute(
        db.select([user_team.c.role]).where(
            (user_team.c.user_id == current_user.id) & 
            (user_team.c.team_id == team.id)
        )
    ).fetchone()
    
    is_team_admin = result and result[0] == 2
    if not (current_user.is_admin or is_team_admin):
        return jsonify({'success': False, 'message': 'Nie masz uprawnień do zarządzania członkami tego zespołu.'})
    
    # Nie pozwól usunąć ostatniego administratora zespołu
    if user_id == current_user.id:
        # Sprawdź czy są inni administratorzy
        admin_count = db.session.execute(
            db.select([db.func.count()]).where(
                (user_team.c.team_id == team.id) & 
                (user_team.c.role == 2) &
                (user_team.c.user_id != current_user.id)
            )
        ).scalar()
        
        if admin_count == 0:
            return jsonify({
                'success': False, 
                'message': 'Nie możesz usunąć się z zespołu, ponieważ jesteś jego jedynym administratorem.'
            })
    
    try:
        # Usuń użytkownika z zespołu
        team.members.remove(user)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

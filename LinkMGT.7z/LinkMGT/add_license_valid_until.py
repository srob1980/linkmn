import os
import sys

project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

from app import create_app, db
from sqlalchemy import text

def add_license_valid_until_column():
    """Dodaj kolumnę valid_until do tabeli licenses"""
    
    app = create_app()
    
    with app.app_context():
        try:
            # Sprawdź czy kolumna już istnieje
            result = db.session.execute(text("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = 'licenses' AND column_name = 'valid_until';
            """))
            
            if result.fetchone():
                print("✅ Kolumna valid_until już istnieje w tabeli licenses")
                return
            
            # Dodaj kolumnę valid_until
            print("Dodawanie kolumny valid_until do tabeli licenses...")
            db.session.execute(text("""
                ALTER TABLE licenses ADD COLUMN valid_until DATE;
            """))
            
            # Dodaj kolumnę valid_from jeśli nie istnieje
            result = db.session.execute(text("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = 'licenses' AND column_name = 'valid_from';
            """))
            
            if not result.fetchone():
                print("Dodawanie kolumny valid_from do tabeli licenses...")
                db.session.execute(text("""
                    ALTER TABLE licenses ADD COLUMN valid_from DATE;
                """))
            
            db.session.commit()
            print("✅ Kolumny zostały dodane pomyślnie!")
            
        except Exception as e:
            print(f"❌ Błąd podczas dodawania kolumn: {e}")
            db.session.rollback()
            raise

if __name__ == '__main__':
    add_license_valid_until_column()
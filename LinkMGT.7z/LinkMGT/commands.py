import click
from flask.cli import with_appcontext
from app import db
from app.models import AppConfig, User
from werkzeug.security import generate_password_hash

@click.command('init-auth-config')
@with_appcontext
def init_auth_config():
    """Initialize authentication configuration settings."""
    configs = [
        ('AUTH_USE_AD', 'False', 'Use Active Directory authentication', False),
        ('AUTH_AD_FALLBACK', 'True', 'Fall back to database auth if AD fails', False),
        ('AUTH_ALLOW_REGISTRATION', 'True', 'Allow user self-registration', False),
    ]
    
    for key, value, description, is_sensitive in configs:
        existing = AppConfig.query.filter_by(key=key).first()
        if not existing:
            config = AppConfig(
                key=key,
                value=value,
                description=description,
                is_sensitive=is_sensitive
            )
            db.session.add(config)
    
    db.session.commit()
    click.echo("Authentication configuration initialized.")

@click.command('create-admin')
@click.argument('username')
@click.argument('email')
@click.argument('password')
@with_appcontext
def create_admin():
    """Create an admin user."""
    user = User(
        username=username,
        email=email,
        is_admin=True,
        is_active=True
    )
    user.set_password(password)
    
    db.session.add(user)
    db.session.commit()
    click.echo(f"Admin user '{username}' created successfully.")
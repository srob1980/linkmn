import os
import sys
import shutil
import requests
from zipfile import ZipFile
from io import BytesIO

def create_directory(directory):
    """Create directory if it doesn't exist"""
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Created directory: {directory}")

def download_file(url, filename):
    """Download a file from URL and save it to filename"""
    print(f"Downloading {url}...")
    response = requests.get(url, stream=True)
    response.raise_for_status()
    
    with open(filename, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
    
    print(f"Downloaded: {filename}")

def download_and_extract_zip(url, extract_to):
    """Download a zip file and extract it"""
    print(f"Downloading and extracting {url}...")
    response = requests.get(url)
    response.raise_for_status()
    
    with ZipFile(BytesIO(response.content)) as zipf:
        zipf.extractall(extract_to)
    
    print(f"Extracted to: {extract_to}")

def setup_bootstrap():
    """Download and set up Bootstrap 5"""
    bootstrap_version = "5.3.2"
    bootstrap_url = f"https://github.com/twbs/bootstrap/releases/download/v{bootstrap_version}/bootstrap-{bootstrap_version}-dist.zip"
    
    # Create directories
    css_dir = "app/static/css"
    js_dir = "app/static/js"
    create_directory(css_dir)
    create_directory(js_dir)
    
    # Create temp directory for extraction
    temp_dir = "temp_bootstrap"
    create_directory(temp_dir)
    
    try:
        # Download and extract Bootstrap
        download_and_extract_zip(bootstrap_url, temp_dir)
        
        # Copy files to appropriate directories
        shutil.copy(f"{temp_dir}/css/bootstrap.min.css", f"{css_dir}/bootstrap.min.css")
        shutil.copy(f"{temp_dir}/css/bootstrap.min.css.map", f"{css_dir}/bootstrap.min.css.map")
        shutil.copy(f"{temp_dir}/js/bootstrap.bundle.min.js", f"{js_dir}/bootstrap.bundle.min.js")
        shutil.copy(f"{temp_dir}/js/bootstrap.bundle.min.js.map", f"{js_dir}/bootstrap.bundle.min.js.map")
        
        print("✅ Bootstrap 5 setup complete")
    finally:
        # Clean up temp directory
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

def setup_fontawesome():
    """Download and set up Font Awesome"""
    fontawesome_version = "6.4.2"
    fontawesome_url = f"https://use.fontawesome.com/releases/v{fontawesome_version}/fontawesome-free-{fontawesome_version}-web.zip"
    
    # Create directory
    fontawesome_dir = "app/static/css/fontawesome"
    create_directory(fontawesome_dir)
    
    # Create temp directory for extraction
    temp_dir = "temp_fontawesome"
    create_directory(temp_dir)
    
    try:
        # Download and extract Font Awesome
        download_and_extract_zip(fontawesome_url, temp_dir)
        
        # Copy CSS files
        shutil.copy(f"{temp_dir}/fontawesome-free-{fontawesome_version}-web/css/all.min.css", f"{fontawesome_dir}/all.min.css")
        
        # Create webfonts directory and copy fonts
        webfonts_dir = "app/static/css/fontawesome/webfonts"
        create_directory(webfonts_dir)
        
        # Copy all webfonts
        src_webfonts = f"{temp_dir}/fontawesome-free-{fontawesome_version}-web/webfonts"
        for font_file in os.listdir(src_webfonts):
            shutil.copy(os.path.join(src_webfonts, font_file), os.path.join(webfonts_dir, font_file))
        
        print("✅ Font Awesome setup complete")
    finally:
        # Clean up temp directory
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

def create_error_svg_images():
    """Create placeholder SVG images for error pages"""
    img_dir = "app/static/img"
    create_directory(img_dir)
    
    # Create basic SVG files for error pages
    error_pages = ["401", "403", "404", "500"]
    
    for error in error_pages:
        svg_content = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500">
            <rect width="100%" height="100%" fill="#f8f9fa"/>
            <text x="50%" y="50%" font-family="Arial" font-size="120" font-weight="bold" text-anchor="middle" fill="#0d6efd">{error}</text>
            <text x="50%" y="65%" font-family="Arial" font-size="24" text-anchor="middle" fill="#6c757d">Error Page</text>
        </svg>"""
        
        with open(f"{img_dir}/{error}.svg", "w") as f:
            f.write(svg_content)
    
    print("✅ Error page SVG images created")

def main():
    """Main function to set up all static files"""
    print("🚀 Setting up static files for LinkMGT...")
    
    # Create utilities.js if it doesn't exist
    js_dir = "app/static/js"
    create_directory(js_dir)
    
    # Set up Bootstrap and Font Awesome
    setup_bootstrap()
    setup_fontawesome()
    create_error_svg_images()
    
    print("\n✨ All static files have been set up successfully!")
    print("You can now run your Flask application with proper styling.")

if __name__ == "__main__":
    main()

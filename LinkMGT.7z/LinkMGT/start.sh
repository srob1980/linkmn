#!/bin/bash

# Ścieżka do katalogu aplikacji
APP_DIR=/opt/LinkMGT

# Przejście do katalogu aplikacji
cd $APP_DIR

# Aktywacja środowiska wirtualnego
source venv/bin/activate

# Eksport zmiennych środowiskowych
export FLASK_APP=app
export FLASK_ENV=${FLASK_ENV:-production}
export FLASK_DEBUG=${FLASK_DEBUG:-0}

# Opcjonalnie - odczyt zmiennych z pliku .env
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# Uruchomienie aplikacji
if [ "$FLASK_ENV" = "development" ]; then
  echo "Uruchamianie w trybie deweloperskim..."
  flask run --host=0.0.0.0 --port=${PORT:-5000}
else
  echo "Uruchamianie w trybie produkcyjnym..."
  # Używamy gunicorn jako serwer produkcyjny (należy go zainstalować: pip install gunicorn)
  gunicorn --bind 0.0.0.0:${PORT:-5000} --workers=4 --timeout 120 "app:create_app()"
fi

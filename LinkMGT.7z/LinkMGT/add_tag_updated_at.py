import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def add_updated_at_to_tags():
    """Add updated_at column to tags table"""
    from app import create_app, db
    from sqlalchemy import Column, DateTime, text
    
    app = create_app()
    
    with app.app_context():
        # Check if column already exists
        exists_query = text("""
            SELECT column_name FROM information_schema.columns 
            WHERE table_name = 'tags' AND column_name = 'updated_at'
        """)
        
        result = db.session.execute(exists_query).fetchone()
        
        if result:
            print("Column 'updated_at' already exists in 'tags' table.")
            return
        
        # Add the column
        add_column_query = text("""
            ALTER TABLE tags ADD COLUMN updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
        """)
        
        db.session.execute(add_column_query)
        
        # Update all existing rows to set updated_at equal to created_at
        update_query = text("""
            UPDATE tags SET updated_at = created_at
        """)
        
        db.session.execute(update_query)
        db.session.commit()
        
        print("Successfully added 'updated_at' column to 'tags' table.")

if __name__ == "__main__":
    add_updated_at_to_tags()

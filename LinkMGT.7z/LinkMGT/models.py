from app import db, login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, Table, Float
from sqlalchemy.orm import relationship

# Association Tables
user_team = db.Table('user_team',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('team_id', db.Integer, db.ForeignKey('teams.id'), primary_key=True),
    db.Column('role', db.Integer, default=0),  # 0=USER, 1=EDITOR, 2=ADMIN
    db.Column('joined_at', db.DateTime, default=datetime.utcnow)
)

# Add or update the link_team association table if it doesn't exist
link_team = db.Table('link_team',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('team_id', db.Integer, db.ForeignKey('teams.id'), primary_key=True),
    db.Column('added_at', db.DateTime, default=datetime.utcnow)
)

link_category = db.Table('link_category',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('category_id', db.Integer, db.ForeignKey('categories.id'), primary_key=True)
)

link_tag = db.Table('link_tag',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tags.id'), primary_key=True)
)

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    ad_dn = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)
    login_count = db.Column(db.Integer, default=0)
    failed_login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime)
    
    # Relationships
    teams = db.relationship('Team', secondary=user_team, 
                           backref=db.backref('members', lazy='dynamic'))
    created_links = db.relationship('Link', backref='creator', lazy='dynamic',
                                  foreign_keys='Link.creator_id')
    
    @property
    def display_name(self):
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.username
    
    @property
    def initials(self):
        if self.first_name and self.last_name:
            return f"{self.first_name[0]}{self.last_name[0]}".upper()
        return self.username[0].upper()
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_role_in_team(self, team_id):
        user_team_entry = db.session.query(user_team).filter_by(
            user_id=self.id, team_id=team_id).first()
        return user_team_entry.role if user_team_entry else -1
    
    def __repr__(self):
        return f'<User {self.username}>'

class Team(db.Model):
    __tablename__ = 'teams'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    color = db.Column(db.String(7), default='#007bff')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    links = db.relationship('Link', secondary=link_team, 
                          backref=db.backref('teams', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Team {self.name}>'

class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    color = db.Column(db.String(7), default='#2563eb')
    icon = db.Column(db.String(50), default='fas fa-folder')
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    links = db.relationship('Link', secondary=link_category, 
                          backref=db.backref('categories', lazy='dynamic'))
    subcategories = db.relationship('Category', 
                                   backref=db.backref('parent', remote_side=[id]),
                                   lazy='dynamic')
    
    def __repr__(self):
        return f'<Category {self.name}>'

class Tag(db.Model):
    __tablename__ = 'tags'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), unique=True, nullable=False)
    color = db.Column(db.String(7), default='#64748b')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    links = db.relationship('Link', secondary=link_tag, 
                          backref=db.backref('tags', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Tag {self.name}>'

class Link(db.Model):
    __tablename__ = 'links'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    is_active = db.Column(db.Boolean, default=True)
    is_public = db.Column(db.Boolean, default=False)
    click_count = db.Column(db.Integer, default=0)
    last_accessed = db.Column(db.DateTime)
    favicon_url = db.Column(db.String(500))
    status_code = db.Column(db.Integer, default=200)
    last_checked = db.Column(db.DateTime)
    
    # Add the teams relationship
    teams = db.relationship('Team', secondary=link_team, 
                          backref=db.backref('links', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Link {self.title}>'

class AppConfig(db.Model):
    __tablename__ = 'app_config'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    value = db.Column(db.String(512), nullable=False)
    description = db.Column(db.String(256))
    category = db.Column(db.String(50), default='general')
    is_sensitive = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_value(cls, key, default=None):
        """Get config value by key"""
        config = cls.query.filter_by(key=key).first()
        return config.value if config else default
    
    @classmethod
    def set_value(cls, key, value, description=None, category='general', is_sensitive=False):
        """Set config value"""
        config = cls.query.filter_by(key=key).first()
        if config:
            config.value = value
            if description:
                config.description = description
            config.category = category
            config.is_sensitive = is_sensitive
        else:
            config = cls(
                key=key, 
                value=value, 
                description=description,
                category=category,
                is_sensitive=is_sensitive
            )
            db.session.add(config)
        db.session.commit()
        return config
    
    def __repr__(self):
        return f'<AppConfig {self.key}>'

# Load user for flask-login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.categories import bp
from app.categories.forms import CategoryForm
from app.models import Category, Link  # Dodaj import Link
from app import db
from sqlalchemy import desc, or_

@bp.route('/')
@login_required
def index():
    """Lista kategorii"""
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    
    # Grupuj kategorie w hierarchii
    root_categories = [c for c in categories if c.parent_id is None]
    child_categories = {}
    for category in categories:
        if category.parent_id:
            if category.parent_id not in child_categories:
                child_categories[category.parent_id] = []
            child_categories[category.parent_id].append(category)
    
    return render_template('categories/index.html',
                          title='Kategorie',
                          root_categories=root_categories,
                          child_categories=child_categories)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Utwórz nową kategorię"""
    form = CategoryForm()
    
    # Pobierz dostępne kategorie do wyboru jako rodzic
    parent_choices = [(0, 'Brak - kategoria główna')]
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    parent_choices.extend([(c.id, c.name) for c in categories])
    form.parent_id.choices = parent_choices
    
    if form.validate_on_submit():
        # Utwórz nową kategorię
        parent_id = form.parent_id.data if form.parent_id.data > 0 else None
        category = Category(
            name=form.name.data,
            description=form.description.data,
            parent_id=parent_id,
            color=form.color.data,
            icon=form.icon.data,
            sort_order=form.sort_order.data,
            created_by=current_user.id
        )
        
        try:
            db.session.add(category)
            db.session.commit()
            flash(f'Kategoria "{category.name}" została utworzona.', 'success')
            return redirect(url_for('categories.index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas tworzenia kategorii: {str(e)}', 'danger')
    
    return render_template('categories/create.html',
                          title='Nowa kategoria',
                          form=form)

@bp.route('/<int:category_id>/edit', methods=['GET', 'POST'])
@login_required
def edit(category_id):
    """Edytuj kategorię"""
    category = Category.query.get_or_404(category_id)
    form = CategoryForm(obj=category)
    
    # Pobierz dostępne kategorie do wyboru jako rodzic (z wyjątkiem siebie i swoich dzieci)
    parent_choices = [(0, 'Brak - kategoria główna')]
    categories = Category.query.filter(
        Category.is_active == True,
        Category.id != category_id
    ).order_by(Category.name).all()
    
    # Wyklucz podkategorie tej kategorii
    def get_subcategory_ids(cat_id):
        subcats = Category.query.filter_by(parent_id=cat_id).all()
        result = [subcat.id for subcat in subcats]
        for subcat in subcats:
            result.extend(get_subcategory_ids(subcat.id))
        return result
    
    excluded_ids = get_subcategory_ids(category_id)
    available_categories = [c for c in categories if c.id not in excluded_ids]
    
    parent_choices.extend([(c.id, c.name) for c in available_categories])
    form.parent_id.choices = parent_choices
    
    if request.method == 'GET':
        form.parent_id.data = category.parent_id if category.parent_id else 0
    
    if form.validate_on_submit():
        # Aktualizuj kategorię
        category.name = form.name.data
        category.description = form.description.data
        category.parent_id = form.parent_id.data if form.parent_id.data > 0 else None
        category.color = form.color.data
        category.icon = form.icon.data
        category.sort_order = form.sort_order.data
        
        try:
            db.session.commit()
            flash(f'Kategoria "{category.name}" została zaktualizowana.', 'success')
            return redirect(url_for('categories.index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji kategorii: {str(e)}', 'danger')
    
    return render_template('categories/edit.html',
                          title=f'Edytuj kategorię: {category.name}',
                          form=form,
                          category=category)

@bp.route('/<int:category_id>/delete', methods=['POST'])
@login_required
def delete(category_id):
    """Usuń kategorię"""
    category = Category.query.get_or_404(category_id)
    
    # Sprawdź czy kategoria ma podkategorie
    subcategories = Category.query.filter_by(parent_id=category_id).count()
    if subcategories > 0:
        return jsonify({
            'success': False,
            'message': f'Nie można usunąć kategorii "{category.name}", ponieważ zawiera {subcategories} podkategorii.'
        })
    
    try:
        # Oznacz jako nieaktywną zamiast usuwać fizycznie
        category.is_active = False
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

@bp.route('/<int:category_id>')
@login_required
def view(category_id):
    """Widok pojedynczej kategorii z przypisanymi linkami"""
    category = Category.query.get_or_404(category_id)
    
    # Pobierz linki dla danej kategorii
    links = Link.query.filter(
        Link.categories.any(id=category_id),
        Link.is_active == True
    )
    
    # Dla zwykłych użytkowników pokaż tylko publiczne linki
    if not current_user.is_admin:
        links = links.filter(Link.is_public == True)
    
    links = links.order_by(Link.created_at.desc()).all()
    
    return render_template('categories/view.html',
                         title=f'Kategoria: {category.name}',
                         category=category,
                         links=links)

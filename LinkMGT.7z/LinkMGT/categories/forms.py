from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Length, Optional, NumberRange
from flask_login import current_user

class CategoryForm(FlaskForm):
    """Formularz do tworzenia i edycji kategorii"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=64)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=500)])
    parent_id = SelectField('Kategoria nadrzędna', coerce=int, validators=[Optional()])
    color = StringField('Kolor', validators=[Optional(), Length(max=7)], default='#3b82f6')
    icon = StringField('Ikona', validators=[Optional(), Length(max=50)], default='fas fa-folder')
    sort_order = IntegerField('Kolejność sortowania', validators=[Optional(), NumberRange(min=0)], default=0)
    submit = SubmitField('Zapisz')

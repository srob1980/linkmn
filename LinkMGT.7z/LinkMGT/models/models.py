from app import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from sqlalchemy import Table, Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship

# Define the association table first, before the models
user_team_table = Table(
    'user_team',
    db.metadata,
    Column('user_id', Integer, ForeignKey('users.id'), primary_key=True),
    Column('team_id', Integer, ForeignKey('teams.id'), primary_key=True),
    Column('role', Integer, default=0),  # 0=USER, 1=EDITOR, 2=ADMIN
    Column('joined_at', DateTime, default=datetime.utcnow),
    extend_existing=True
)

# Relacja wiele-do-wielu między Link i Category
link_category = db.Table('link_category',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('category_id', db.Integer, db.ForeignKey('categories.id'), primary_key=True)
)

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(128))
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    ad_dn = db.Column(db.String(255))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Flags
    is_active = db.Column(db.Boolean, default=True, index=True)
    is_admin = db.Column(db.Boolean, default=False)
    
    # Stats
    login_count = db.Column(db.Integer, default=0)
    
    # Relationships using the association table
    teams = relationship('Team', secondary=user_team_table, back_populates='members')
    created_links = relationship('Link', backref='creator', lazy='dynamic')
    created_teams = relationship('Team', backref='creator', foreign_keys='Team.created_by')
    created_categories = relationship('Category', backref='creator', foreign_keys='Category.created_by')
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @property
    def display_name(self):
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.username
    
    @property
    def initials(self):
        if self.first_name and self.last_name:
            return f"{self.first_name[0]}{self.last_name[0]}".upper()
        return self.username[:2].upper()
    
    def get_teams_count(self):
        """Bezpieczna metoda do liczenia zespołów"""
        try:
            return len(self.teams) if self.teams else 0
        except:
            return 0
    
    def get_links_count(self):
        """Bezpieczna metoda do liczenia linków"""
        try:
            return self.created_links.filter_by(is_active=True).count()
        except:
            return 0

class Team(db.Model):
    __tablename__ = 'teams'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False, index=True)
    description = db.Column(db.Text)
    color = db.Column(db.String(7), default='#007bff')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Flags
    is_active = db.Column(db.Boolean, default=True, index=True)
    
    # Foreign Keys
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships using the association table
    members = relationship('User', secondary=user_team_table, back_populates='teams')
    
    def __repr__(self):
        return f'<Team {self.name}>'
    
    def get_user_role(self, user_id):
        """Get user role in this team"""
        result = db.session.execute(
            user_team_table.select().where(
                user_team_table.c.user_id == user_id,
                user_team_table.c.team_id == self.id
            )
        ).first()
        return result.role if result else None
    
    def get_members_count(self):
        """Bezpieczna metoda do liczenia członków"""
        try:
            return len(self.members) if self.members else 0
        except:
            return 0

class UserTeam(db.Model):
    """Association object for User-Team relationship with additional data"""
    __tablename__ = 'user_team'
    __table_args__ = {'extend_existing': True}
    
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), primary_key=True)
    role = db.Column(db.Integer, default=0)  # 0=USER, 1=EDITOR, 2=ADMIN
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship('User', overlaps="teams,members")
    team = relationship('Team', overlaps="teams,members")
    
    def __repr__(self):
        return f'<UserTeam {self.user_id}-{self.team_id}>'
    
    @property
    def role_name(self):
        roles = {0: 'Użytkownik', 1: 'Edytor', 2: 'Administrator'}
        return roles.get(self.role, 'Nieznana')

class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False, index=True)
    description = db.Column(db.Text)
    color = db.Column(db.String(7), default='#2563eb')
    icon = db.Column(db.String(50), default='fas fa-folder')
    
    # Hierarchy support
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    sort_order = db.Column(db.Integer, default=0, index=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Flags
    is_active = db.Column(db.Boolean, default=True, index=True)
    
    # Foreign Keys
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    parent = relationship('Category', remote_side=[id], backref='children')
    links = relationship('Link', secondary=link_category, back_populates='categories', lazy='dynamic')

    def __repr__(self):
        return f'<Category {self.name}>'

class Tag(db.Model):
    __tablename__ = 'tags'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), unique=True, nullable=False, index=True)
    color = db.Column(db.String(7), default='#64748b')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Tag {self.name}>'

class Link(db.Model):
    __tablename__ = 'links'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False, index=True)
    url = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_accessed = db.Column(db.DateTime)
    last_checked = db.Column(db.DateTime)
    
    # Flags and metadata
    is_active = db.Column(db.Boolean, default=True, index=True)
    is_public = db.Column(db.Boolean, default=False)
    click_count = db.Column(db.Integer, default=0, index=True)
    status_code = db.Column(db.Integer, default=200)
    favicon_url = db.Column(db.String(500))
    
    # Foreign Keys
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'), index=True)

    # Relationships
    categories = relationship('Category', secondary=link_category, back_populates='links', lazy='dynamic')

    def __repr__(self):
        return f'<Link {self.title}>'

class AppConfig(db.Model):
    __tablename__ = 'app_config'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False, index=True)
    value = db.Column(db.String(256), nullable=False)
    description = db.Column(db.String(256))
    is_sensitive = db.Column(db.Boolean, default=False)
    category = db.Column(db.String(64), default='general')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<AppConfig {self.key}: {self.value}>'
    
    @staticmethod
    def get_value(key, default=None):
        """Pobierz wartość konfiguracji"""
        try:
            config = AppConfig.query.filter_by(key=key).first()
            return config.value if config else default
        except Exception:
            return default
    
    @staticmethod
    def set_value(key, value, description=None, is_sensitive=False, category='general'):
        """Ustaw wartość konfiguracji"""
        try:
            config = AppConfig.query.filter_by(key=key).first()
            if config:
                config.value = str(value)
                if description:
                    config.description = description
                config.is_sensitive = is_sensitive
                config.category = category
                config.updated_at = datetime.utcnow()
            else:
                config = AppConfig(
                    key=key,
                    value=str(value),
                    description=description,
                    is_sensitive=is_sensitive,
                    category=category
                )
                db.session.add(config)
            
            db.session.commit()
            return True
        except Exception as e:
            db.session.rollback()
            return False

class AuditLog(db.Model):
    __tablename__ = 'audit_log'
    
    id = db.Column(db.Integer, primary_key=True)
    table_name = db.Column(db.String(64), nullable=False, index=True)
    record_id = db.Column(db.Integer, nullable=False, index=True)
    action = db.Column(db.String(10), nullable=False)  # INSERT, UPDATE, DELETE
    old_values = db.Column(db.Text)  # JSON string
    new_values = db.Column(db.Text)  # JSON string
    changed_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    changed_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.Text)
    
    # Relationships
    user = relationship('User', backref='audit_logs')
    
    def __repr__(self):
        return f'<AuditLog {self.table_name}:{self.record_id} {self.action}>'
    
    @staticmethod
    def log_change(table_name, record_id, action, old_values=None, new_values=None, user_id=None, ip_address=None, user_agent=None):
        """Zapisz wpis w audyt logu"""
        try:
            import json
            
            log_entry = AuditLog(
                table_name=table_name,
                record_id=record_id,
                action=action,
                old_values=json.dumps(old_values) if old_values else None,
                new_values=json.dumps(new_values) if new_values else None,
                changed_by=user_id,
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            db.session.add(log_entry)
            db.session.commit()
            return True
            
        except Exception as e:
            db.session.rollback()
            print(f"Błąd zapisywania audyt logu: {e}")
            return False

from app import login_manager

# Import all models from separate files
from app.models.models import (
    User, Team, UserTeam, Category, Tag, Link, 
    AppConfig, AuditLog, user_team_table
)

# Import infrastructure models with error handling
try:
    from app.models.infrastructure import (
        Location, Vendor, AssetStatus, AssetType, Asset, 
        MaintenanceLog, License, SupportContract, PriorityLevel, ContractStatus
    )
    __all__ = [
        'User', 'Team', 'UserTeam', 'Category', 'Tag', 'Link', 
        'AppConfig', 'AuditLog', 'user_team_table',
        'Location', 'Vendor', 'AssetStatus', 'AssetType', 'Asset', 
        'MaintenanceLog', 'License', 'SupportContract', 'PriorityLevel', 'ContractStatus'
    ]
except ImportError as e:
    print(f"Infrastructure models not available: {e}")
    __all__ = [
        'User', 'Team', 'UserTeam', 'Category', 'Tag', 'Link', 
        'AppConfig', 'AuditLog', 'user_team_table'
    ]

@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login"""
    try:
        return User.query.get(int(user_id))
    except Exception:
        return None
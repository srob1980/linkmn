from app import db
from datetime import datetime
from sqlalchemy import Enum
import enum

# Custom enums for type safety
class AssetStatus(enum.Enum):
    ACTIVE = 'ACTIVE'
    INACTIVE = 'INACTIVE'
    MAINTENANCE = 'MAINTENANCE'
    DECOMMISSIONED = 'DECOMMISSIONED'

class PriorityLevel(enum.Enum):
    LOW = 'LOW'
    MEDIUM = 'MEDIUM'
    HIGH = 'HIGH'
    CRITICAL = 'CRITICAL'

class ContractStatus(enum.Enum):
    ACTIVE = 'ACTIVE'
    EXPIRED = 'EXPIRED'
    PENDING = 'PENDING'
    CANCELLED = 'CANCELLED'

class Location(db.Model):
    __tablename__ = 'locations'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text)
    city = db.Column(db.String(50))
    country = db.Column(db.String(50))
    postal_code = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    assets = db.relationship('Asset', backref='location', lazy='dynamic')
    
    def __repr__(self):
        return f'<Location {self.name}>'

class Vendor(db.Model):
    __tablename__ = 'vendors'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_person = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(30))
    address = db.Column(db.Text)
    city = db.Column(db.String(50))
    country = db.Column(db.String(50))
    website = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    assets = db.relationship('Asset', backref='vendor', lazy='dynamic')
    licenses = db.relationship('License', backref='vendor', lazy='dynamic')
    support_contracts = db.relationship('SupportContract', backref='vendor', lazy='dynamic')
    
    def __repr__(self):
        return f'<Vendor {self.name}>'

class AssetType(db.Model):
    __tablename__ = 'asset_types'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    icon = db.Column(db.String(50), default='fas fa-server')
    color = db.Column(db.String(7), default='#6b7280')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    assets = db.relationship('Asset', backref='asset_type', lazy='dynamic')
    
    def __repr__(self):
        return f'<AssetType {self.name}>'

class Asset(db.Model):
    __tablename__ = 'assets'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    asset_tag = db.Column(db.String(50), unique=True)
    serial_number = db.Column(db.String(100))
    model = db.Column(db.String(100))
    manufacturer = db.Column(db.String(100))
    asset_type_id = db.Column(db.Integer, db.ForeignKey('asset_types.id'))
    location_id = db.Column(db.Integer, db.ForeignKey('locations.id'))
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendors.id'))
    status = db.Column(db.String(20), default='ACTIVE')
    purchase_date = db.Column(db.Date)
    warranty_end = db.Column(db.Date)
    value = db.Column(db.Numeric(10, 2))
    description = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    mac_address = db.Column(db.String(17))
    operating_system = db.Column(db.String(100))
    cpu = db.Column(db.String(100))
    memory_gb = db.Column(db.Integer)
    storage_gb = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    maintenance_logs = db.relationship('MaintenanceLog', backref='asset', lazy='dynamic')
    
    def __repr__(self):
        return f'<Asset {self.name}>'

class License(db.Model):
    __tablename__ = 'licenses'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    software = db.Column(db.String(100), nullable=False)
    license_key = db.Column(db.Text)
    license_type = db.Column(db.String(50))
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendors.id'))
    purchase_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date)
    seats = db.Column(db.Integer, default=1)
    used_seats = db.Column(db.Integer, default=0)
    cost = db.Column(db.Numeric(10, 2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    def __repr__(self):
        return f'<License {self.name}>'

class SupportContract(db.Model):
    __tablename__ = 'support_contracts'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendors.id'))
    contract_number = db.Column(db.String(50))
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default='ACTIVE')
    cost = db.Column(db.Numeric(10, 2))
    description = db.Column(db.Text)
    contact_info = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    def __repr__(self):
        return f'<SupportContract {self.name}>'

class MaintenanceLog(db.Model):
    __tablename__ = 'maintenance_log'
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('assets.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    maintenance_type = db.Column(db.String(50))
    priority = db.Column(db.String(20), default='MEDIUM')
    scheduled_date = db.Column(db.DateTime)
    completed_date = db.Column(db.DateTime)
    performed_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    cost = db.Column(db.Numeric(10, 2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    def __repr__(self):
        return f'<MaintenanceLog {self.title}>'
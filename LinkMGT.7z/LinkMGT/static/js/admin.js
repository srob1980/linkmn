/**
 * Admin panel JavaScript functions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Initialize date pickers
    initDatePickers();
    
    // Handle database type change
    setupDatabaseTypeHandler();
    
    // Auto-update system resources
    if (document.querySelector('.system-resource-item')) {
        setInterval(updateSystemResources, 30000); // Update every 30 seconds
    }
    
    // Enable copy to clipboard functionality
    setupClipboardCopy();
});

/**
 * Initialize date picker inputs
 */
function initDatePickers() {
    // Use native date inputs or initialize a date picker library here
    // This is a placeholder for when you need more advanced date picking
}

/**
 * Setup database type change handler
 */
function setupDatabaseTypeHandler() {
    const dbTypeSelect = document.getElementById('db_type');
    if (!dbTypeSelect) return;
    
    dbTypeSelect.addEventListener('change', function() {
        updateDatabaseConfigForm();
    });
    
    // Call once on page load
    updateDatabaseConfigForm();
    
    function updateDatabaseConfigForm() {
        const dbType = dbTypeSelect.value;
        const sqliteConfig = document.getElementById('sqlite-config');
        const otherDbConfig = document.getElementById('other-db-config');
        const oracleConfig = document.getElementById('oracle-config');
        
        if (!sqliteConfig || !otherDbConfig) return;
        
        if (dbType === 'sqlite') {
            sqliteConfig.style.display = 'block';
            otherDbConfig.style.display = 'none';
        } else {
            sqliteConfig.style.display = 'none';
            otherDbConfig.style.display = 'block';
            
            if (oracleConfig) {
                oracleConfig.style.display = dbType === 'oracle' ? 'block' : 'none';
            }
        }
    }
}

/**
 * Update system resources via AJAX
 */
function updateSystemResources() {
    fetch('/admin/system_resources')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateResourcesDisplay(data.resources);
            }
        })
        .catch(error => console.error('Error fetching system resources:', error));
}

/**
 * Update resources display with new data
 */
function updateResourcesDisplay(resources) {
    // Update CPU stats
    updateResourceItem(0, resources.cpu.usage_percent, 
        `${resources.cpu.usage_percent}%`, 
        `Rdzenie fizyczne: ${resources.cpu.physical_count} | Wątki logiczne: ${resources.cpu.count}`);
    
    // Update RAM stats
    updateResourceItem(1, resources.memory.percent, 
        `${resources.memory.percent}%`,
        `Wykorzystane: ${resources.memory.used_gb} GB | Całkowite: ${resources.memory.total_gb} GB`);
    
    // Update Disk stats
    updateResourceItem(2, resources.disk.percent, 
        `${resources.disk.percent}%`,
        `Wykorzystane: ${resources.disk.used_gb} GB | Całkowite: ${resources.disk.total_gb} GB`);
}

/**
 * Update individual resource item display
 */
function updateResourceItem(index, percent, valueText, detailsText) {
    const items = document.querySelectorAll('.system-resource-item');
    if (!items || items.length <= index) return;
    
    const item = items[index];
    
    // Update percentage text
    const valueElement = item.querySelector('.fw-bold');
    if (valueElement) valueElement.textContent = valueText;
    
    // Update progress bar
    const progressBar = item.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = `${percent}%`;
        progressBar.setAttribute('aria-valuenow', percent);
        
        // Update color based on value
        progressBar.classList.remove('bg-success', 'bg-warning', 'bg-danger');
        if (percent > 80) {
            progressBar.classList.add('bg-danger');
        } else if (percent > 60) {
            progressBar.classList.add('bg-warning');
        } else {
            progressBar.classList.add('bg-success');
        }
    }
    
    // Update details text if available
    const detailsElement = item.querySelector('.text-muted');
    if (detailsElement && detailsText) detailsElement.textContent = detailsText;
}

/**
 * Setup clipboard copy functionality
 */
function setupClipboardCopy() {
    const copyButtons = document.querySelectorAll('.copy-to-clipboard');
    
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const textToCopy = this.getAttribute('data-copy-text');
            const originalText = this.innerHTML;
            
            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy).then(() => {
                    this.innerHTML = '<i class="fas fa-check me-1"></i>Skopiowano';
                    setTimeout(() => {
                        this.innerHTML = originalText;
                    }, 2000);
                }).catch(err => {
                    console.error('Nie udało się skopiować: ', err);
                });
            }
        });
    });
}

/**
 * Confirm action with modal
 */
function confirmAction(actionText, actionUrl, itemName, dangerMode = false) {
    const modal = document.getElementById('confirmActionModal');
    if (!modal) return false;
    
    const modalTitle = modal.querySelector('.modal-title');
    const modalBody = modal.querySelector('.modal-body');
    const actionButton = modal.querySelector('#confirmActionButton');
    const actionForm = modal.querySelector('#confirmActionForm');
    
    if (modalTitle) modalTitle.textContent = actionText;
    if (modalBody) modalBody.innerHTML = `Czy na pewno chcesz ${actionText.toLowerCase()} <strong>${itemName}</strong>?`;
    if (actionForm) actionForm.action = actionUrl;
    
    if (actionButton) {
        actionButton.textContent = actionText;
        actionButton.classList.remove('btn-danger', 'btn-warning');
        actionButton.classList.add(dangerMode ? 'btn-danger' : 'btn-warning');
    }
    
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    
    return false;
}

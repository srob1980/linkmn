document.addEventListener('DOMContentLoaded', function() {
    // Database configuration handlers
    const dbTypeSelect = document.getElementById('dbType');
    const sqliteConfig = document.getElementById('sqliteConfig');
    const otherDbConfig = document.getElementById('otherDbConfig');
    const oracleConfig = document.getElementById('oracleConfig');
    const testConnectionBtn = document.getElementById('testConnection');

    if (dbTypeSelect) {
        dbTypeSelect.addEventListener('change', updateDbConfigForm);
        updateDbConfigForm();
    }

    function updateDbConfigForm() {
        const dbType = dbTypeSelect.value;
        sqliteConfig.classList.toggle('d-none', dbType !== 'sqlite');
        otherDbConfig.classList.toggle('d-none', dbType === 'sqlite');
        oracleConfig.classList.toggle('d-none', dbType !== 'oracle');
    }

    // Test database connection
    if (testConnectionBtn) {
        testConnectionBtn.addEventListener('click', async function() {
            const formData = new FormData(document.getElementById('dbConfigForm'));
            const data = {
                type: formData.get('type'),
                host: formData.get('host'),
                port: formData.get('port'),
                name: formData.get('name'),
                user: formData.get('user'),
                password: formData.get('password')
            };

            try {
                const response = await fetch('/admin/database/test', {  // Updated endpoint
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify(data)
                });

                const result = await response.json();
                if (result.success) {
                    showAlert('success', 'Połączenie z bazą danych udane!');
                } else {
                    showAlert('danger', `Błąd połączenia: ${result.error}`);
                }
            } catch (error) {
                showAlert('danger', 'Wystąpił błąd podczas testowania połączenia');
            }
        });
    }

    // SSL configuration
    const enableSSL = document.getElementById('enableSSL');
    const sslConfig = document.getElementById('sslConfig');

    if (enableSSL) {
        enableSSL.addEventListener('change', function() {
            sslConfig.classList.toggle('d-none', !this.checked);
        });
    }

    // AD configuration
    const enableAD = document.getElementById('enableAD');
    const adSettings = document.getElementById('adSettings');
    const testADBtn = document.getElementById('testAD');

    if (enableAD) {
        enableAD.addEventListener('change', function() {
            adSettings.classList.toggle('d-none', !this.checked);
        });
    }

    if (testADBtn) {
        testADBtn.addEventListener('click', async function() {
            const formData = new FormData(document.getElementById('adConfigForm'));
            try {
                const response = await fetch('/admin/test_ad_connection', {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: formData
                });

                const result = await response.json();
                showAlert(result.success ? 'success' : 'danger', result.message);
            } catch (error) {
                showAlert('danger', 'Wystąpił błąd podczas testowania połączenia z AD');
            }
        });
    }

    // Logging configuration
    const logToFile = document.getElementById('logToFile');
    const fileLoggingSettings = document.getElementById('fileLoggingSettings');

    if (logToFile) {
        logToFile.addEventListener('change', function() {
            fileLoggingSettings.classList.toggle('d-none', !this.checked);
        });
    }

    // Helper function to show alerts
    function showAlert(type, message) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;

        const container = document.querySelector('.container-fluid');
        container.insertBefore(alertDiv, container.firstChild);

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            alertDiv.classList.remove('show');
            setTimeout(() => alertDiv.remove(), 150);
        }, 5000);
    }
});

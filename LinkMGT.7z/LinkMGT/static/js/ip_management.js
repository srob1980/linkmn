function checkIpStatus(ipId) {
    fetch(`/admin/api/ip/check-status/${ipId}`)
        .then(response => response.json())
        .then(data => {
            const statusBadge = document.querySelector(`#ip-${ipId} .status-badge`);
            const hostnameSpan = document.querySelector(`#ip-${ipId} .hostname`);
            const lastSeenSpan = document.querySelector(`#ip-${ipId} .last-seen`);
            
            statusBadge.className = `badge status-badge bg-${getStatusColor(data.status)}`;
            statusBadge.textContent = data.status;
            
            if (data.hostname) {
                hostnameSpan.textContent = data.hostname;
            }
            
            if (data.last_seen) {
                lastSeenSpan.textContent = new Date(data.last_seen).toLocaleString();
            }
        })
        .catch(error => console.error('Error checking IP status:', error));
}

function getStatusColor(status) {
    switch (status) {
        case 'used': return 'success';
        case 'reserved': return 'warning';
        default: return 'secondary';
    }
}

function checkAllIpStatuses() {
    document.querySelectorAll('[data-ip-id]').forEach(el => {
        checkIpStatus(el.dataset.ipId);
    });
}

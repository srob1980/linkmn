/**
 * Utility functions for LinkMGT application
 */

// Copy text to clipboard
function copyToClipboard(text, successMessage = 'Skopiowano do schowka!') {
    if (!navigator.clipboard) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            const successful = document.execCommand('copy');
            const msg = successful ? successMessage : 'Nie udało się skopiować';
            showToast(msg, successful ? 'success' : 'danger');
        } catch (err) {
            showToast('Błąd kopiowania: ' + err, 'danger');
        }
        
        document.body.removeChild(textArea);
        return;
    }
    
    // Modern approach
    navigator.clipboard.writeText(text).then(function() {
        showToast(successMessage, 'success');
    }, function(err) {
        showToast('Nie udało się skopiować: ' + err, 'danger');
    });
}

// Show a toast notification
function showToast(message, type = 'info', duration = 3000) {
    let toastContainer = document.getElementById('toast-container');
    
    // Create container if it doesn't exist
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast align-items-center text-white bg-${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    // Toast content
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add to container
    toastContainer.appendChild(toast);
    
    // Initialize and show
    const bsToast = new bootstrap.Toast(toast, {
        animation: true,
        autohide: true,
        delay: duration
    });
    
    bsToast.show();
    
    // Remove after hiding
    toast.addEventListener('hidden.bs.toast', function () {
        this.remove();
    });
}

// Format a date to a readable string
function formatDate(dateString, format = 'short') {
    if (!dateString) return '—';
    
    const date = new Date(dateString);
    
    if (isNaN(date.getTime())) {
        return dateString;
    }
    
    if (format === 'short') {
        return date.toLocaleDateString('pl-PL');
    } else if (format === 'long') {
        return date.toLocaleDateString('pl-PL', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
    } else if (format === 'datetime') {
        return date.toLocaleDateString('pl-PL', { 
            year: 'numeric', 
            month: 'numeric', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    return dateString;
}

// Format currency
function formatCurrency(amount, currency = 'PLN') {
    if (amount === null || amount === undefined) return '—';
    
    return new Intl.NumberFormat('pl-PL', { 
        style: 'currency', 
        currency: currency 
    }).format(amount);
}

// Confirm delete with modal
function confirmDelete(itemId, itemName, itemType = 'element', deleteUrl) {
    const modalElement = document.getElementById('deleteModal');
    if (!modalElement) {
        console.error('Delete modal not found in the DOM');
        return;
    }
    
    // Set item name and type in the modal
    const nameElement = document.getElementById('itemName');
    const typeElement = document.getElementById('itemType');
    
    if (nameElement) nameElement.textContent = itemName;
    if (typeElement) typeElement.textContent = itemType;
    
    // Set form action
    const form = document.getElementById('deleteForm');
    if (form && deleteUrl) {
        form.action = deleteUrl.replace('0', itemId);
    }
    
    // Show modal
    const modal = new bootstrap.Modal(modalElement);
    modal.show();
}

// Initialize all tooltips on a page
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Initialize all popovers on a page
function initPopovers() {
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

// DOM Ready Event
document.addEventListener('DOMContentLoaded', function() {
    initTooltips();
    initPopovers();
    
    // Initialize any toast containers
    if (!document.getElementById('toast-container')) {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }
});

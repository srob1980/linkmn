/**
 * LinkMGT - Main Application JavaScript
 */

// Initialize all tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide alerts after 5 seconds
    var autoHideAlerts = document.querySelectorAll('.alert-dismissible:not(.alert-persistent)');
    autoHideAlerts.forEach(function(alert) {
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Tag input handler
    var tagInputs = document.querySelectorAll('.tag-input');
    tagInputs.forEach(function(input) {
        initTagInput(input);
    });
    
    // Confirm dialogs
    document.querySelectorAll('[data-confirm]').forEach(function(element) {
        element.addEventListener('click', function(e) {
            if (!confirm(this.dataset.confirm)) {
                e.preventDefault();
                return false;
            }
        });
    });
});

// Tag input functionality
function initTagInput(input) {
    if (!input) return;
    
    var hiddenInput = document.createElement('input');
    hiddenInput.type = 'hidden';
    hiddenInput.name = input.name;
    hiddenInput.value = input.value;
    input.parentNode.appendChild(hiddenInput);
    
    var tagContainer = document.createElement('div');
    tagContainer.className = 'tag-container d-flex flex-wrap gap-2 mb-2';
    input.parentNode.insertBefore(tagContainer, input);
    
    var tags = hiddenInput.value ? hiddenInput.value.split(',').map(t => t.trim()).filter(t => t) : [];
    
    // Initialize with existing tags
    renderTags();
    
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            addTag(this.value.trim());
            this.value = '';
        }
    });
    
    input.addEventListener('blur', function() {
        if (this.value.trim()) {
            addTag(this.value.trim());
            this.value = '';
        }
    });
    
    function addTag(tag) {
        if (tag && !tags.includes(tag)) {
            tags.push(tag);
            renderTags();
            updateInputValue();
        }
    }
    
    function removeTag(tag) {
        tags = tags.filter(t => t !== tag);
        renderTags();
        updateInputValue();
    }
    
    function renderTags() {
        tagContainer.innerHTML = '';
        tags.forEach(tag => {
            var tagElement = document.createElement('span');
            tagElement.className = 'badge bg-primary d-flex align-items-center';
            tagElement.innerHTML = `
                ${tag}
                <button type="button" class="btn-close btn-close-white ms-2" aria-label="Close" style="font-size: 0.5rem;"></button>
            `;
            tagElement.querySelector('.btn-close').addEventListener('click', function() {
                removeTag(tag);
            });
            tagContainer.appendChild(tagElement);
        });
    }
    
    function updateInputValue() {
        hiddenInput.value = tags.join(',');
    }
}

// Track link clicks
function trackLink(linkId, redirectToLink = true) {
    if (!linkId) return;
    
    fetch('/links/' + linkId + '/track', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (redirectToLink && data.url) {
            window.open(data.url, '_blank');
        }
    })
    .catch(error => console.error('Error tracking link:', error));
}

// Custom JavaScript for LinkMGT application

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide alert messages after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Sidebar toggle functionality
    var sidebarCollapse = document.getElementById('sidebarCollapse');
    var sidebarCollapseMain = document.getElementById('sidebarCollapseMain');
    var sidebar = document.getElementById('sidebar');
    var content = document.getElementById('content');
    var body = document.body;
    
    // Create overlay div for mobile
    var overlay = document.createElement('div');
    overlay.className = 'overlay';
    body.appendChild(overlay);
    
    function toggleSidebar() {
        sidebar.classList.toggle('active');
        
        // Handle overlay for mobile view
        if (window.innerWidth < 768) {
            if (sidebar.classList.contains('active')) {
                overlay.classList.add('active');
                body.style.overflow = 'hidden';
            } else {
                overlay.classList.remove('active');
                body.style.overflow = '';
            }
        }
    }
    
    if (sidebarCollapse) {
        sidebarCollapse.addEventListener('click', toggleSidebar);
    }
    
    if (sidebarCollapseMain) {
        sidebarCollapseMain.addEventListener('click', toggleSidebar);
    }
    
    // Close sidebar when clicking on overlay
    overlay.addEventListener('click', function() {
        if (sidebar.classList.contains('active')) {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            body.style.overflow = '';
        }
    });
    
    // Close sidebar when window resizes to larger screen
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 768 && sidebar.classList.contains('active') && overlay.classList.contains('active')) {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            body.style.overflow = '';
        }
    });
    
    // Expand sidebar dropdown if active page is inside
    var activeLinks = document.querySelectorAll('.sidebar-nav .nav-link.active');
    activeLinks.forEach(function(link) {
        var parent = link.closest('.collapse');
        if (parent) {
            var parentToggle = document.querySelector('[data-bs-toggle="collapse"][href="#' + parent.id + '"]');
            if (parentToggle) {
                parentToggle.classList.remove('collapsed');
                parentToggle.setAttribute('aria-expanded', 'true');
                new bootstrap.Collapse(parent, { toggle: true });
            }
        }
    });
});

// Function to track link clicks
function trackLink(linkId) {
    // Only execute if linkId is provided
    if (!linkId) return;
    
    fetch('/links/' + linkId + '/track', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    }).catch(error => console.error('Error tracking link:', error));
}

// Function to confirm deletions
function confirmDelete(itemId, itemName, itemType = 'item', actionUrl = null) {
    if (!itemId) return;
    
    var deleteModal = document.getElementById('deleteModal');
    if (!deleteModal) return;
    
    // Set the item name in the modal
    var nameElement = document.getElementById('itemName');
    if (nameElement) {
        nameElement.textContent = itemName;
    }
    
    // Set the item type in the modal
    var typeElement = document.getElementById('itemType');
    if (typeElement) {
        typeElement.textContent = itemType;
    }
    
    // Set the form action
    var deleteForm = document.getElementById('deleteForm');
    if (deleteForm && actionUrl) {
        deleteForm.action = actionUrl.replace('0', itemId);
    }
    
    // Show the modal
    var modal = new bootstrap.Modal(deleteModal);
    modal.show();
}

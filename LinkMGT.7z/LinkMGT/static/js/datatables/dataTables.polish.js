(function(window, document, undefined) {
    var factory = function($, DataTable) {
        "use strict";
        
        $.extend(true, DataTable.defaults.oLanguage, {
            "sProcessing":     "Przetwarzanie...",
            "sSearch":         "Szukaj:",
            "sLengthMenu":     "Pokaż _MENU_ pozycji",
            "sInfo":          "Pozycje od _START_ do _END_ z _TOTAL_ łącznie",
            "sInfoEmpty":      "Pozycji 0 z 0 dostępnych",
            "sInfoFiltered":   "(filtrowanie spośród _MAX_ dostępnych pozycji)",
            "sInfoPostFix":    "",
            "sLoadingRecords": "Wczytywanie...",
            "sZeroRecords":    "Nie znaleziono pasujących pozycji",
            "sEmptyTable":     "Brak danych",
            "oPaginate": {
                "sFirst":      "Pierwsza",
                "sPrevious":   "Poprzednia",
                "sNext":       "Następna",
                "sLast":       "Ostatnia"
            },
            "oAria": {
                "sSortAscending":  ": aktywuj, by posortować kolumnę rosnąco",
                "sSortDescending": ": aktywuj, by posortować kolumnę malejąco"
            }
        });
    };

    // Define as an AMD module
    if (typeof define === 'function' && define.amd) {
        define(['jquery', 'datatables.net'], factory);
    }
    else if (typeof exports === 'object') {
        // Node/CommonJS
        module.exports = function (root, $) {
            if (!root) {
                root = window;
            }
            if (!$ || !$.fn.dataTable) {
                $ = require('datatables.net')(root, $).$;
            }
            return factory($, $.fn.dataTable);
        };
    }
    else {
        // Browser
        factory(jQuery, jQuery.fn.dataTable);
    }
})(window, document);

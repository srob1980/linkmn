/**
 * Admin dashboard charts and visualizations
 */
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh system resources every 30 seconds
    setInterval(function() {
        fetchSystemResources();
    }, 30000);
    
    // Initialize tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
});

/**
 * Fetch updated system resources data via AJAX
 */
function fetchSystemResources() {
    fetch('/admin/system_resources')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateSystemResources(data.resources);
            }
        })
        .catch(error => console.error('Error fetching system resources:', error));
}

/**
 * Update the system resources display with new data
 */
function updateSystemResources(resources) {
    // Update CPU usage
    const cpuUsage = document.querySelector('.system-resource-item:nth-child(1) .fw-bold');
    const cpuProgressBar = document.querySelector('.system-resource-item:nth-child(1) .progress-bar');
    
    if (cpuUsage && cpuProgressBar) {
        cpuUsage.textContent = `${resources.cpu.usage_percent}%`;
        cpuProgressBar.style.width = `${resources.cpu.usage_percent}%`;
        cpuProgressBar.setAttribute('aria-valuenow', resources.cpu.usage_percent);
        
        // Update progress bar color based on usage
        cpuProgressBar.className = 'progress-bar';
        if (resources.cpu.usage_percent > 80) {
            cpuProgressBar.classList.add('bg-danger');
        } else if (resources.cpu.usage_percent > 60) {
            cpuProgressBar.classList.add('bg-warning');
        } else {
            cpuProgressBar.classList.add('bg-success');
        }
    }
    
    // Update Memory usage
    const memoryUsage = document.querySelector('.system-resource-item:nth-child(2) .fw-bold');
    const memoryProgressBar = document.querySelector('.system-resource-item:nth-child(2) .progress-bar');
    const memoryText = document.querySelector('.system-resource-item:nth-child(2) .text-muted');
    
    if (memoryUsage && memoryProgressBar && memoryText) {
        memoryUsage.textContent = `${resources.memory.percent}%`;
        memoryProgressBar.style.width = `${resources.memory.percent}%`;
        memoryProgressBar.setAttribute('aria-valuenow', resources.memory.percent);
        memoryText.textContent = `${resources.memory.used_gb} GB / ${resources.memory.total_gb} GB`;
        
        // Update progress bar color based on usage
        memoryProgressBar.className = 'progress-bar';
        if (resources.memory.percent > 80) {
            memoryProgressBar.classList.add('bg-danger');
        } else if (resources.memory.percent > 60) {
            memoryProgressBar.classList.add('bg-warning');
        } else {
            memoryProgressBar.classList.add('bg-success');
        }
    }
    
    // Update Disk usage
    const diskUsage = document.querySelector('.system-resource-item:nth-child(3) .fw-bold');
    const diskProgressBar = document.querySelector('.system-resource-item:nth-child(3) .progress-bar');
    const diskText = document.querySelector('.system-resource-item:nth-child(3) .text-muted');
    
    if (diskUsage && diskProgressBar && diskText) {
        diskUsage.textContent = `${resources.disk.percent}%`;
        diskProgressBar.style.width = `${resources.disk.percent}%`;
        diskProgressBar.setAttribute('aria-valuenow', resources.disk.percent);
        diskText.textContent = `${resources.disk.used_gb} GB / ${resources.disk.total_gb} GB`;
        
        // Update progress bar color based on usage
        diskProgressBar.className = 'progress-bar';
        if (resources.disk.percent > 80) {
            diskProgressBar.classList.add('bg-danger');
        } else if (resources.disk.percent > 60) {
            diskProgressBar.classList.add('bg-warning');
        } else {
            diskProgressBar.classList.add('bg-success');
        }
    }
}

/**
 * Admin dashboard charts
 */

// Initialize activity chart
function initActivityChart(chartId, labels, datasets) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    // Chart configuration
    const config = {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Logowania',
                    data: datasets.logins,
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.1)',
                    borderWidth: 2,
                    pointRadius: 3,
                    fill: true,
                    tension: 0.2
                },
                {
                    label: 'Dodane linki',
                    data: datasets.links,
                    borderColor: '#1cc88a',
                    backgroundColor: 'rgba(28, 200, 138, 0.1)',
                    borderWidth: 2,
                    pointRadius: 3,
                    fill: true,
                    tension: 0.2
                },
                {
                    label: 'Akcje',
                    data: datasets.actions,
                    borderColor: '#f6c23e',
                    backgroundColor: 'rgba(246, 194, 62, 0.1)',
                    borderWidth: 2,
                    pointRadius: 3,
                    fill: true,
                    tension: 0.2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        }
    };
    
    // Create chart
    return new Chart(ctx, config);
}

// Initialize resource usage gauge charts
function initResourceGauges() {
    const cpuGauge = document.getElementById('cpuGauge');
    const memoryGauge = document.getElementById('memoryGauge');
    const diskGauge = document.getElementById('diskGauge');
    
    if (!cpuGauge || !memoryGauge || !diskGauge) return;
    
    const cpuValue = parseFloat(cpuGauge.getAttribute('data-value') || 0);
    const memoryValue = parseFloat(memoryGauge.getAttribute('data-value') || 0);
    const diskValue = parseFloat(diskGauge.getAttribute('data-value') || 0);
    
    const gaugeOptions = {
        angle: 0.15,
        lineWidth: 0.44,
        radiusScale: 1,
        pointer: {
            length: 0.6,
            strokeWidth: 0.035,
            color: '#000000'
        },
        limitMax: true,
        limitMin: true,
        colorStart: '#1cc88a',
        colorStop: '#1cc88a',
        strokeColor: '#e0e0e0',
        generateGradient: true,
        highDpiSupport: true,
        percentColors: [
            [0.0, "#1cc88a"],   // green below 50%
            [0.5, "#f6c23e"],   // yellow 50-75%
            [0.75, "#e74a3b"]   // red above 75%
        ],
    };
    
    const cpuGaugeInstance = new Gauge(cpuGauge).setOptions(gaugeOptions);
    cpuGaugeInstance.maxValue = 100;
    cpuGaugeInstance.setMinValue(0);
    cpuGaugeInstance.animationSpeed = 32;
    cpuGaugeInstance.set(cpuValue);
    
    const memoryGaugeInstance = new Gauge(memoryGauge).setOptions(gaugeOptions);
    memoryGaugeInstance.maxValue = 100;
    memoryGaugeInstance.setMinValue(0);
    memoryGaugeInstance.animationSpeed = 32;
    memoryGaugeInstance.set(memoryValue);
    
    const diskGaugeInstance = new Gauge(diskGauge).setOptions(gaugeOptions);
    diskGaugeInstance.maxValue = 100;
    diskGaugeInstance.setMinValue(0);
    diskGaugeInstance.animationSpeed = 32;
    diskGaugeInstance.set(diskValue);
}

// Document ready function
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });
    
    // Initialize popovers
    const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
    popovers.forEach(popover => {
        new bootstrap.Popover(popover);
    });
    
    // Initialize activity chart if element exists
    const activityChart = document.getElementById('userActivityChart');
    if (activityChart) {
        // Get chart data from data attributes or a global variable
        const labels = window.chartData?.labels || [];
        const datasets = window.chartData?.datasets || { logins: [], links: [], actions: [] };
        
        if (labels.length > 0) {
            initActivityChart('userActivityChart', labels, datasets);
        }
    }
    
    // Initialize resource gauges
    initResourceGauges();
    
    // Initialize real-time updates
    startRealtimeUpdates();
});

function initializeCharts(data) {
    // Resource usage chart
    const resourceCtx = document.getElementById('resourcesChart');
    if (resourceCtx) {
        new Chart(resourceCtx, {
            type: 'line',
            data: {
                labels: data.timestamps,
                datasets: [
                    {
                        label: 'CPU',
                        data: data.cpu,
                        borderColor: '#0d6efd',
                        tension: 0.4
                    },
                    {
                        label: 'RAM',
                        data: data.memory,
                        borderColor: '#198754',
                        tension: 0.4
                    },
                    {
                        label: 'Dysk',
                        data: data.disk,
                        borderColor: '#dc3545',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: value => value + '%'
                        }
                    }
                }
            }
        });
    }
}

// Update charts with new data
function updateCharts(period) {
    fetch(`/admin/metrics?period=${period}`)
        .then(response => response.json())
        .then(data => {
            initializeCharts(data);
        })
        .catch(error => console.error('Error updating charts:', error));
}

// Initialize real-time updates
let updateInterval;
function startRealtimeUpdates(interval = 30000) {
    if (updateInterval) clearInterval(updateInterval);
    updateInterval = setInterval(() => updateCharts('hour'), interval);
}

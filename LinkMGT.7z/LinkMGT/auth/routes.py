from flask import render_template, redirect, url_for, flash, request
from flask_login import current_user, login_user, logout_user
from app.auth import bp
from app.auth.forms import LoginForm, RegistrationForm
from app.models import User, AppConfig
from app import db
import re

def is_valid_email(email):
    """Sprawdź czy email jest poprawny"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            user.login_count += 1
            user.last_login = db.func.now()
            db.session.commit()
            
            next_page = request.args.get('next')
            if not next_page or not next_page.startswith('/'):
                next_page = url_for('main.index')
                
            flash(f'Zalogowano jako {user.username}', 'success')
            return redirect(next_page)
        else:
            flash('Nieprawidłowa nazwa użytkownika lub hasło', 'danger')
    
    return render_template('auth/login.html', title='Logowanie', form=form)

@bp.route('/logout')
def logout():
    logout_user()
    flash('Zostałeś wylogowany.', 'info')
    return redirect(url_for('auth.login'))

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    # Sprawdź czy rejestracja jest włączona
    registration_enabled = AppConfig.get_value('ENABLE_USER_REGISTRATION', 'true').lower() == 'true'
    if not registration_enabled:
        flash('Rejestracja użytkowników jest obecnie wyłączona.', 'warning')
        return redirect(url_for('auth.login'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            is_admin=False,
            is_active=True
        )
        user.set_password(form.password.data)
        
        try:
            db.session.add(user)
            db.session.commit()
            flash('Rejestracja zakończona sukcesem! Możesz się teraz zalogować.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas rejestracji: {str(e)}', 'danger')
    
    return render_template('auth/register.html', title='Rejestracja', form=form)

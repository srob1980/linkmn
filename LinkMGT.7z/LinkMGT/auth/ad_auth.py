import ldap3
from flask import current_app
from app.models import AppConfig, User
from app import db

def test_ad_connection(server, domain, username, password):
    """Testuj połączenie z Active Directory"""
    try:
        # Utwórz połączenie z serwerem AD
        server_obj = ldap3.Server(server, get_info=ldap3.ALL)
        
        # Utwórz użytkownika do uwierzytelniania
        user_dn = f"{username}@{domain}"
        
        # Spróbuj się połączyć
        conn = ldap3.Connection(server_obj, user=user_dn, password=password, authentication=ldap3.SIMPLE)
        
        if conn.bind():
            conn.unbind()
            return True, "Połączenie z Active Directory udane"
        else:
            return False, f"Błąd uwierzytelniania: {conn.result}"
            
    except Exception as e:
        return False, f"Błąd połączenia: {str(e)}"

def authenticate_ad_user(username, password):
    """Uwierzytelnij użytkownika przez Active Directory"""
    
    try:
        # Pobierz konfigurację AD
        ad_enabled = AppConfig.get_value('AUTH_USE_AD', 'False').lower() == 'true'
        if not ad_enabled:
            return None
        
        ad_server = AppConfig.get_value('AD_SERVER')
        ad_domain = AppConfig.get_value('AD_DOMAIN')
        ad_base_dn = AppConfig.get_value('AD_BASE_DN')
        
        if not all([ad_server, ad_domain, ad_base_dn]):
            return None
        
        # Utwórz połączenie z AD
        server = ldap3.Server(ad_server, get_info=ldap3.ALL)
        user_dn = f"{username}@{ad_domain}"
        
        conn = ldap3.Connection(server, user=user_dn, password=password, authentication=ldap3.SIMPLE)
        
        if not conn.bind():
            return None
        
        # Wyszukaj użytkownika w AD
        search_filter = f"(sAMAccountName={username})"
        conn.search(ad_base_dn, search_filter, attributes=['displayName', 'mail', 'givenName', 'sn', 'distinguishedName'])
        
        if not conn.entries:
            conn.unbind()
            return None
        
        ad_user = conn.entries[0]
        conn.unbind()
        
        # Sprawdź czy użytkownik istnieje w lokalnej bazie
        user = User.query.filter_by(username=username).first()
        
        if not user:
            # Utwórz nowego użytkownika na podstawie danych z AD
            user = User(
                username=username,
                email=str(ad_user.mail) if ad_user.mail else f"{username}@{ad_domain}",
                first_name=str(ad_user.givenName) if ad_user.givenName else '',
                last_name=str(ad_user.sn) if ad_user.sn else '',
                ad_dn=str(ad_user.distinguishedName),
                is_active=True
            )
            
            # Ustaw tymczasowe hasło (nie będzie używane przy uwierzytelnianiu AD)
            user.set_password('ad_user_temp_password')
            
            db.session.add(user)
            db.session.commit()
        else:
            # Zaktualizuj dane użytkownika z AD
            if ad_user.mail:
                user.email = str(ad_user.mail)
            if ad_user.givenName:
                user.first_name = str(ad_user.givenName)
            if ad_user.sn:
                user.last_name = str(ad_user.sn)
            user.ad_dn = str(ad_user.distinguishedName)
            
            db.session.commit()
        
        return user
        
    except Exception as e:
        current_app.logger.error(f"AD authentication error: {str(e)}")
        return None

def sync_ad_groups(user):
    """Synchronizuj grupy użytkownika z Active Directory"""
    
    try:
        if not user.ad_dn:
            return
        
        ad_server = AppConfig.get_value('AD_SERVER')
        ad_username = AppConfig.get_value('AD_USERNAME')
        ad_password = AppConfig.get_value('AD_PASSWORD')
        
        if not all([ad_server, ad_username, ad_password]):
            return
        
        # Połącz się jako konto serwisowe
        server = ldap3.Server(ad_server, get_info=ldap3.ALL)
        conn = ldap3.Connection(server, user=ad_username, password=ad_password, authentication=ldap3.SIMPLE)
        
        if not conn.bind():
            return
        
        # Wyszukaj grupy użytkownika
        search_filter = f"(member={user.ad_dn})"
        conn.search(ad_server, search_filter, attributes=['cn', 'description'])
        
        groups = []
        for group in conn.entries:
            groups.append({
                'name': str(group.cn),
                'description': str(group.description) if group.description else ''
            })
        
        conn.unbind()
        
        # Tutaj możesz dodać logikę mapowania grup AD na role w aplikacji
        # Na przykład: jeśli użytkownik jest w grupie "Domain Admins", ustaw is_admin=True
        
        return groups
        
    except Exception as e:
        current_app.logger.error(f"AD group sync error: {str(e)}")
        return []

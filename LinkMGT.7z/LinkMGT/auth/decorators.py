from functools import wraps
from flask import flash, redirect, url_for, request, jsonify
from flask_login import current_user

def admin_required(f):
    """Dekorator wymagający uprawnień administratora"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Musisz być zalogowany.', 'warning')
            return redirect(url_for('auth.login'))
        
        if not current_user.is_admin:
            flash('Wymagane uprawnienia administratora.', 'danger')
            return redirect(url_for('main.index'))
        
        return f(*args, **kwargs)
    return decorated_function

def team_member_required(team_id_param='team_id'):
    """Dekorator wymagający członkostwa w zespole"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Wymagane zalogowanie.', 'warning')
                return redirect(url_for('auth.login', next=request.url))
            
            # Admin ma dostęp do wszystkiego
            if current_user.is_admin:
                return f(*args, **kwargs)
            
            # Pobierz team_id z argumentów
            team_id = kwargs.get(team_id_param)
            if not team_id:
                team_id = request.args.get(team_id_param)
            
            if not team_id:
                flash('Nie określono zespołu.', 'danger')
                return redirect(url_for('teams.index'))
            
            # Sprawdź czy użytkownik jest członkiem zespołu
            from app.models import Team
            team = Team.query.get_or_404(team_id)
            
            if current_user not in team.members:
                flash('Nie jesteś członkiem tego zespołu.', 'danger')
                return redirect(url_for('teams.index'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def team_admin_required(f):
    """Decorator wymagający uprawnień administratora zespołu"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Musisz być zalogowany.', 'warning')
            return redirect(url_for('auth.login'))
        
        # Sprawdź czy użytkownik jest globalnym adminem lub adminem zespołu
        team_id = kwargs.get('team_id')
        if team_id:
            from app.models import UserTeam
            user_team = UserTeam.query.filter_by(
                user_id=current_user.id, 
                team_id=team_id
            ).first()
            
            if not (current_user.is_admin or (user_team and user_team.role == 2)):
                flash('Wymagane uprawnienia administratora zespołu.', 'danger')
                return redirect(url_for('teams.view', team_id=team_id))
        
        return f(*args, **kwargs)
    return decorated_function

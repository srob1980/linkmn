import os
import subprocess
import sys

def install_dependencies():
    """Install required Python dependencies"""
    print("Installing required dependencies...")
    
    # Check if pip is available
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"])
    except subprocess.CalledProcessError:
        print("Error: pip is not installed or not working properly.")
        return False
    
    # Get the requirements file path
    requirements_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements.txt")
    
    # Check if requirements file exists
    if not os.path.exists(requirements_file):
        print(f"Error: Requirements file not found at {requirements_file}")
        return False
    
    # Install dependencies
    try:
        print(f"Installing dependencies from {requirements_file}")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", requirements_file])
        print("✅ All dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error installing dependencies: {e}")
        
        # Try to install critical dependencies individually
        critical_deps = ["flask", "flask-sqlalchemy", "psutil", "psycopg2-binary", "python-dotenv"]
        print("Trying to install critical dependencies individually:")
        
        for dep in critical_deps:
            try:
                print(f"Installing {dep}...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
                print(f"✅ {dep} installed")
            except subprocess.CalledProcessError:
                print(f"❌ Failed to install {dep}")
        
        return False

if __name__ == "__main__":
    install_dependencies()

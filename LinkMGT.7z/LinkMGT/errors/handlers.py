from flask import render_template, request
from app import db
from app.errors import bp

@bp.app_errorhandler(404)
def not_found_error(error):
    """Obsługa błędu 404 - strona nie znaleziona"""
    # Add simple context to prevent template errors
    return render_template('errors/404.html', 
                          title="404 - Strona nie znaleziona",
                          url_exists=lambda x: False), 404

@bp.app_errorhandler(403)
def forbidden_error(error):
    """Obsługa błędu 403 - dostęp zabroniony"""
    return render_template('errors/403.html',
                          title="403 - Dostęp zabroniony",
                          url_exists=lambda x: False), 403

@bp.app_errorhandler(401)
def unauthorized_error(error):
    """Obsługa błędu 401 - nieautoryzowany dostęp"""
    return render_template('errors/401.html',
                          title="401 - Nieautoryzowany dostęp",
                          url_exists=lambda x: False), 401

@bp.app_errorhandler(500)
def internal_error(error):
    """Obsługa błędu 500 - wewnętrzny błąd serwera"""
    db.session.rollback()
    return render_template('errors/500.html',
                          title="500 - Błąd serwera",
                          url_exists=lambda x: False), 500

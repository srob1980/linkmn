import os
import sys
from dotenv import load_dotenv

# Load environment variables first
load_dotenv()

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

from app import create_app, db

app = create_app()

# Try to load database settings from the app config table
try:
    from config import Config
    
    # Check if the method exists before calling it
    if hasattr(Config, 'get_db_settings'):
        Config.get_db_settings(app)
        print("Database settings loaded from application configuration")
    else:
        # Define the method if it doesn't exist
        def load_db_settings(app):
            """Load database settings from application configuration"""
            with app.app_context():
                try:
                    # Try to import AppConfig model
                    from app.models.config import AppConfig
                    
                    # Get database URL
                    db_url = AppConfig.get_value('DATABASE_URL')
                    if db_url:
                        app.config['SQLALCHEMY_DATABASE_URI'] = db_url
                        print(f"Database URL from config: {db_url}")
                except Exception as e:
                    print(f"Error loading database configuration: {e}")
        
        # Call the local implementation
        load_db_settings(app)
        print("Database settings loaded using fallback method")
        
except Exception as e:
    print(f"Error loading database settings: {e}")
    print("Using default database settings from environment variables")

@app.shell_context_processor
def make_shell_context():
    """Provide context for the Flask shell"""
    # Import all models here to avoid circular imports
    from app.models import User, Team, Link, Category, Tag, AppConfig
    
    # Try to import infrastructure models if available
    try:
        from app.models import (
            Asset, AssetType, AssetStatus, Location, Vendor, 
            License, SupportContract, MaintenanceLog
        )
        return {
            'db': db, 
            'User': User, 
            'Team': Team,
            'Link': Link,
            'Category': Category,
            'Tag': Tag,
            'Asset': Asset,
            'AssetType': AssetType,
            'AssetStatus': AssetStatus,
            'Location': Location,
            'Vendor': Vendor,
            'License': License,
            'SupportContract': SupportContract,
            'MaintenanceLog': MaintenanceLog,
            'AppConfig': AppConfig
        }
    except ImportError:
        # Return without infrastructure models
        return {
            'db': db, 
            'User': User, 
            'Team': Team,
            'Link': Link,
            'Category': Category,
            'Tag': Tag,
            'AppConfig': AppConfig
        }

def get_ssl_context():
    """Get SSL context if HTTPS is enabled"""
    if app.config.get('USE_SSL', False):
        cert_path = app.config.get('SSL_CERT', 'cert.pem')
        key_path = app.config.get('SSL_KEY', 'key.pem')
        
        if os.path.exists(cert_path) and os.path.exists(key_path):
            return (cert_path, key_path)
        else:
            print(f"SSL files not found: {cert_path}, {key_path}")
            return None
    return None

if __name__ == '__main__':
    ssl_context = get_ssl_context()
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() in ('true', '1', 't')
    host = os.environ.get('HOST', '127.0.0.1')
    port = int(os.environ.get('HTTP_PORT', 5000))
    
    print(f"Starting server at {host}:{port} (Debug: {debug}, SSL: {ssl_context is not None})")
    
    app.run(
        debug=debug,
        host=host,
        port=port,
        ssl_context=ssl_context
    )

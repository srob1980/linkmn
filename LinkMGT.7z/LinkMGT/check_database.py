import os
import sys
import platform
import subprocess
import importlib.util
from sqlalchemy import text

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def check_psycopg2():
    """Check if psycopg2 is installed correctly"""
    print("🔍 Checking psycopg2 installation...")
    
    try:
        import psycopg2
        print("✅ psycopg2 is installed")
        print(f"   Version: {psycopg2.__version__}")
        print(f"   Path: {psycopg2.__path__[0] if hasattr(psycopg2, '__path__') else 'Built-in'}")
        return True
    except ImportError as e:
        print(f"❌ psycopg2 import failed: {e}")
        return False
    except Exception as e:
        print(f"⚠️ psycopg2 error: {e}")
        return False

def check_postgresql_drivers():
    """Check if PostgreSQL drivers are installed"""
    print("\n🔍 Checking PostgreSQL drivers...")
    
    # Check for PostgreSQL binaries in PATH
    pg_path = None
    paths = os.environ.get('PATH', '').split(os.pathsep)
    
    if platform.system() == 'Windows':
        pg_bin = 'pg_config.exe'
    else:
        pg_bin = 'pg_config'
    
    for path in paths:
        if os.path.exists(os.path.join(path, pg_bin)):
            pg_path = path
            break
    
    if pg_path:
        print(f"✅ PostgreSQL binaries found in PATH: {pg_path}")
    else:
        print("❌ PostgreSQL binaries not found in PATH")
    
    # Check for Microsoft Visual C++ Redistributable on Windows
    if platform.system() == 'Windows':
        print("\n🔍 Checking for Microsoft Visual C++ Redistributable...")
        try:
            # Check for common VC++ Redistributable DLLs
            system32_path = os.path.join(os.environ.get('SystemRoot', 'C:\\Windows'), 'System32')
            vc_dlls = ['msvcp140.dll', 'vcruntime140.dll']
            found_dlls = []
            
            for dll in vc_dlls:
                if os.path.exists(os.path.join(system32_path, dll)):
                    found_dlls.append(dll)
            
            if found_dlls:
                print(f"✅ Microsoft Visual C++ Redistributable appears to be installed. Found: {', '.join(found_dlls)}")
            else:
                print("❌ Microsoft Visual C++ Redistributable files not found")
                print("   This might cause issues with psycopg2 and other compiled modules.")
        except Exception as e:
            print(f"⚠️ Error checking for VC++ Redistributable: {e}")

def check_sqlalchemy_models():
    """Check SQLAlchemy models for common relationship issues"""
    print("\n🔍 Checking SQLAlchemy models...")
    
    try:
        # Try to load models
        from app.models.user import User
        from app.models.team import Team
        print("✅ Basic models loaded successfully")
        
        # Test relationship integrity
        from app import create_app, db
        app = create_app()
        with app.app_context():
            # Check for relationship conflicts
            try:
                # Query a few records to validate relationships
                User.query.first()
                Team.query.first()
                print("✅ Model relationships appear to be configured correctly")
            except Exception as e:
                print(f"❌ Model relationship error: {e}")
                print("   You may have conflicting relationship definitions between models.")
    except ImportError as e:
        print(f"❌ Error importing models: {e}")
    except Exception as e:
        print(f"❌ Unexpected error during model check: {e}")

def check_connection_string():
    """Check database connection string"""
    from dotenv import load_dotenv
    load_dotenv()
    
    print("\n🔍 Checking database connection settings...")
    
    database_url = os.environ.get('DATABASE_URL')
    if database_url:
        print(f"✅ DATABASE_URL is set: {database_url.split('@')[0].split(':')[0]}:***@{database_url.split('@')[1] if '@' in database_url else database_url}")
        
        # Check if URL format is valid
        if not (database_url.startswith('postgresql://') or database_url.startswith('sqlite:///')):
            print("⚠️ Warning: DATABASE_URL format may be invalid")
    else:
        print("❌ DATABASE_URL environment variable not set")
        print("   Check your .env file or set this environment variable.")
        
    # Check fallback
    fallback_url = os.environ.get('DATABASE_URL_FALLBACK')
    if fallback_url:
        print(f"✅ Fallback database URL is set: {fallback_url.split('@')[0].split(':')[0]}:***@{fallback_url.split('@')[1] if '@' in fallback_url else fallback_url}")
    else:
        print("ℹ️ No fallback database URL set")

def suggest_fixes():
    """Suggest fixes for common issues"""
    print("\n🔧 Suggested fixes:")
    
    print("1. Install psycopg2-binary instead of psycopg2:")
    print("   pip install psycopg2-binary")
    
    print("\n2. Make sure PostgreSQL is installed and binaries are in PATH")
    
    if platform.system() == 'Windows':
        print("\n3. Install Microsoft Visual C++ Redistributable:")
        print("   https://aka.ms/vs/17/release/vc_redist.x64.exe")
    
    print("\n4. Set the DATABASE_URL environment variable in .env file:")
    print("   DATABASE_URL=postgresql://username:password@localhost:5432/linkmgt")
    
    print("\n5. If all else fails, use SQLite as a fallback:")
    print("   DATABASE_URL_FALLBACK=sqlite:///app.db")

def test_database_connection():
    """Test database connection using SQLAlchemy"""
    try:
        from app import create_app, db
        print("\n🔍 Testing database connection...")
        
        app = create_app()
        with app.app_context():
            try:
                # Try a simple query
                result = db.session.execute(text("SELECT 1")).scalar()
                print("✅ Database connection successful!")
                
                # Check table existence
                tables_query = db.session.execute(text("""
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'public' 
                    ORDER BY table_name
                """))
                tables = [row[0] for row in tables_query]
                
                print(f"\n📋 Found {len(tables)} tables in database:")
                for table in tables:
                    print(f"   - {table}")
                
            except Exception as e:
                print(f"❌ Database connection failed: {e}")
                suggest_fixes()
                
    except ImportError:
        print("❌ Could not import app. Check your Flask app configuration.")
    except Exception as e:
        print(f"❌ Error during app initialization: {e}")

if __name__ == "__main__":
    print("=" * 60)
    print("LinkMGT Database Connection Checker")
    print("=" * 60)
    
    print(f"Python: {sys.version}")
    print(f"Platform: {platform.platform()}")
    print(f"System: {platform.system()} {platform.release()}")
    
    check_psycopg2()
    check_postgresql_drivers()
    check_sqlalchemy_models()
    check_connection_string()
    test_database_connection()
    
    print("\n" + "=" * 60)
    print("Check complete! Review any warnings or errors above.")
    print("=" * 60)

#!/usr/bin/env python
"""
Skrypt pomocniczy do zarządzania wirtualnym środowiskiem projektu LinkMGT.
Uruchom: python setup_venv.py
"""
import os
import sys
import subprocess
import platform

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
VENV_DIR = os.path.join(PROJECT_DIR, "venv")

def create_venv():
    """Tworzy wirtualne środowisko Python"""
    print(f"Tworzenie wirtualnego środowiska w {VENV_DIR}...")
    subprocess.run([sys.executable, "-m", "venv", VENV_DIR])
    print("Środowisko utworzone pomyślnie!")

def get_activate_command():
    """Zwraca odpowiednią komendę aktywacji w zależności od systemu operacyjnego"""
    system = platform.system().lower()
    if system == "windows":
        return f"{VENV_DIR}\\Scripts\\activate"
    else:  # Linux/Mac
        return f"source {VENV_DIR}/bin/activate"

def install_requirements():
    """Instaluje wymagane zależności projektu"""
    # Określenie ścieżki do pip w wirtualnym środowisku
    system = platform.system().lower()
    if system == "windows":
        pip_path = os.path.join(VENV_DIR, "Scripts", "pip")
    else:
        pip_path = os.path.join(VENV_DIR, "bin", "pip")
    
    req_path = os.path.join(PROJECT_DIR, "requirements.txt")
    print(f"Instalowanie zależności z {req_path}...")
    subprocess.run([pip_path, "install", "-r", req_path])
    print("Zależności zainstalowane pomyślnie!")

def main():
    """Funkcja główna"""
    if not os.path.exists(VENV_DIR):
        create_venv()
        activate_cmd = get_activate_command()
        print("\nAby aktywować środowisko, wykonaj:")
        print(f"  {activate_cmd}")
        
        print("\nNastępnie zainstaluj zależności:")
        if platform.system().lower() == "windows":
            print("  pip install -r requirements.txt")
        else:
            print("  pip install -r requirements.txt")
            
        print("\nLub uruchom ten skrypt ponownie po aktywacji środowiska.")
    else:
        # Sprawdź, czy środowisko jest aktywne
        if not hasattr(sys, 'real_prefix') and not (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
            print("Wirtualne środowisko istnieje, ale nie jest aktywne.")
            print(f"Aktywuj je komendą: {get_activate_command()}")
            print("Następnie uruchom ten skrypt ponownie, aby zainstalować zależności.")
        else:
            install_requirements()
            print("\nŚrodowisko jest gotowe! Możesz uruchomić aplikację:")
            print("  python run.py")

if __name__ == "__main__":
    main()

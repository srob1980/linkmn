import os
import sys
import psycopg2
from sqlalchemy import text

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

from app import create_app, db

def run_database_update():
    """Wykonaj aktualizację bazy danych"""
    
    app = create_app()
    
    with app.app_context():
        try:
            # Odczytaj plik SQL
            sql_file_path = os.path.join(project_path, 'update_database.sql')
            
            if not os.path.exists(sql_file_path):
                print(f"Błąd: Nie znaleziono pliku {sql_file_path}")
                return False
            
            with open(sql_file_path, 'r', encoding='utf-8') as f:
                sql_content = f.read()
            
            print("Rozpoczynanie aktualizacji bazy danych...")
            
            # Wykonaj SQL
            db.session.execute(text(sql_content))
            db.session.commit()
            
            print("✅ Aktualizacja bazy danych zakończona pomyślnie!")
            
            # Sprawdź czy wszystko działa
            from app.models import User, Team, Category, Link, AppConfig
            
            print("\n📊 Statystyki po aktualizacji:")
            print(f"- Użytkownicy: {User.query.count()}")
            print(f"- Zespoły: {Team.query.count()}")
            print(f"- Kategorie: {Category.query.count()}")
            print(f"- Linki: {Link.query.count()}")
            print(f"- Konfiguracje: {AppConfig.query.count()}")
            
            # Sprawdź pole is_public
            public_links = Link.query.filter_by(is_public=True).count()
            print(f"- Publiczne linki: {public_links}")
            
            return True
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Błąd podczas aktualizacji bazy danych: {e}")
            return False

if __name__ == '__main__':
    success = run_database_update()
    sys.exit(0 if success else 1)

import os
from datetime import timedelta
from dotenv import load_dotenv
import sqlite3
import sys
import importlib.util

# Load environment variables from .env file
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    load_dotenv(os.path.join(basedir, '.env'))
except ImportError:
    pass  # python-dotenv not installed, will use defaults

from app.models.config import AppConfig

class Config:
    # Flask configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'hard-to-guess-string'
    
    # Database configuration with SQLite fallback
    sqlite_path = os.path.join(basedir, 'app.db')
    default_db_uri = f'sqlite:///{sqlite_path}'
    
    # Check available database drivers
    SQLITE_AVAILABLE = True  # SQLite is part of Python standard library
    
    # PostgreSQL availability check
    PG_AVAILABLE = False
    try:
        import psycopg2
        PG_AVAILABLE = True
    except (ImportError, ModuleNotFoundError):
        print("⚠️ PostgreSQL support unavailable: psycopg2 module not found")
    
    # MySQL/MariaDB availability check
    MYSQL_AVAILABLE = False
    try:
        import pymysql
        MYSQL_AVAILABLE = True
    except (ImportError, ModuleNotFoundError):
        print("⚠️ MySQL/MariaDB support unavailable: pymysql module not found")
    
    # Oracle availability check
    ORACLE_AVAILABLE = False
    try:
        oracle_available = False
        # Try modern oracledb first
        try:
            import oracledb
            oracle_available = True
        except ImportError:
            # Fall back to cx_Oracle
            try:
                import cx_Oracle
                oracle_available = True
            except ImportError:
                pass
                
        ORACLE_AVAILABLE = oracle_available
        if not oracle_available:
            print("⚠️ Oracle support unavailable: neither oracledb nor cx_Oracle modules found")
    except Exception as e:
        print(f"⚠️ Error checking Oracle support: {e}")
    
    # Set database URI with fallback mechanism
    db_url = os.environ.get('DATABASE_URL')
    if db_url:
        # Check if the requested database driver is available
        if db_url.startswith('postgresql://') and not PG_AVAILABLE:
            print("⚠️ PostgreSQL URL specified but driver not available. Using fallback.")
            db_url = None
        elif (db_url.startswith('mysql://') or db_url.startswith('mariadb://')) and not MYSQL_AVAILABLE:
            print("⚠️ MySQL/MariaDB URL specified but driver not available. Using fallback.")
            db_url = None
        elif db_url.startswith('oracle://') and not ORACLE_AVAILABLE:
            print("⚠️ Oracle URL specified but driver not available. Using fallback.")
            db_url = None
            
    if db_url:
        SQLALCHEMY_DATABASE_URI = db_url
        db_type = db_url.split('://')[0]
        print(f"✅ Using {db_type.upper()} database")
    else:
        sqlite_path = os.path.join(basedir, 'app.db')
        SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL_FALLBACK') or f'sqlite:///{sqlite_path}'
        print(f"⚠️ Using SQLite fallback database: {sqlite_path}")
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Database-specific engine options
    db_engine = SQLALCHEMY_DATABASE_URI.split('://')[0] if SQLALCHEMY_DATABASE_URI else 'sqlite'
    
    # Set engine-specific options
    engine_options = {
        'pool_pre_ping': True,
        'pool_recycle': 300,  # Recycle connections after 5 minutes
        'pool_timeout': 30    # Connection timeout of 30 seconds
    }
    
    # Add Oracle-specific options
    if db_engine == 'oracle':
        engine_options.update({
            'coerce_to_unicode': True,
            'arraysize': 100
        })
    
    # Add MySQL-specific options
    elif db_engine in ('mysql', 'mariadb'):
        engine_options.update({
            'connect_args': {
                'charset': 'utf8mb4',
                'use_unicode': True
            }
        })
    
    # Add PostgreSQL-specific options
    elif db_engine == 'postgresql':
        engine_options.update({
            'connect_args': {
                'client_encoding': 'utf8'
            }
        })
    
    SQLALCHEMY_ENGINE_OPTIONS = engine_options
    
    # Server configuration
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() in ('true', '1', 't')
    HOST = os.environ.get('HOST', '0.0.0.0')
    PORT = int(os.environ.get('HTTP_PORT', 5000))
    
    # SSL configuration
    USE_SSL = os.environ.get('USE_SSL', 'False').lower() in ('true', '1', 't')
    SSL_CERT = os.environ.get('SSL_CERT', 'cert.pem')
    SSL_KEY = os.environ.get('SSL_KEY', 'key.pem')
    
    # Application configuration
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10MB limit for file uploads
    ITEMS_PER_PAGE = 10  # Pagination

    # Active Directory Configuration
    AD_ENABLED = os.environ.get('AD_ENABLED', 'False').lower() in ('true', '1', 't')
    AD_SERVER = os.environ.get('AD_SERVER', 'ldap://your-ad-server.com')
    AD_DOMAIN = os.environ.get('AD_DOMAIN', 'yourdomain.com')
    AD_BASE_DN = os.environ.get('AD_BASE_DN', 'DC=yourdomain,DC=com')
    AD_USER_PREFIX = os.environ.get('AD_USER_PREFIX', 'CN=')
    AD_USE_UPN = os.environ.get('AD_USE_UPN', 'False').lower() in ('true', '1', 't')
    AD_TIMEOUT = int(os.environ.get('AD_TIMEOUT', 10))
    AD_USE_TLS = os.environ.get('AD_USE_TLS', 'False').lower() in ('true', '1', 't')
    AD_TLS_CACERT = os.environ.get('AD_TLS_CACERT', '')
    AD_SERVICE_USER = os.environ.get('AD_SERVICE_USER', '')
    AD_SERVICE_PASSWORD = os.environ.get('AD_SERVICE_PASSWORD', '')
    
    # AD Group configuration
    AD_ADMIN_GROUP = os.environ.get('AD_ADMIN_GROUP', 'LinkMGT-Admins')
    AD_SYNC_GROUPS = os.environ.get('AD_SYNC_GROUPS', 'False').lower() in ('true', '1', 't')
    AD_AUTO_CREATE_TEAMS = os.environ.get('AD_AUTO_CREATE_TEAMS', 'False').lower() in ('true', '1', 't')
    AD_TEAM_PREFIX = os.environ.get('AD_TEAM_PREFIX', 'TEAM-')
    
    # AD group to team mappings (loaded from env var as comma-separated key=value pairs)
    AD_GROUP_TEAM_MAPPINGS = {}
    team_mappings = os.environ.get('AD_GROUP_TEAM_MAPPINGS', '')
    if team_mappings:
        for mapping in team_mappings.split(','):
            if '=' in mapping:
                ad_group, team = mapping.split('=', 1)
                AD_GROUP_TEAM_MAPPINGS[ad_group.strip()] = team.strip()
    
    # CSRF protection
    WTF_CSRF_ENABLED = True
    
    @classmethod
    def get_db_settings(cls, app):
        """Get database settings from application configuration"""
        with app.app_context():
            try:
                # Try to import AppConfig model
                from app.models.config import AppConfig
                
                # Get database URL
                db_url = AppConfig.get_value('DATABASE_URL')
                if db_url:
                    app.config['SQLALCHEMY_DATABASE_URI'] = db_url
                
                # Get fallback URL
                db_fallback = AppConfig.get_value('DATABASE_URL_FALLBACK')
                if db_fallback:
                    app.config['DATABASE_URL_FALLBACK'] = db_fallback
                
                # Get connection pool settings
                pool_pre_ping = AppConfig.get_value('DB_POOL_PRE_PING')
                pool_recycle = AppConfig.get_value('DB_POOL_RECYCLE')
                pool_timeout = AppConfig.get_value('DB_POOL_TIMEOUT')
                
                engine_options = app.config.get('SQLALCHEMY_ENGINE_OPTIONS', {})
                
                if pool_pre_ping is not None:
                    engine_options['pool_pre_ping'] = pool_pre_ping.lower() == 'true'
                
                if pool_recycle is not None and pool_recycle.isdigit():
                    engine_options['pool_recycle'] = int(pool_recycle)
                
                if pool_timeout is not None and pool_timeout.isdigit():
                    engine_options['pool_timeout'] = int(pool_timeout)
                
                app.config['SQLALCHEMY_ENGINE_OPTIONS'] = engine_options
                
                print(f"Database URL from config: {db_url}")
                
            except Exception as e:
                print(f"Error loading database configuration: {e}")
                # Continue with default settings

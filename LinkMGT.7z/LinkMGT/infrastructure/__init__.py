from flask import Blueprint

bp = Blueprint('infrastructure', __name__)

from app.infrastructure import routes
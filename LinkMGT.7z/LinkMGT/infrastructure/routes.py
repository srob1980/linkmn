from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.infrastructure import bp
from app.infrastructure.forms import AssetForm, LicenseForm, SupportContractForm, MaintenanceForm, VendorForm, LocationForm
from app import db
from app.auth.decorators import admin_required
from sqlalchemy import func, desc, or_
from datetime import datetime, timedelta

# Import models safely with fallbacks for development without migration
try:
    from app.models.infrastructure import (Asset, License, SupportContract, MaintenanceLog, 
                                        Location, Vendor, AssetType)
except ImportError:
    # Create placeholder classes for development
    class Asset:
        query = None
    class License:
        query = None
    class SupportContract:
        query = None
    class MaintenanceLog:
        query = None
    class Location:
        query = None
    class Vendor:
        query = None
    class AssetType:
        query = None

@bp.route('/')
@login_required
def index():
    """Panel główny infrastruktury"""
    try:
        # Prepare stats dictionary with default values
        stats = {
            'total_assets': 0,
            'total_licenses': 0,
            'total_contracts': 0,
            'total_maintenance': 0,
            'expiring_soon': 0,
            'inactive_assets': 0
        }
        
        # If Asset model exists, get asset count
        if hasattr(Asset, 'query') and Asset.query is not None:
            stats['total_assets'] = Asset.query.count()
            stats['inactive_assets'] = Asset.query.filter_by(status='INACTIVE').count()
        
        # If License model exists, get license count
        if hasattr(License, 'query') and License.query is not None:
            stats['total_licenses'] = License.query.count()
            # Count licenses expiring in next 30 days
            thirty_days = datetime.now() + timedelta(days=30)
            stats['expiring_soon'] = License.query.filter(
                License.expiry_date <= thirty_days,
                License.expiry_date >= datetime.now()
            ).count()
        
        # If SupportContract model exists, get contract count
        if hasattr(SupportContract, 'query') and SupportContract.query is not None:
            stats['total_contracts'] = SupportContract.query.count()
        
        # If MaintenanceLog model exists, get maintenance count
        if hasattr(MaintenanceLog, 'query') and MaintenanceLog.query is not None:
            stats['total_maintenance'] = MaintenanceLog.query.count()
        
        # Get recent assets
        recent_assets = []
        if hasattr(Asset, 'query') and Asset.query is not None:
            recent_assets = Asset.query.order_by(desc(Asset.created_at)).limit(5).all()
        
        # Get locations
        locations = []
        if hasattr(Location, 'query') and Location.query is not None:
            locations = Location.query.filter_by(is_active=True).all()
        
        # Get vendors
        vendors = []
        if hasattr(Vendor, 'query') and Vendor.query is not None:
            vendors = Vendor.query.filter_by(is_active=True).all()
        
        return render_template('infrastructure/index.html',
                              title='Infrastruktura IT',
                              stats=stats,
                              recent_assets=recent_assets,
                              locations=locations,
                              vendors=vendors)
    
    except Exception as e:
        flash(f'Błąd ładowania danych infrastruktury: {str(e)}', 'danger')
        return render_template('infrastructure/index.html', 
                              title='Infrastruktura IT',
                              stats={
                                  'total_assets': 0,
                                  'total_licenses': 0,
                                  'total_contracts': 0,
                                  'total_maintenance': 0,
                                  'expiring_soon': 0,
                                  'inactive_assets': 0
                              },
                              recent_assets=[],
                              locations=[],
                              vendors=[])

@bp.route('/assets')
@login_required
def assets():
    """Lista zasobów IT"""
    try:
        # Get query parameters
        status_filter = request.args.get('status', 'all')
        type_filter = request.args.get('type', 'all')
        location_filter = request.args.get('location', 'all')
        search_query = request.args.get('q', '')
        
        # Base query
        query = Asset.query
        
        # Apply filters
        if status_filter != 'all':
            query = query.filter(Asset.status == status_filter)
            
        if type_filter != 'all':
            query = query.filter(Asset.asset_type_id == type_filter)
            
        if location_filter != 'all':
            query = query.filter(Asset.location_id == location_filter)
            
        if search_query:
            query = query.filter(or_(
                Asset.name.ilike(f'%{search_query}%'),
                Asset.asset_tag.ilike(f'%{search_query}%'),
                Asset.serial_number.ilike(f'%{search_query}%'),
                Asset.model.ilike(f'%{search_query}%')
            ))
        
        # Get assets with pagination
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        assets = query.order_by(Asset.name).paginate(page=page, per_page=per_page)
        
        # Get filter options for dropdowns
        statuses = db.session.query(Asset.status).distinct().all()
        asset_types = AssetType.query.order_by(AssetType.name).all()
        locations = Location.query.order_by(Location.name).all()
        
        return render_template('infrastructure/assets.html',
                              title='Zasoby IT',
                              assets=assets,
                              statuses=statuses,
                              asset_types=asset_types,
                              locations=locations,
                              current_status=status_filter,
                              current_type=type_filter,
                              current_location=location_filter,
                              search_query=search_query)
    
    except Exception as e:
        flash(f'Błąd podczas ładowania zasobów: {str(e)}', 'danger')
        return render_template('infrastructure/assets.html', 
                              title='Zasoby IT',
                              error=str(e))

@bp.route('/asset/<int:asset_id>')
@login_required
def asset_view(asset_id):
    """Szczegóły zasobu IT"""
    try:
        asset = Asset.query.get_or_404(asset_id)
        
        # Get maintenance history
        maintenance_logs = MaintenanceLog.query.filter_by(asset_id=asset_id).order_by(desc(MaintenanceLog.created_at)).all()
        
        return render_template('infrastructure/asset_view.html',
                              title=f'Zasób: {asset.name}',
                              asset=asset,
                              maintenance_logs=maintenance_logs)
    
    except Exception as e:
        flash(f'Błąd podczas ładowania szczegóły zasobu: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.assets'))

@bp.route('/asset/create', methods=['GET', 'POST'])
@login_required
@admin_required
def asset_create():
    """Tworzenie nowego zasobu IT"""
    form = AssetForm()
    
    # Populate select fields
    form.asset_type_id.choices = [(t.id, t.name) for t in AssetType.query.order_by(AssetType.name).all()]
    form.location_id.choices = [(l.id, l.name) for l in Location.query.order_by(Location.name).all()]
    form.vendor_id.choices = [(v.id, v.name) for v in Vendor.query.order_by(Vendor.name).all()]
    
    if form.validate_on_submit():
        try:
            asset = Asset(
                name=form.name.data,
                asset_tag=form.asset_tag.data,
                serial_number=form.serial_number.data,
                model=form.model.data,
                manufacturer=form.manufacturer.data,
                asset_type_id=form.asset_type_id.data,
                location_id=form.location_id.data,
                vendor_id=form.vendor_id.data,
                status=form.status.data,
                purchase_date=form.purchase_date.data,
                warranty_end=form.warranty_end.data,
                value=form.value.data,
                description=form.description.data,
                ip_address=form.ip_address.data,
                mac_address=form.mac_address.data,
                operating_system=form.operating_system.data,
                cpu=form.cpu.data,
                memory_gb=form.memory_gb.data,
                storage_gb=form.storage_gb.data,
                created_by=current_user.id
            )
            
            db.session.add(asset)
            db.session.commit()
            
            flash(f'Zasób "{asset.name}" został pomyślnie utworzony.', 'success')
            return redirect(url_for('infrastructure.asset_view', asset_id=asset.id))
        
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas tworzenia zasobu: {str(e)}', 'danger')
    
    return render_template('infrastructure/asset_form.html',
                          title='Nowy zasób IT',
                          form=form)

@bp.route('/asset/<int:asset_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def asset_edit(asset_id):
    """Edycja zasobu IT"""
    asset = Asset.query.get_or_404(asset_id)
    form = AssetForm(obj=asset)
    
    # Populate select fields
    form.asset_type_id.choices = [(t.id, t.name) for t in AssetType.query.order_by(AssetType.name).all()]
    form.location_id.choices = [(l.id, l.name) for l in Location.query.order_by(Location.name).all()]
    form.vendor_id.choices = [(v.id, v.name) for v in Vendor.query.order_by(Vendor.name).all()]
    
    if form.validate_on_submit():
        try:
            # Update asset properties
            asset.name = form.name.data
            asset.asset_tag = form.asset_tag.data
            asset.serial_number = form.serial_number.data
            asset.model = form.model.data
            asset.manufacturer = form.manufacturer.data
            asset.asset_type_id = form.asset_type_id.data
            asset.location_id = form.location_id.data
            asset.vendor_id = form.vendor_id.data
            asset.status = form.status.data
            asset.purchase_date = form.purchase_date.data
            asset.warranty_end = form.warranty_end.data
            asset.value = form.value.data
            asset.description = form.description.data
            asset.ip_address = form.ip_address.data
            asset.mac_address = form.mac_address.data
            asset.operating_system = form.operating_system.data
            asset.cpu = form.cpu.data
            asset.memory_gb = form.memory_gb.data
            asset.storage_gb = form.storage_gb.data
            
            db.session.commit()
            
            flash(f'Zasób "{asset.name}" został pomyślnie zaktualizowany.', 'success')
            return redirect(url_for('infrastructure.asset_view', asset_id=asset.id))
        
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji zasobu: {str(e)}', 'danger')
    
    return render_template('infrastructure/asset_form.html',
                          title=f'Edycja zasobu: {asset.name}',
                          form=form,
                          asset=asset)

@bp.route('/licenses')
@login_required
def licenses():
    """Lista licencji"""
    try:
        # Get query parameters
        expiry_filter = request.args.get('expiry', 'all')
        vendor_filter = request.args.get('vendor', 'all')
        search_query = request.args.get('q', '')
        
        # Base query
        query = License.query
        
        # Apply filters
        if expiry_filter == 'expired':
            query = query.filter(License.expiry_date < datetime.now().date())
        elif expiry_filter == 'expiring':
            query = query.filter(License.expiry_date.between(
                datetime.now().date(), 
                datetime.now().date() + timedelta(days=30)
            ))
            
        if vendor_filter != 'all':
            query = query.filter(License.vendor_id == vendor_filter)
            
        if search_query:
            query = query.filter(or_(
                License.name.ilike(f'%{search_query}%'),
                License.software.ilike(f'%{search_query}%'),
                License.license_type.ilike(f'%{search_query}%')
            ))
        
        # Get licenses with pagination
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        licenses = query.order_by(License.name).paginate(page=page, per_page=per_page)
        
        # Get filter options for dropdowns
        vendors = Vendor.query.order_by(Vendor.name).all()
        
        return render_template('infrastructure/licenses.html',
                              title='Licencje',
                              licenses=licenses,
                              vendors=vendors,
                              current_expiry=expiry_filter,
                              current_vendor=vendor_filter,
                              search_query=search_query)
    
    except Exception as e:
        flash(f'Błąd podczas ładowania licencji: {str(e)}', 'danger')
        return render_template('infrastructure/licenses.html', 
                              title='Licencje',
                              error=str(e))

@bp.route('/support_contracts')
@login_required
def support_contracts():
    """Lista umów serwisowych"""
    try:
        # Get query parameters
        status_filter = request.args.get('status', 'all')
        vendor_filter = request.args.get('vendor', 'all')
        search_query = request.args.get('q', '')
        
        # Base query
        query = SupportContract.query
        
        # Apply filters
        if status_filter != 'all':
            query = query.filter(SupportContract.status == status_filter)
            
        if vendor_filter != 'all':
            query = query.filter(SupportContract.vendor_id == vendor_filter)
            
        if search_query:
            query = query.filter(or_(
                SupportContract.name.ilike(f'%{search_query}%'),
                SupportContract.contract_number.ilike(f'%{search_query}%'),
                SupportContract.description.ilike(f'%{search_query}%')
            ))
        
        # Get contracts with pagination
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        contracts = query.order_by(SupportContract.end_date).paginate(page=page, per_page=per_page)
        
        # Get filter options for dropdowns
        vendors = Vendor.query.order_by(Vendor.name).all()
        
        return render_template('infrastructure/support_contracts.html',
                              title='Umowy serwisowe',
                              contracts=contracts,
                              vendors=vendors,
                              current_status=status_filter,
                              current_vendor=vendor_filter,
                              search_query=search_query)
    
    except Exception as e:
        flash(f'Błąd podczas ładowania umów serwisowych: {str(e)}', 'danger')
        return render_template('infrastructure/support_contracts.html', 
                              title='Umowy serwisowe',
                              error=str(e))

@bp.route('/maintenance')
@login_required
def maintenance():
    """Historia konserwacji"""
    try:
        # Get query parameters
        asset_filter = request.args.get('asset', 'all')
        type_filter = request.args.get('type', 'all')
        search_query = request.args.get('q', '')
        
        # Base query
        query = MaintenanceLog.query
        
        # Apply filters
        if asset_filter != 'all':
            query = query.filter(MaintenanceLog.asset_id == asset_filter)
            
        if type_filter != 'all':
            query = query.filter(MaintenanceLog.maintenance_type == type_filter)
            
        if search_query:
            query = query.filter(or_(
                MaintenanceLog.title.ilike(f'%{search_query}%'),
                MaintenanceLog.description.ilike(f'%{search_query}%')
            ))
        
        # Get logs with pagination
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        logs = query.order_by(desc(MaintenanceLog.created_at)).paginate(page=page, per_page=per_page)
        
        # Get filter options for dropdowns
        assets = Asset.query.order_by(Asset.name).all()
        
        return render_template('infrastructure/maintenance.html',
                              title='Historia konserwacji',
                              logs=logs,
                              assets=assets,
                              current_asset=asset_filter,
                              current_type=type_filter,
                              search_query=search_query)
    
    except Exception as e:
        flash(f'Błąd podczas ładowania historii konserwacji: {str(e)}', 'danger')
        return render_template('infrastructure/maintenance.html', 
                              title='Historia konserwacji',
                              error=str(e))

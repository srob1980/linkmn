from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, TextAreaField, DateField, DecimalField, IntegerField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Optional, Length, NumberRange, ValidationError
from datetime import date

class AssetForm(FlaskForm):
    """Formularz zasobu IT"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    asset_tag = StringField('Numer inwentarzowy', validators=[Optional(), Length(max=50)])
    serial_number = StringField('Numer seryjny', validators=[Optional(), Length(max=100)])
    model = StringField('Model', validators=[Optional(), Length(max=100)])
    manufacturer = StringField('Producent', validators=[Optional(), Length(max=100)])
    
    asset_type_id = SelectField('Typ zasobu', coerce=int, validators=[DataRequired()])
    location_id = SelectField('Lokalizacja', coerce=int, validators=[Optional()])
    vendor_id = SelectField('Dostawca', coerce=int, validators=[Optional()])
    
    status = SelectField('Status', choices=[
        ('ACTIVE', 'Aktywny'),
        ('INACTIVE', 'Nieaktywny'),
        ('MAINTENANCE', 'W serwisie'),
        ('DECOMMISSIONED', 'Wycofany')
    ], validators=[DataRequired()])
    
    purchase_date = DateField('Data zakupu', validators=[Optional()])
    warranty_end = DateField('Koniec gwarancji', validators=[Optional()])
    value = DecimalField('Wartość', validators=[Optional(), NumberRange(min=0)], places=2)
    description = TextAreaField('Opis', validators=[Optional(), Length(max=1000)])
    
    # Techniczne parametry
    ip_address = StringField('Adres IP', validators=[Optional(), Length(max=45)])
    mac_address = StringField('Adres MAC', validators=[Optional(), Length(max=17)])
    operating_system = StringField('System operacyjny', validators=[Optional(), Length(max=100)])
    cpu = StringField('Procesor', validators=[Optional(), Length(max=100)])
    memory_gb = IntegerField('Pamięć RAM (GB)', validators=[Optional(), NumberRange(min=0)])
    storage_gb = IntegerField('Przestrzeń dyskowa (GB)', validators=[Optional(), NumberRange(min=0)])
    
    submit = SubmitField('Zapisz')
    
    def validate_warranty_end(self, field):
        """Sprawdź czy data końca gwarancji jest po dacie zakupu"""
        if field.data and self.purchase_date.data and field.data < self.purchase_date.data:
            raise ValidationError('Data końca gwarancji musi być po dacie zakupu.')

class LicenseForm(FlaskForm):
    """Formularz licencji"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    software = StringField('Oprogramowanie', validators=[DataRequired(), Length(max=100)])
    license_key = TextAreaField('Klucz licencyjny', validators=[Optional()])
    license_type = StringField('Typ licencji', validators=[Optional(), Length(max=50)])
    
    vendor_id = SelectField('Dostawca', coerce=int, validators=[Optional()])
    
    purchase_date = DateField('Data zakupu', validators=[Optional()])
    expiry_date = DateField('Data wygaśnięcia', validators=[Optional()])
    
    seats = IntegerField('Liczba stanowisk', validators=[Optional(), NumberRange(min=1)], default=1)
    used_seats = IntegerField('Wykorzystane stanowiska', validators=[Optional(), NumberRange(min=0)], default=0)
    
    cost = DecimalField('Koszt', validators=[Optional(), NumberRange(min=0)], places=2)
    notes = TextAreaField('Uwagi', validators=[Optional(), Length(max=1000)])
    
    submit = SubmitField('Zapisz')
    
    def validate_expiry_date(self, field):
        """Sprawdź czy data wygaśnięcia jest po dacie zakupu"""
        if field.data and self.purchase_date.data and field.data < self.purchase_date.data:
            raise ValidationError('Data wygaśnięcia musi być po dacie zakupu.')
    
    def validate_used_seats(self, field):
        """Sprawdź czy liczba wykorzystanych stanowisk nie przekracza liczby stanowisk"""
        if field.data and self.seats.data and field.data > self.seats.data:
            raise ValidationError('Liczba wykorzystanych stanowisk nie może przekraczać liczby stanowisk.')

class SupportContractForm(FlaskForm):
    """Formularz umowy serwisowej"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    contract_number = StringField('Numer umowy', validators=[Optional(), Length(max=50)])
    
    vendor_id = SelectField('Dostawca', coerce=int, validators=[Optional()])
    
    start_date = DateField('Data rozpoczęcia', validators=[DataRequired()])
    end_date = DateField('Data zakończenia', validators=[DataRequired()])
    
    status = SelectField('Status', choices=[
        ('ACTIVE', 'Aktywna'),
        ('EXPIRED', 'Wygasła'),
        ('PENDING', 'Oczekująca'),
        ('CANCELLED', 'Anulowana')
    ], validators=[DataRequired()])
    
    cost = DecimalField('Koszt', validators=[Optional(), NumberRange(min=0)], places=2)
    description = TextAreaField('Opis', validators=[Optional(), Length(max=1000)])
    contact_info = TextAreaField('Informacje kontaktowe', validators=[Optional(), Length(max=500)])
    
    submit = SubmitField('Zapisz')
    
    def validate_end_date(self, field):
        """Sprawdź czy data zakończenia jest po dacie rozpoczęcia"""
        if field.data and self.start_date.data and field.data < self.start_date.data:
            raise ValidationError('Data zakończenia musi być po dacie rozpoczęcia.')

class MaintenanceForm(FlaskForm):
    """Formularz serwisu"""
    asset_id = SelectField('Zasób', coerce=int, validators=[DataRequired()])
    title = StringField('Tytuł', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=1000)])
    
    maintenance_type = SelectField('Typ serwisu', choices=[
        ('PREVENTIVE', 'Zapobiegawczy'),
        ('CORRECTIVE', 'Naprawczy'),
        ('UPGRADE', 'Aktualizacja'),
        ('INSPECTION', 'Przegląd')
    ], validators=[DataRequired()])
    
    priority = SelectField('Priorytet', choices=[
        ('LOW', 'Niski'),
        ('MEDIUM', 'Średni'),
        ('HIGH', 'Wysoki'),
        ('CRITICAL', 'Krytyczny')
    ], validators=[DataRequired()])
    
    scheduled_date = DateField('Planowana data', validators=[Optional()])
    completed_date = DateField('Data zakończenia', validators=[Optional()])
    
    cost = DecimalField('Koszt', validators=[Optional(), NumberRange(min=0)], places=2)
    notes = TextAreaField('Uwagi', validators=[Optional(), Length(max=1000)])
    
    submit = SubmitField('Zapisz')

class VendorForm(FlaskForm):
    """Formularz dostawcy"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    contact_person = StringField('Osoba kontaktowa', validators=[Optional(), Length(max=100)])
    email = StringField('Email', validators=[Optional(), Length(max=120)])
    phone = StringField('Telefon', validators=[Optional(), Length(max=30)])
    
    address = TextAreaField('Adres', validators=[Optional(), Length(max=500)])
    city = StringField('Miasto', validators=[Optional(), Length(max=50)])
    country = StringField('Kraj', validators=[Optional(), Length(max=50)])
    website = StringField('Strona WWW', validators=[Optional(), Length(max=200)])
    
    is_active = BooleanField('Aktywny', default=True)
    
    submit = SubmitField('Zapisz')

class LocationForm(FlaskForm):
    """Formularz lokalizacji"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    address = TextAreaField('Adres', validators=[Optional(), Length(max=500)])
    city = StringField('Miasto', validators=[Optional(), Length(max=50)])
    country = StringField('Kraj', validators=[Optional(), Length(max=50)])
    postal_code = StringField('Kod pocztowy', validators=[Optional(), Length(max=20)])
    
    is_active = BooleanField('Aktywna', default=True)
    
    submit = SubmitField('Zapisz')
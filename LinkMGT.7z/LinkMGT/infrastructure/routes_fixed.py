from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.infrastructure import bp
from app.infrastructure.forms import AssetForm, LocationForm, VendorForm, LicenseForm, SupportContractForm
from app.models.infrastructure import Asset, Location, Vendor, License, SupportContract, MaintenanceLog
from app.models import User
from app import db
from datetime import datetime, timedelta
from sqlalchemy import or_, and_

# Helper functions
def safe_count_assets():
    """Bezpieczne liczenie zasobów"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("SELECT COUNT(*) FROM assets"))
        return result.scalar() or 0
    except:
        return 0

def safe_count_active_assets():
    """Bezpieczne liczenie aktywnych zasobów"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("SELECT COUNT(*) FROM assets WHERE status = 'active'"))
        return result.scalar() or 0
    except:
        return 0

def safe_count_licenses():
    """Bezpieczne liczenie licencji"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("SELECT COUNT(*) FROM licenses"))
        return result.scalar() or 0
    except:
        return 0

def safe_count_expiring_licenses():
    """Bezpieczne liczenie wygasających licencji"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("""
            SELECT COUNT(*) FROM licenses 
            WHERE expiry_date <= CURRENT_DATE + INTERVAL '30 days'
        """))
        return result.scalar() or 0
    except:
        return 0

def safe_count_locations():
    """Bezpieczne liczenie lokalizacji"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("SELECT COUNT(*) FROM locations"))
        return result.scalar() or 0
    except:
        return 0

def safe_count_vendors():
    """Bezpieczne liczenie dostawców"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("SELECT COUNT(*) FROM vendors"))
        return result.scalar() or 0
    except:
        return 0

def safe_count_support_contracts():
    """Bezpieczne liczenie umów serwisowych"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("SELECT COUNT(*) FROM support_contracts"))
        return result.scalar() or 0
    except:
        return 0

def safe_count_active_contracts():
    """Bezpieczne liczenie aktywnych umów serwisowych"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text("""
            SELECT COUNT(*) FROM support_contracts 
            WHERE end_date >= CURRENT_DATE
        """))
        return result.scalar() or 0
    except:
        return 0

def safe_get_recent_assets(limit=5):
    """Bezpieczne pobieranie ostatnich zasobów"""
    try:
        assets = Asset.query.order_by(Asset.created_at.desc()).limit(limit).all()
        return [asset.to_dict() for asset in assets]
    except:
        return []

def safe_get_expiring_licenses(limit=5):
    """Bezpieczne pobieranie wygasających licencji"""
    try:
        from sqlalchemy import text
        result = db.session.execute(text(f"""
            SELECT id, name, license_type, expiry_date, quantity
            FROM licenses 
            WHERE expiry_date IS NOT NULL AND expiry_date <= CURRENT_DATE + INTERVAL '30 days'
            ORDER BY expiry_date ASC
            LIMIT {limit}
        """))
        
        licenses = []
        for row in result:
            licenses.append({
                'id': row[0],
                'name': row[1],
                'license_type': row[2],
                'expiry_date': row[3],
                'quantity': row[4]
            })
        return licenses
    except Exception as e:
        print(f"Błąd podczas pobierania licencji: {e}")
        return []

def safe_get_upcoming_maintenance(limit=5):
    """Bezpieczne pobieranie nadchodzącej konserwacji"""
    try:
        maintenance_logs = MaintenanceLog.query.filter(
            MaintenanceLog.scheduled_date >= datetime.utcnow()
        ).order_by(MaintenanceLog.scheduled_date).limit(limit).all()
        
        return [log.to_dict() for log in maintenance_logs]
    except Exception as e:
        print(f"Błąd podczas pobierania konserwacji: {e}")
        return []

def safe_get_asset_by_id(asset_id):
    """Bezpieczne pobieranie zasobu po ID"""
    try:
        asset = Asset.query.get(asset_id)
        if asset:
            return asset.to_dict()
        return None
    except:
        return None

def safe_get_license_by_id(license_id):
    """Bezpieczne pobieranie licencji po ID"""
    try:
        license = License.query.get(license_id)
        if license:
            return license.to_dict()
        return None
    except:
        return None

def safe_get_location_by_id(location_id):
    """Bezpieczne pobieranie lokalizacji po ID"""
    try:
        location = Location.query.get(location_id)
        if location:
            return location.to_dict()
        return None
    except:
        return None

def safe_get_vendor_by_id(vendor_id):
    """Bezpieczne pobieranie dostawcy po ID"""
    try:
        vendor = Vendor.query.get(vendor_id)
        if vendor:
            return vendor.to_dict()
        return None
    except:
        return None

# Routes
@bp.route('/')
@login_required
def index():
    """Dashboard infrastruktury"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Bezpieczne pobieranie statystyk
    try:
        stats = {
            'total_assets': safe_count_assets(),
            'active_assets': safe_count_active_assets(),
            'total_licenses': safe_count_licenses(),
            'expiring_licenses': safe_count_expiring_licenses(),
            'total_locations': safe_count_locations(),
            'total_vendors': safe_count_vendors(),
            'support_contracts': safe_count_support_contracts(),
            'active_contracts': safe_count_active_contracts()
        }
        
        # Ostatnie zasoby
        recent_assets = safe_get_recent_assets()
        
        # Wygasające licencje  
        expiring_licenses = safe_get_expiring_licenses()
        
        # Nadchodząca konserwacja
        upcoming_maintenance = safe_get_upcoming_maintenance()
        
    except Exception as e:
        print(f"Błąd podczas pobierania statystyk infrastruktury: {e}")
        stats = {
            'total_assets': 0,
            'active_assets': 0,
            'total_licenses': 0,
            'expiring_licenses': 0,
            'total_locations': 0,
            'total_vendors': 0,
            'support_contracts': 0,
            'active_contracts': 0
        }
        recent_assets = []
        expiring_licenses = []
        upcoming_maintenance = []
    
    return render_template('infrastructure/index.html',
                         title='Infrastruktura IT',
                         stats=stats,
                         recent_assets=recent_assets,
                         expiring_licenses=expiring_licenses,
                         upcoming_maintenance=upcoming_maintenance)

@bp.route('/assets')
@login_required
def assets():
    """Lista zasobów infrastruktury"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pobierz wszystkie zasoby
    try:
        assets_list = Asset.query.all()
    except Exception as e:
        flash(f'Wystąpił błąd podczas pobierania zasobów: {str(e)}', 'danger')
        assets_list = []

    return render_template('infrastructure/assets.html',
                         title='Zasoby IT',
                         assets=assets_list)

@bp.route('/assets/create', methods=['GET', 'POST'])
@login_required
def create_asset():
    """Dodawanie nowego zasobu infrastruktury"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    form = AssetForm()
    
    if form.validate_on_submit():
        try:
            asset = Asset(
                name=form.name.data,
                asset_type=form.asset_type.data,
                status=form.status.data,
                serial_number=form.serial_number.data,
                model=form.model.data,
                manufacturer=form.manufacturer.data,
                purchase_date=form.purchase_date.data,
                warranty_end=form.warranty_end.data,
                location_id=form.location_id.data if form.location_id.data else None,
                assigned_to=form.assigned_to.data if form.assigned_to.data else None,
                notes=form.notes.data,
                specs=form.specs.data,
                cost=form.cost.data,
                vendor_id=form.vendor_id.data if form.vendor_id.data else None,
                asset_tag=form.asset_tag.data
            )
            db.session.add(asset)
            db.session.commit()
            flash('Zasób został pomyślnie dodany!', 'success')
            return redirect(url_for('infrastructure.assets'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania zasobu: {str(e)}', 'danger')
    
    return render_template('infrastructure/asset_form.html',
                         title='Dodaj nowy zasób',
                         form=form)

@bp.route('/maintenance')
@login_required
def maintenance():
    """Lista wpisów konserwacji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pobierz wszystkie wpisy konserwacji
    try:
        maintenance_logs = MaintenanceLog.query.order_by(MaintenanceLog.scheduled_date.desc()).all()
    except Exception as e:
        flash(f'Wystąpił błąd podczas pobierania wpisów konserwacji: {str(e)}', 'danger')
        maintenance_logs = []

    return render_template('infrastructure/maintenance.html',
                         title='Historia konserwacji',
                         logs=maintenance_logs)

@bp.route('/maintenance/create', methods=['GET', 'POST'])
@login_required
def create_maintenance():
    """Dodawanie nowego wpisu konserwacji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    from app.infrastructure.forms import MaintenanceLogForm
    
    form = MaintenanceLogForm()
    
    # Pobierz wszystkie zasoby
    try:
        assets = Asset.query.all()
        form.asset_id.choices = [(asset.id, asset.name) for asset in assets]
    except:
        form.asset_id.choices = []
    
    if form.validate_on_submit():
        try:
            log = MaintenanceLog(
                asset_id=form.asset_id.data,
                maintenance_type=form.maintenance_type.data,
                description=form.description.data,
                scheduled_date=form.scheduled_date.data,
                completed_date=form.completed_date.data if form.completed_date.data else None,
                performed_by=form.performed_by.data,
                cost=form.cost.data,
                notes=form.notes.data
            )
            db.session.add(log)
            db.session.commit()
            flash('Wpis konserwacji został pomyślnie dodany!', 'success')
            return redirect(url_for('infrastructure.maintenance'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania wpisu konserwacji: {str(e)}', 'danger')
    
    return render_template('infrastructure/maintenance_form.html',
                         title='Dodaj nową konserwację',
                         form=form)

@bp.route('/support_contracts')
@login_required
def support_contracts():
    """Lista umów serwisowych"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pobierz wszystkie umowy serwisowe
    try:
        contracts = SupportContract.query.all()
    except Exception as e:
        flash(f'Wystąpił błąd podczas pobierania umów serwisowych: {str(e)}', 'danger')
        contracts = []

    return render_template('infrastructure/support_contracts.html',
                         title='Umowy serwisowe',
                         contracts=contracts)

@bp.route('/support_contracts/create', methods=['GET', 'POST'])
@login_required
def create_support_contract():
    """Dodawanie nowej umowy serwisowej"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    form = SupportContractForm()
    
    # Pobierz listę zasobów do powiązania
    try:
        assets = Asset.query.all()
        form.asset_id.choices = [(0, '-- Brak --')] + [(asset.id, asset.name) for asset in assets]
    except:
        form.asset_id.choices = [(0, '-- Brak --')]
        
    # Pobierz listę dostawców
    try:
        vendors = Vendor.query.all()
        form.vendor_id.choices = [(vendor.id, vendor.name) for vendor in vendors]
    except:
        form.vendor_id.choices = []
    
    if form.validate_on_submit():
        try:
            contract = SupportContract(
                name=form.name.data,
                contract_number=form.contract_number.data,
                description=form.description.data,
                vendor_id=form.vendor_id.data,
                start_date=form.start_date.data,
                end_date=form.end_date.data,
                cost=form.cost.data,
                renewal_terms=form.renewal_terms.data,
                contact_name=form.contact_name.data,
                contact_email=form.contact_email.data,
                contact_phone=form.contact_phone.data,
                notes=form.notes.data
            )
            
            # Powiąż z zasobem jeśli wybrano
            if form.asset_id.data and form.asset_id.data > 0:
                contract.asset_id = form.asset_id.data
                
            db.session.add(contract)
            db.session.commit()
            
            flash('Umowa serwisowa została pomyślnie dodana!', 'success')
            return redirect(url_for('infrastructure.support_contracts'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania umowy serwisowej: {str(e)}', 'danger')
    
    return render_template('infrastructure/support_contract_form.html',
                         title='Nowy kontrakt wsparcia',
                         form=form,
                         action='create')

@bp.route('/assets/<int:asset_id>')
@login_required
def view_asset(asset_id):
    """Wyświetl szczegóły zasobu"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.assets'))
    
    try:
        asset = safe_get_asset_by_id(asset_id)
        if not asset:
            flash('Zasób nie został znaleziony.', 'danger')
            return redirect(url_for('infrastructure.assets'))
        
        return render_template('infrastructure/asset_view.html',
                             title=f'Zasób: {asset["name"]}',
                             asset=asset)
    except Exception as e:
        flash(f'Błąd podczas pobierania zasobu: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.assets'))

@bp.route('/assets/<int:asset_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_asset(asset_id):
    """Edytuj zasób"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.assets'))
    
    from app.infrastructure.forms import AssetForm
    
    try:
        asset = safe_get_asset_by_id(asset_id)
        if not asset:
            flash('Zasób nie został znaleziony.', 'danger')
            return redirect(url_for('infrastructure.assets'))
        
        form = AssetForm()
        
        if request.method == 'GET':
            # Wypełnij formularz danymi zasobu
            form.name.data = asset['name']
            form.asset_type.data = asset['asset_type']
            form.status.data = asset['status']
            form.serial_number.data = asset.get('serial_number')
            form.model.data = asset.get('model')
            form.manufacturer.data = asset.get('manufacturer')
            form.purchase_date.data = asset.get('purchase_date')
            form.warranty_end.data = asset.get('warranty_end')
            form.location_id.data = asset.get('location_id')
            form.assigned_to.data = asset.get('assigned_to')
            form.notes.data = asset.get('notes')
            form.specs.data = asset.get('specs')
            form.cost.data = asset.get('cost')
            form.vendor_id.data = asset.get('vendor_id')
            form.asset_tag.data = asset.get('asset_tag')
        
        if form.validate_on_submit():
            try:
                # Pobierz instancję zasobu
                db_asset = Asset.query.get(asset_id)
                if not db_asset:
                    flash('Zasób nie został znaleziony.', 'danger')
                    return redirect(url_for('infrastructure.assets'))
                
                # Aktualizuj dane
                db_asset.name = form.name.data
                db_asset.asset_type = form.asset_type.data
                db_asset.status = form.status.data
                db_asset.serial_number = form.serial_number.data
                db_asset.model = form.model.data
                db_asset.manufacturer = form.manufacturer.data
                db_asset.purchase_date = form.purchase_date.data
                db_asset.warranty_end = form.warranty_end.data
                db_asset.location_id = form.location_id.data if form.location_id.data else None
                db_asset.assigned_to = form.assigned_to.data if form.assigned_to.data else None
                db_asset.notes = form.notes.data
                db_asset.specs = form.specs.data
                db_asset.cost = form.cost.data
                db_asset.vendor_id = form.vendor_id.data if form.vendor_id.data else None
                db_asset.asset_tag = form.asset_tag.data
                
                db.session.commit()
                flash('Zasób został pomyślnie zaktualizowany!', 'success')
                return redirect(url_for('infrastructure.view_asset', asset_id=asset_id))
            except Exception as e:
                db.session.rollback()
                flash(f'Wystąpił błąd podczas aktualizacji zasobu: {str(e)}', 'danger')
                
        return render_template('infrastructure/asset_form.html',
                             title=f'Edytuj zasób: {asset["name"]}',
                             form=form,
                             asset=asset)
    except Exception as e:
        flash(f'Błąd podczas edycji zasobu: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.assets'))

@bp.route('/licenses')
@login_required
def licenses():
    """Lista licencji oprogramowania"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pobierz wszystkie licencje
    try:
        licenses_list = License.query.all()
    except Exception as e:
        flash(f'Wystąpił błąd podczas pobierania licencji: {str(e)}', 'danger')
        licenses_list = []

    return render_template('infrastructure/licenses.html',
                          title='Licencje oprogramowania',
                          licenses=licenses_list)

@bp.route('/licenses/create', methods=['GET', 'POST'])
@login_required
def create_license():
    """Dodawanie nowej licencji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    form = LicenseForm()
    
    # Pobierz listę zasobów dla powiązania z licencją
    try:
        assets = Asset.query.all()
        form.asset_id.choices = [(0, '-- Brak --')] + [(asset.id, f"{asset.name} ({asset.asset_tag})") for asset in assets]
    except Exception as e:
        print(f"Błąd podczas ładowania zasobów: {e}")
        form.asset_id.choices = [(0, '-- Brak --')]
    
    if form.validate_on_submit():
        try:
            license = License(
                name=form.name.data,
                description=form.description.data,
                license_type=form.license_type.data,
                license_key=form.license_key.data,
                purchase_date=form.purchase_date.data,
                expiry_date=form.expiry_date.data,
                quantity=form.quantity.data,
                cost=form.cost.data,
                vendor_id=form.vendor_id.data if form.vendor_id.data else None,
                notes=form.notes.data
            )
            
            # Powiąż z zasobem jeśli wybrano
            if form.asset_id.data and form.asset_id.data > 0:
                license.asset_id = form.asset_id.data
                
            db.session.add(license)
            db.session.commit()
            
            flash('Licencja została pomyślnie dodana!', 'success')
            return redirect(url_for('infrastructure.licenses'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania licencji: {str(e)}', 'danger')
    
    return render_template('infrastructure/license_form.html',
                          title='Dodaj licencję',
                          form=form)

@bp.route('/licenses/<int:license_id>/delete', methods=['POST'])
@login_required
def delete_license(license_id):
    """Usuwanie licencji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    license = License.query.get_or_404(license_id)
    
    try:
        db.session.delete(license)
        db.session.commit()
        flash('Licencja została usunięta!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Wystąpił błąd podczas usuwania licencji: {str(e)}', 'danger')
    
    return redirect(url_for('infrastructure.licenses'))

@bp.route('/licenses/<int:license_id>')
@login_required
def view_license(license_id):
    """Wyświetl szczegóły licencji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.licenses'))
    
    try:
        license = License.query.get_or_404(license_id)
        return render_template('infrastructure/license_view.html',
                              title=f'Licencja: {license.name}',
                              license=license)
    except Exception as e:
        flash(f'Błąd podczas pobierania licencji: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.licenses'))

@bp.route('/licenses/<int:license_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_license(license_id):
    """Edycja licencji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.licenses'))
    
    try:
        license = License.query.get_or_404(license_id)
        form = LicenseForm(obj=license)
        
        # Pobierz listę zasobów dla powiązania z licencją
        try:
            assets = Asset.query.all()
            form.asset_id.choices = [(0, '-- Brak --')] + [(asset.id, f"{asset.name} ({asset.asset_tag})") for asset in assets]
            if not license.asset_id:
                form.asset_id.data = 0
        except Exception as e:
            print(f"Błąd podczas ładowania zasobów: {e}")
            form.asset_id.choices = [(0, '-- Brak --')]
        
        if form.validate_on_submit():
            try:
                license.name = form.name.data
                license.description = form.description.data
                license.license_type = form.license_type.data
                license.license_key = form.license_key.data
                license.purchase_date = form.purchase_date.data
                license.expiry_date = form.expiry_date.data
                license.quantity = form.quantity.data
                license.cost = form.cost.data
                license.vendor_id = form.vendor_id.data if form.vendor_id.data else None
                license.notes = form.notes.data
                
                # Powiąż z zasobem jeśli wybrano
                if form.asset_id.data and form.asset_id.data > 0:
                    license.asset_id = form.asset_id.data
                else:
                    license.asset_id = None
                    
                db.session.commit()
                
                flash('Licencja została pomyślnie zaktualizowana!', 'success')
                return redirect(url_for('infrastructure.view_license', license_id=license_id))
            except Exception as e:
                db.session.rollback()
                flash(f'Wystąpił błąd podczas aktualizacji licencji: {str(e)}', 'danger')
        
        return render_template('infrastructure/license_form.html',
                              title=f'Edytuj licencję: {license.name}',
                              form=form,
                              license=license)
    except Exception as e:
        flash(f'Błąd podczas edycji licencji: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.licenses'))

@bp.route('/locations')
@login_required
def locations():
    """Lista lokalizacji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pobierz wszystkie lokalizacje
    try:
        locations_list = Location.query.all()
    except Exception as e:
        flash(f'Wystąpił błąd podczas pobierania lokalizacji: {str(e)}', 'danger')
        locations_list = []

    return render_template('infrastructure/locations.html',
                         title='Lokalizacje',
                         locations=locations_list)

@bp.route('/locations/create', methods=['GET', 'POST'])
@login_required
def create_location():
    """Dodawanie nowej lokalizacji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    form = LocationForm()
    
    if form.validate_on_submit():
        try:
            location = Location(
                name=form.name.data,
                address=form.address.data,
                city=form.city.data,
                postal_code=form.postal_code.data,
                country=form.country.data,
                contact_person=form.contact_person.data,
                contact_email=form.contact_email.data,
                contact_phone=form.contact_phone.data,
                notes=form.notes.data
            )
            db.session.add(location)
            db.session.commit()
            flash('Lokalizacja została pomyślnie dodana!', 'success')
            return redirect(url_for('infrastructure.locations'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania lokalizacji: {str(e)}', 'danger')
    
    return render_template('infrastructure/location_form.html',
                         title='Dodaj lokalizację',
                         form=form)

@bp.route('/locations/<int:location_id>')
@login_required
def view_location(location_id):
    """Wyświetl szczegóły lokalizacji"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.locations'))
    
    try:
        location = safe_get_location_by_id(location_id)
        if not location:
            flash('Lokalizacja nie została znaleziona.', 'danger')
            return redirect(url_for('infrastructure.locations'))
        
        return render_template('infrastructure/location_view.html',
                             title=f'Lokalizacja: {location["name"]}',
                             location=location)
    except Exception as e:
        flash(f'Błąd podczas pobierania lokalizacji: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.locations'))

@bp.route('/locations/<int:location_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_location(location_id):
    """Edytuj lokalizację"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.locations'))
    
    try:
        location = Location.query.get_or_404(location_id)
        form = LocationForm(obj=location)
        
        if form.validate_on_submit():
            try:
                location.name = form.name.data
                location.address = form.address.data
                location.city = form.city.data
                location.postal_code = form.postal_code.data
                location.country = form.country.data
                location.contact_person = form.contact_person.data
                location.contact_email = form.contact_email.data
                location.contact_phone = form.contact_phone.data
                location.notes = form.notes.data
                
                db.session.commit()
                flash('Lokalizacja została pomyślnie zaktualizowana!', 'success')
                return redirect(url_for('infrastructure.view_location', location_id=location_id))
            except Exception as e:
                db.session.rollback()
                flash(f'Wystąpił błąd podczas aktualizacji lokalizacji: {str(e)}', 'danger')
                
        return render_template('infrastructure/location_form.html',
                             title=f'Edytuj lokalizację: {location.name}',
                             form=form,
                             location=location)
    except Exception as e:
        flash(f'Błąd podczas edycji lokalizacji: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.locations'))

@bp.route('/vendors')
@login_required
def vendors():
    """Lista dostawców"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pobierz wszystkich dostawców
    try:
        vendors_list = Vendor.query.all()
    except Exception as e:
        flash(f'Wystąpił błąd podczas pobierania dostawców: {str(e)}', 'danger')
        vendors_list = []

    return render_template('infrastructure/vendors.html',
                         title='Dostawcy',
                         vendors=vendors_list)

@bp.route('/vendors/create', methods=['GET', 'POST'])
@login_required
def create_vendor():
    """Dodawanie nowego dostawcy"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('main.index'))
    
    form = VendorForm()
    
    if form.validate_on_submit():
        try:
            vendor = Vendor(
                name=form.name.data,
                contact_person=form.contact_person.data,
                contact_email=form.contact_email.data,
                contact_phone=form.contact_phone.data,
                address=form.address.data,
                website=form.website.data,
                notes=form.notes.data
            )
            db.session.add(vendor)
            db.session.commit()
            flash('Dostawca został pomyślnie dodany!', 'success')
            return redirect(url_for('infrastructure.vendors'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania dostawcy: {str(e)}', 'danger')
    
    return render_template('infrastructure/vendor_form.html',
                         title='Dodaj dostawcę',
                         form=form)

@bp.route('/vendors/<int:vendor_id>')
@login_required
def view_vendor(vendor_id):
    """Wyświetl szczegóły dostawcy"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.vendors'))
    
    try:
        vendor = safe_get_vendor_by_id(vendor_id)
        if not vendor:
            flash('Dostawca nie został znaleziony.', 'danger')
            return redirect(url_for('infrastructure.vendors'))
        
        return render_template('infrastructure/vendor_view.html',
                             title=f'Dostawca: {vendor["name"]}',
                             vendor=vendor)
    except Exception as e:
        flash(f'Błąd podczas pobierania dostawcy: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.vendors'))

@bp.route('/vendors/<int:vendor_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_vendor(vendor_id):
    """Edytuj dostawcę"""
    if not current_user.is_admin:
        flash('Wymagane uprawnienia administratora.', 'danger')
        return redirect(url_for('infrastructure.vendors'))
    
    try:
        vendor = Vendor.query.get_or_404(vendor_id)
        form = VendorForm(obj=vendor)
        
        if form.validate_on_submit():
            try:
                vendor.name = form.name.data
                vendor.contact_person = form.contact_person.data
                vendor.contact_email = form.contact_email.data
                vendor.contact_phone = form.contact_phone.data
                vendor.address = form.address.data
                vendor.website = form.website.data
                vendor.notes = form.notes.data
                
                db.session.commit()
                flash('Dostawca został pomyślnie zaktualizowany!', 'success')
                return redirect(url_for('infrastructure.view_vendor', vendor_id=vendor_id))
            except Exception as e:
                db.session.rollback()
                flash(f'Wystąpił błąd podczas aktualizacji dostawcy: {str(e)}', 'danger')
                
        return render_template('infrastructure/vendor_form.html',
                             title=f'Edytuj dostawcę: {vendor.name}',
                             form=form,
                             vendor=vendor)
    except Exception as e:
        flash(f'Błąd podczas edycji dostawcy: {str(e)}', 'danger')
        return redirect(url_for('infrastructure.vendors'))

# API endpoints - niech pozostaną niezmienne
@bp.route('/api/assets/<int:asset_id>/status', methods=['POST'])
@login_required
def api_update_asset_status(asset_id):
    """API do aktualizacji statusu zasobu"""
    if not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Brak uprawnień administratora.'}), 403
    
    data = request.get_json()
    if not data or 'status' not in data:
        return jsonify({'success': False, 'error': 'Brak parametru status.'}), 400
    
    try:
        asset = Asset.query.get_or_404(asset_id)
        asset.status = data['status']
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@bp.route('/api/assets/search')
@login_required
def api_search_assets():
    """API do wyszukiwania zasobów"""
    if not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Brak uprawnień administratora.'}), 403
    
    query = request.args.get('q', '')
    if not query or len(query) < 3:
        return jsonify({'success': False, 'error': 'Zapytanie wyszukiwania musi mieć co najmniej 3 znaki.'}), 400
        
    try:
        assets = Asset.query.filter(
            or_(
                Asset.name.ilike(f'%{query}%'),
                Asset.serial_number.ilike(f'%{query}%'),
                Asset.asset_tag.ilike(f'%{query}%'),
                Asset.model.ilike(f'%{query}%'),
                Asset.manufacturer.ilike(f'%{query}%')
            )
        ).limit(10).all()
        
        result = []
        for asset in assets:
            result.append({
                'id': asset.id,
                'name': asset.name,
                'asset_tag': asset.asset_tag or '',
                'status': asset.status,
                'model': asset.model or '',
                'manufacturer': asset.manufacturer or ''
            })
            
        return jsonify({'success': True, 'assets': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

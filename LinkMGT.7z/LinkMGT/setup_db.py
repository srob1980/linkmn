import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def setup_database():
    """Set up the database with initial data"""
    print("Setting up the LinkMGT database...")
    
    # Import Flask app and database
    from app import create_app, db
    app = create_app()
    
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Now import models after tables are created
        from app.models.user import User
        from app.models.config import AppConfig
        
        # Check if admin user exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            print("Creating admin user...")
            admin = User(
                username='admin',
                email='admin@example.com',
                first_name='Admin',
                last_name='Admin',
                is_admin=True,
                is_active=True
            )
            admin.set_password('admin')
            db.session.add(admin)
            
            # Add basic configuration
            configs = [
                ('APP_NAME', 'LinkMGT', 'Application name'),
                ('APP_VERSION', '1.0', 'Application version'),
                ('ENABLE_REGISTRATION', 'true', 'Allow new user registration'),
                ('ENABLE_PASSWORD_RESET', 'true', 'Allow password reset')
            ]
            
            for key, value, description in configs:
                config = AppConfig(
                    key=key,
                    value=value,
                    description=description
                )
                db.session.add(config)
                
            db.session.commit()
            print("Admin user created successfully!")
            print("Username: admin")
            print("Password: admin")
        else:
            print("Admin user already exists.")
        
        print("Database setup complete!")

if __name__ == "__main__":
    setup_database()

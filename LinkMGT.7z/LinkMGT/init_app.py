import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def initialize_application():
    """Initialize the LinkMGT application database and configuration"""
    try:
        print("🚀 Initializing LinkMGT application...")
        
        # Import application
        from app import create_app, db
        from app.models.user import User
        from app.models.config import AppConfig
        from app.models.team import Team
        from app.models.link import Category, Link, Tag
        
        # Create app with test config
        app = create_app()
        
        with app.app_context():
            print("📦 Creating database tables...")
            db.create_all()
            
            # Create admin user if it doesn't exist
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                print("👤 Creating admin user...")
                admin = User(
                    username='admin',
                    email='admin@example.com',
                    first_name='Admin',
                    last_name='User',
                    is_admin=True,
                    is_active=True
                )
                admin.set_password('admin')
                db.session.add(admin)
                db.session.commit()
                print("✅ Admin user created successfully")
                print("   Username: admin")
                print("   Password: admin")
            else:
                print("ℹ️ Admin user already exists")
            
            # Create application configuration
            if AppConfig.query.count() == 0:
                print("⚙️ Creating application configuration...")
                configs = [
                    ('APP_NAME', 'LinkMGT', 'Application name'),
                    ('APP_VERSION', '1.0.0', 'Application version'),
                    ('ENABLE_REGISTRATION', 'true', 'Allow user registration'),
                    ('ENABLE_PASSWORD_RESET', 'true', 'Allow password reset'),
                    ('MAX_LINKS_PER_USER', '1000', 'Maximum links per user'),
                    ('ALLOW_PUBLIC_LINKS', 'true', 'Allow public links'),
                ]
                
                for key, value, description in configs:
                    config = AppConfig(
                        key=key,
                        value=value,
                        description=description,
                        created_at=datetime.utcnow()
                    )
                    db.session.add(config)
                db.session.commit()
                print("✅ Application configuration created")
            
            # Create sample categories if none exist
            if Category.query.count() == 0:
                print("📂 Creating sample categories...")
                categories = [
                    ('Development', 'Development resources and tools', '#007bff', 'fas fa-code'),
                    ('Documentation', 'Documentation and reference materials', '#28a745', 'fas fa-book'),
                    ('Infrastructure', 'Infrastructure and server resources', '#dc3545', 'fas fa-server'),
                ]
                
                for name, description, color, icon in categories:
                    category = Category(
                        name=name,
                        description=description,
                        color=color,
                        icon=icon,
                        is_active=True,
                        created_by=admin.id
                    )
                    db.session.add(category)
                db.session.commit()
                print("✅ Sample categories created")
            
            # Create sample teams if none exist
            if Team.query.count() == 0:
                print("👥 Creating sample teams...")
                teams = [
                    ('IT Department', 'Information Technology team', '#0066cc'),
                    ('Development', 'Software development team', '#339933'),
                    ('Operations', 'Operations team', '#ff9900')
                ]
                
                for name, description, color in teams:
                    team = Team(
                        name=name,
                        description=description,
                        color=color,
                        is_active=True,
                        created_by=admin.id
                    )
                    db.session.add(team)
                db.session.commit()
                print("✅ Sample teams created")
            
            print("\n✅ LinkMGT initialization complete!")
            print("\n📋 Login information:")
            print("   Username: admin")
            print("   Password: admin")
            print("\n🌐 Run the application:")
            print("   python run.py")
            
    except Exception as e:
        print(f"❌ Error during initialization: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == '__main__':
    initialize_application()

import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

from app import create_app, db
from app.models.user import User

def init_db():
    """Initialize the database and create admin user if it doesn't exist"""
    app = create_app()
    
    with app.app_context():
        print("Creating database tables...")
        db.create_all()
        
        # Check if admin user exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            print("Creating admin user...")
            admin = User(
                username='admin',
                email='admin@example.com',
                is_admin=True,
                is_active=True
            )
            admin.set_password('admin')
            db.session.add(admin)
            
            # Create basic configurations
            from app.models.config import AppConfig
            
            config_items = [
                ('APP_NAME', 'LinkMGT', 'Application name'),
                ('APP_VERSION', '1.0', 'Application version'),
                ('ENABLE_REGISTRATION', 'true', 'Allow user registration'),
            ]
            
            for key, value, description in config_items:
                config = AppConfig(
                    key=key,
                    value=value,
                    description=description,
                    created_at=datetime.utcnow()
                )
                db.session.add(config)
            
            db.session.commit()
            print("Admin user created. Username: admin, Password: admin")
        else:
            print("Admin user already exists")
        
        print("Database initialization complete!")

if __name__ == '__main__':
    init_db()
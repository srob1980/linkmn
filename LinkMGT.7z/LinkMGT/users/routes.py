from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.users import bp
from app.models import User, Team, Link
from app import db
from app.auth.decorators import admin_required

@bp.route('/')
@login_required
def index():
    """Lista użytkowników (tylko dla adminów) lub profil użytkownika"""
    if current_user.is_admin:
        # Dla adminów - pokaż listę wszystkich użytkowników
        page = request.args.get('page', 1, type=int)
        users = User.query.order_by(User.created_at.desc()).paginate(
            page=page, per_page=20, error_out=False)
        
        return render_template('users/index.html',
                             title='Użytkownicy',
                             users=users)
    else:
        # Dla zwykłych użytkowników - przekieruj do profilu
        return redirect(url_for('users.profile'))

@bp.route('/profile')
@login_required
def profile():
    """Profil aktualnego użytkownika"""
      # Statystyki użytkownika
    user_stats = {
        'total_links': current_user.created_links.filter_by(is_active=True).count(),
        'public_links': current_user.created_links.filter_by(is_active=True, is_public=True).count(),
        'private_links': current_user.created_links.filter_by(is_active=True, is_public=False).count(),
        'total_teams': len(current_user.teams) if hasattr(current_user, 'teams') else 0,
        'total_clicks': sum(link.click_count for link in current_user.created_links)
    }
    
    # Ostatnie linki
    recent_links = current_user.created_links.filter_by(is_active=True).order_by(Link.created_at.desc()).limit(5).all()
    
    # Najpopularniejsze linki
    popular_links = current_user.created_links.filter_by(is_active=True).order_by(Link.click_count.desc()).limit(5).all()
    
    # Zespoły użytkownika
    user_teams = current_user.teams.all()
    
    return render_template('users/profile.html',
                         title='Mój profil',
                         user=current_user,
                         user_stats=user_stats,
                         recent_links=recent_links,
                         popular_links=popular_links,
                         user_teams=user_teams)

@bp.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    """Edycja profilu użytkownika"""
    
    if request.method == 'POST':
        try:
            # Aktualizuj dane użytkownika
            current_user.first_name = request.form.get('first_name', '').strip()
            current_user.last_name = request.form.get('last_name', '').strip()
            current_user.email = request.form.get('email', '').strip()
            
            # Sprawdź czy email nie jest już używany przez innego użytkownika
            existing_user = User.query.filter(User.email == current_user.email, User.id != current_user.id).first()
            if existing_user:
                flash('Ten adres email jest już używany przez innego użytkownika.', 'danger')
                return render_template('users/edit_profile.html', title='Edytuj profil')
            
            # Zmiana hasła (opcjonalnie)
            new_password = request.form.get('new_password', '').strip()
            if new_password:
                current_password = request.form.get('current_password', '').strip()
                if not current_user.check_password(current_password):
                    flash('Aktualne hasło jest nieprawidłowe.', 'danger')
                    return render_template('users/edit_profile.html', title='Edytuj profil')
                
                confirm_password = request.form.get('confirm_password', '').strip()
                if new_password != confirm_password:
                    flash('Nowe hasła nie są identyczne.', 'danger')
                    return render_template('users/edit_profile.html', title='Edytuj profil')
                
                current_user.set_password(new_password)
                flash('Hasło zostało zmienione.', 'info')
            
            db.session.commit()
            flash('Profil został zaktualizowany.', 'success')
            return redirect(url_for('users.profile'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji profilu: {str(e)}', 'danger')
    
    return render_template('users/edit_profile.html', title='Edytuj profil')

@bp.route('/view/<int:user_id>')
@login_required
def view(user_id):
    """Podgląd profilu użytkownika (tylko dla adminów lub publiczne info)"""
    
    user = User.query.get_or_404(user_id)
    
    # Sprawdź uprawnienia
    if not current_user.is_admin and user != current_user:
        flash('Brak uprawnień do przeglądania tego profilu.', 'danger')
        return redirect(url_for('main.index'))
    
    # Statystyki użytkownika
    user_stats = {
        'total_links': user.created_links.filter_by(is_active=True).count(),
        'public_links': user.created_links.filter_by(is_active=True, is_public=True).count(),
        'total_teams': user.teams.count(),
        'member_since': user.created_at
    }
    
    # Publiczne linki użytkownika
    public_links = user.created_links.filter_by(is_active=True, is_public=True).order_by(Link.created_at.desc()).limit(10).all()
    
    return render_template('users/view.html',
                         title=f'Profil: {user.display_name}',
                         user=user,
                         user_stats=user_stats,
                         public_links=public_links)

@bp.route('/admin/users')
@login_required
@admin_required
def admin_users():
    """Panel administracyjny użytkowników"""
    
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str)
    
    # Bazowe zapytanie
    query = User.query
    
    # Filtrowanie wyszukiwania
    if search:
        query = query.filter(
            db.or_(
                User.username.ilike(f'%{search}%'),
                User.email.ilike(f'%{search}%'),
                User.first_name.ilike(f'%{search}%'),
                User.last_name.ilike(f'%{search}%')
            )
        )
    
    # Paginacja
    users = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False)
    
    return render_template('users/admin_users.html',
                         title='Zarządzanie użytkownikami',
                         users=users,
                         search=search)

@bp.route('/admin/toggle_status/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def toggle_user_status(user_id):
    """Zmień status aktywności użytkownika"""
    
    user = User.query.get_or_404(user_id)
    
    # Nie pozwalaj wyłączać siebie
    if user == current_user:
        return jsonify({'success': False, 'message': 'Nie możesz wyłączyć własnego konta.'}), 400
    
    try:
        user.is_active = not user.is_active
        db.session.commit()
        
        status = 'aktywowany' if user.is_active else 'dezaktywowany'
        return jsonify({
            'success': True,
            'message': f'Użytkownik {user.username} został {status}.',
            'is_active': user.is_active
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@bp.route('/admin/toggle_admin/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def toggle_admin_status(user_id):
    """Zmień status administratora użytkownika"""
    
    user = User.query.get_or_404(user_id)
    
    try:
        user.is_admin = not user.is_admin
        db.session.commit()
        
        status = 'nadano' if user.is_admin else 'odebrano'
        return jsonify({
            'success': True,
            'message': f'Uprawnienia administratora {status} użytkownikowi {user.username}.',
            'is_admin': user.is_admin
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@bp.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create():
    """Utwórz nowego użytkownika (tylko dla adminów)"""
    
    from app.users.forms import UserForm
    
    form = UserForm()
    
    if form.validate_on_submit():
        try:
            # Sprawdź czy username już istnieje
            existing_user = User.query.filter_by(username=form.username.data).first()
            if existing_user:
                flash('Użytkownik o tej nazwie już istnieje.', 'danger')
                return render_template('users/create.html', title='Nowy użytkownik', form=form)
            
            # Sprawdź czy email już istnieje
            existing_email = User.query.filter_by(email=form.email.data).first()
            if existing_email:
                flash('Użytkownik z tym adresem email już istnieje.', 'danger')
                return render_template('users/create.html', title='Nowy użytkownik', form=form)
            
            # Utwórz nowego użytkownika
            user = User(
                username=form.username.data,
                email=form.email.data,
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                is_admin=form.is_admin.data,
                is_active=form.is_active.data
            )
            user.set_password(form.password.data)
            
            db.session.add(user)
            db.session.commit()
            
            flash(f'Użytkownik {user.username} został utworzony pomyślnie.', 'success')
            return redirect(url_for('users.view', user_id=user.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas tworzenia użytkownika: {str(e)}', 'danger')
    
    return render_template('users/create.html', title='Nowy użytkownik', form=form)

@bp.route('/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit(user_id):
    """Edytuj użytkownika (tylko dla adminów)"""
    
    user = User.query.get_or_404(user_id)
    
    from app.users.forms import EditUserForm
    form = EditUserForm()
    
    if request.method == 'GET':
        form.username.data = user.username
        form.email.data = user.email
        form.first_name.data = user.first_name
        form.last_name.data = user.last_name
        form.is_admin.data = user.is_admin
        form.is_active.data = user.is_active
    
    if form.validate_on_submit():
        try:
            # Sprawdź czy username już istnieje (z wyłączeniem aktualnego użytkownika)
            existing_user = User.query.filter(User.username == form.username.data, User.id != user.id).first()
            if existing_user:
                flash('Użytkownik o tej nazwie już istnieje.', 'danger')
                return render_template('users/edit.html', title='Edytuj użytkownika', form=form, user=user)
            
            # Sprawdź czy email już istnieje (z wyłączeniem aktualnego użytkownika)
            existing_email = User.query.filter(User.email == form.email.data, User.id != user.id).first()
            if existing_email:
                flash('Użytkownik z tym adresem email już istnieje.', 'danger')
                return render_template('users/edit.html', title='Edytuj użytkownika', form=form, user=user)
            
            # Aktualizuj dane użytkownika
            user.username = form.username.data
            user.email = form.email.data
            user.first_name = form.first_name.data
            user.last_name = form.last_name.data
            user.is_admin = form.is_admin.data
            user.is_active = form.is_active.data
            
            # Zmień hasło jeśli podano nowe
            if form.password.data:
                user.set_password(form.password.data)
            
            db.session.commit()
            
            flash(f'Dane użytkownika {user.username} zostały zaktualizowane.', 'success')
            return redirect(url_for('users.view', user_id=user.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas edycji użytkownika: {str(e)}', 'danger')
    
    return render_template('users/edit.html', title='Edytuj użytkownika', form=form, user=user)

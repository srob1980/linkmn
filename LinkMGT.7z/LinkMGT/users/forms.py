from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, ValidationError, Email, Length, Optional, EqualTo
from app.models import User

class UserForm(FlaskForm):
    """Form for user management (edit/create)"""
    username = StringField('Nazwa użytkownika', validators=[
        DataRequired(),
        Length(min=3, max=64)
    ], render_kw={'placeholder': 'Wprowadź nazwę użytkownika'})
    email = StringField('Email', validators=[
        DataRequired(),
        Email(),
        Length(max=120)
    ], render_kw={'placeholder': 'user@example.com'})
    first_name = StringField('Imię', validators=[
        Optional(),
        Length(max=64)
    ], render_kw={'placeholder': 'Imię'})
    last_name = StringField('Nazwisko', validators=[
        Optional(),
        Length(max=64)
    ], render_kw={'placeholder': 'Nazwisko'})
    password = PasswordField('Hasło', validators=[
        DataRequired(),
        Length(min=6, message='Hasło musi mieć minimum 6 znaków')
    ], render_kw={'placeholder': 'Wprowadź hasło'})
    password2 = PasswordField('Potwierdź hasło', validators=[
        DataRequired(),
        EqualTo('password', message='Hasła muszą być identyczne')
    ], render_kw={'placeholder': 'Potwierdź hasło'})
    is_admin = BooleanField('Administrator', default=False, description='Czy użytkownik ma uprawnienia administratora')
    is_active = BooleanField('Aktywny', default=True, description='Czy konto użytkownika jest aktywne')
    submit = SubmitField('Utwórz użytkownika')

    def __init__(self, original_username=None, *args, **kwargs):
        super(UserForm, self).__init__(*args, **kwargs)
        self.original_username = original_username

    def validate_username(self, username):
        if username.data != self.original_username:
            user = User.query.filter_by(username=username.data).first()
            if user:
                raise ValidationError('Ta nazwa użytkownika jest już zajęta.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user and user.username != self.original_username:
            raise ValidationError('Ten adres email jest już zarejestrowany.')

class UserCreateForm(FlaskForm):
    """Form for creating new users"""
    username = StringField('Nazwa użytkownika', validators=[
        DataRequired(),
        Length(min=3, max=64)
    ])
    email = StringField('Email', validators=[
        DataRequired(),
        Email(),
        Length(max=120)
    ])
    password = PasswordField('Hasło', validators=[
        DataRequired(),
        Length(min=8, message='Hasło musi mieć minimum 8 znaków')
    ])
    password2 = PasswordField('Powtórz hasło', validators=[
        DataRequired(),
        EqualTo('password', message='Hasła muszą być identyczne')
    ])
    is_active = BooleanField('Aktywny', default=True)
    is_admin = BooleanField('Administrator')
    submit = SubmitField('Dodaj użytkownika')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Ta nazwa użytkownika jest już zajęta.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Ten adres email jest już zarejestrowany.')

class EditUserForm(FlaskForm):
    username = StringField('Nazwa użytkownika', 
                          validators=[DataRequired(), Length(min=3, max=64)],
                          render_kw={'placeholder': 'Wprowadź nazwę użytkownika'})
    
    email = StringField('Email', 
                       validators=[DataRequired(), Email()],
                       render_kw={'placeholder': 'user@example.com'})
    
    first_name = StringField('Imię', 
                            validators=[Optional(), Length(max=64)],
                            render_kw={'placeholder': 'Imię'})
    
    last_name = StringField('Nazwisko', 
                           validators=[Optional(), Length(max=64)],
                           render_kw={'placeholder': 'Nazwisko'})
    
    password = PasswordField('Nowe hasło (zostaw puste aby nie zmieniać)', 
                            validators=[Optional(), Length(min=6)],
                            render_kw={'placeholder': 'Nowe hasło'})
    
    password2 = PasswordField('Potwierdź nowe hasło',
                             validators=[EqualTo('password', message='Hasła muszą być identyczne')],
                             render_kw={'placeholder': 'Potwierdź nowe hasło'})
    
    is_admin = BooleanField('Administrator', 
                           default=False,
                           description='Czy użytkownik ma uprawnienia administratora')
    
    is_active = BooleanField('Aktywny', 
                            default=True,
                            description='Czy konto użytkownika jest aktywne')
    
    submit = SubmitField('Zapisz zmiany')

class ProfileForm(FlaskForm):
    first_name = StringField('Imię', 
                            validators=[Optional(), Length(max=64)],
                            render_kw={'placeholder': 'Imię'})
    
    last_name = StringField('Nazwisko', 
                           validators=[Optional(), Length(max=64)],
                           render_kw={'placeholder': 'Nazwisko'})
    
    email = StringField('Email', 
                       validators=[DataRequired(), Email()],
                       render_kw={'placeholder': 'user@example.com'})
    
    current_password = PasswordField('Aktualne hasło (wymagane do zmiany hasła)', 
                                    validators=[Optional()],
                                    render_kw={'placeholder': 'Aktualne hasło'})
    
    new_password = PasswordField('Nowe hasło', 
                                validators=[Optional(), Length(min=6)],
                                render_kw={'placeholder': 'Nowe hasło'})
    
    confirm_password = PasswordField('Potwierdź nowe hasło',
                                    validators=[EqualTo('new_password', message='Hasła muszą być identyczne')],
                                    render_kw={'placeholder': 'Potwierdź nowe hasło'})
    
    submit = SubmitField('Zapisz profil')
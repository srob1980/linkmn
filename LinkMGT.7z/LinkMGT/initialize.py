import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def initialize_application():
    """Complete initialization of the LinkMGT application"""
    
    try:
        print("🚀 Initializing LinkMGT application...")
        
        # Import the application
        from app import create_app, db
        
        # Create the application
        app = create_app()
        
        with app.app_context():
            print("📦 Creating database tables...")
            
            # Create all database tables
            db.create_all()
            
            # Import models
            from app.models.user import User
            from app.models.team import Team
            from app.models.link import Category, Link, Tag
            from app.models.config import AppConfig
            
            # Check if admin user already exists
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                print("👤 Creating admin account...")
                admin = User(
                    username='admin',
                    email='admin@example.com',
                    first_name='Admin',
                    last_name='User',
                    is_admin=True,
                    is_active=True
                )
                admin.set_password('admin')
                db.session.add(admin)
                db.session.commit()
                print("✅ Admin user created: admin/admin")
            else:
                print("ℹ️ Admin account already exists")
            
            # Create initial configuration
            if AppConfig.query.count() == 0:
                print("⚙️ Creating initial configuration...")
                configs = [
                    ('APP_NAME', 'LinkMGT', 'Application name'),
                    ('APP_VERSION', '1.0.0', 'Application version'),
                    ('ENABLE_REGISTRATION', 'true', 'Allow new user registration'),
                    ('ALLOW_PASSWORD_RESET', 'true', 'Allow users to reset passwords')
                ]
                
                for key, value, description in configs:
                    config = AppConfig(key=key, value=value, description=description)
                    db.session.add(config)
                db.session.commit()
                print("✅ Initial configuration created")
            
            # Create sample categories if none exist
            if Category.query.count() == 0:
                print("📂 Creating sample categories...")
                categories = [
                    ('Development', 'Development tools and resources', '#007bff'),
                    ('Documentation', 'Documentation and knowledge base', '#28a745'),
                    ('Infrastructure', 'Infrastructure and server resources', '#dc3545')
                ]
                
                for name, description, color in categories:
                    category = Category(
                        name=name, 
                        description=description, 
                        color=color,
                        is_active=True,
                        created_by=admin.id
                    )
                    db.session.add(category)
                db.session.commit()
                print("✅ Sample categories created")
            
            # Create sample teams if none exist
            if Team.query.count() == 0:
                print("👥 Creating sample teams...")
                teams = [
                    ('IT Department', 'Information Technology team', '#0066cc'),
                    ('Development', 'Software development team', '#339933'),
                    ('Operations', 'Operations team', '#ff9900')
                ]
                
                for name, description, color in teams:
                    team = Team(
                        name=name,
                        description=description,
                        color=color,
                        is_active=True,
                        created_by=admin.id
                    )
                    db.session.add(team)
                db.session.commit()
                print("✅ Sample teams created")
            
            print("✅ Application initialization complete!")
            print("\n📋 Login information:")
            print("Username: admin")
            print("Password: admin")
            print("\n🌐 Run the application:")
            print("python run.py")
            
            return True
            
    except Exception as e:
        print(f"❌ Error during initialization: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    initialize_application()

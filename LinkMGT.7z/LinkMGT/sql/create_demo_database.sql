-- Parametr do zmiany nazwy bazy danych
\set dbname 'linkmgt_demo'

-- Utwórz bazę danych (usuń istniejącą jeśli istnieje)
DROP DATABASE IF EXISTS :'dbname';
CREATE DATABASE :'dbname';

-- Połącz z utworzoną bazą danych
\c :dbname

BEGIN;

-- Tworzenie tabel

-- Tabela konfiguracji aplikacji
CREATE TABLE app_config (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    description TEXT,
    category VARCHAR(50),
    is_sensitive BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela użytkowników
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(128),
    first_name VARCHAR(64),
    last_name VARCHAR(64),
    ad_dn VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    is_admin BOOLEAN DEFAULT FALSE,
    is_global_admin BOOLEAN DEFAULT FALSE,
    login_count INTEGER DEFAULT 0,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela zespołów
CREATE TABLE teams (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id)
);

-- Tabela asocjacyjna użytkownik-zespół
CREATE TABLE user_team (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    role INTEGER DEFAULT 0,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, team_id)
);

-- Tabela asocjacyjna dla udostępniania zasobów między zespołami
CREATE TABLE team_resource_share (
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    resource_team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    resource_type VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    PRIMARY KEY (team_id, resource_team_id, resource_type)
);

-- Tabela kategorii
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'folder',
    color VARCHAR(7) DEFAULT '#6c757d',
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    parent_id INTEGER REFERENCES categories(id),
    owner_team_id INTEGER REFERENCES teams(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela tagów
CREATE TABLE tags (
    id SERIAL PRIMARY KEY,
    name VARCHAR(32) NOT NULL UNIQUE,
    color VARCHAR(7) DEFAULT '#64748b',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela linków
CREATE TABLE links (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    url VARCHAR(500) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'link',
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    category_id INTEGER REFERENCES categories(id),
    creator_id INTEGER REFERENCES users(id),
    owner_team_id INTEGER REFERENCES teams(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela asocjacyjna link-kategoria
CREATE TABLE link_category (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, category_id)
);

-- Tabela asocjacyjna link-tag
CREATE TABLE link_tag (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (link_id, tag_id)
);

-- Tabela asocjacyjna link-team
CREATE TABLE link_team (
    link_id INTEGER REFERENCES links(id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (link_id, team_id)
);

-- Tabela logów aktywności
CREATE TABLE activity_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    severity VARCHAR(20) DEFAULT 'INFO'
);

-- Tabela logów systemowych
CREATE TABLE system_log (
    id SERIAL PRIMARY KEY,
    level VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source VARCHAR(100),
    details TEXT
);

-- Tabele infrastruktury

-- Tabela typów zasobów
CREATE TABLE asset_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'server',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela statusów zasobów
CREATE TABLE asset_statuses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    color VARCHAR(7) DEFAULT '#6c757d',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela lokalizacji
CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    address TEXT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela dostawców
CREATE TABLE vendors (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    website VARCHAR(255),
    contact_info TEXT,
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela zasobów
CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    serial_number VARCHAR(100),
    model VARCHAR(100),
    purchase_date DATE,
    warranty_end DATE,
    notes TEXT,
    type_id INTEGER REFERENCES asset_types(id),
    status_id INTEGER REFERENCES asset_statuses(id),
    location_id INTEGER REFERENCES locations(id),
    vendor_id INTEGER REFERENCES vendors(id),
    owner_team_id INTEGER REFERENCES teams(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id)
);

-- Tabela typów licencji
CREATE TABLE license_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela licencji
CREATE TABLE licenses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    key_info VARCHAR(255),
    software VARCHAR(100),
    purchase_date DATE,
    expiry_date DATE,
    seats INTEGER DEFAULT 1,
    notes TEXT,
    type_id INTEGER REFERENCES license_types(id),
    vendor_id INTEGER REFERENCES vendors(id),
    owner_team_id INTEGER REFERENCES teams(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id)
);

-- Tabela umów serwisowych
CREATE TABLE support_contracts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contract_number VARCHAR(100),
    start_date DATE,
    end_date DATE,
    notes TEXT,
    vendor_id INTEGER REFERENCES vendors(id),
    owner_team_id INTEGER REFERENCES teams(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id)
);

-- Tabela podsieci IP
CREATE TABLE subnets (
    id SERIAL PRIMARY KEY,
    network VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    vlan INTEGER,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela adresów IP
CREATE TABLE ip_addresses (
    id SERIAL PRIMARY KEY,
    address VARCHAR(45) NOT NULL,
    subnet_id INTEGER REFERENCES subnets(id) ON DELETE CASCADE,
    hostname VARCHAR(255),
    status VARCHAR(20) DEFAULT 'free',
    description TEXT,
    mac_address VARCHAR(17),
    dns_ptr VARCHAR(255),
    last_seen TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(address, subnet_id)
);

-- Wypełnianie tabel danymi demonstracyjnymi

-- Konfiguracja aplikacji
INSERT INTO app_config (key, value, description, category) VALUES
('APP_NAME', 'LinkMGT', 'Nazwa aplikacji', 'system'),
('APP_VERSION', '1.0.0', 'Wersja aplikacji', 'system'),
('ITEMS_PER_PAGE', '10', 'Ilość elementów na stronie', 'system'),
('ENABLE_REGISTRATION', 'true', 'Włącz rejestrację użytkowników', 'system'),
('ALLOW_PUBLIC_LINKS', 'true', 'Pozwól na tworzenie publicznych linków', 'system'),
('MAX_LINKS_PER_USER', '1000', 'Maksymalna liczba linków per użytkownik', 'system');

-- Użytkownicy (hasło: password123)
INSERT INTO users (username, email, password_hash, first_name, last_name, is_active, is_admin, is_global_admin) VALUES
('admin', 'admin@example.com', 'pbkdf2:sha256:150000$GcI4pVGj$ec3c959a8c834882a6f2bef4e6ea3a0ce2f9c3538ceee5c1b790e9f1ab08d5f9', 'Admin', 'User', TRUE, TRUE, TRUE),
('moderator', 'moderator@example.com', 'pbkdf2:sha256:150000$GcI4pVGj$ec3c959a8c834882a6f2bef4e6ea3a0ce2f9c3538ceee5c1b790e9f1ab08d5f9', 'Moderator', 'User', TRUE, TRUE, FALSE),
('user1', 'user1@example.com', 'pbkdf2:sha256:150000$GcI4pVGj$ec3c959a8c834882a6f2bef4e6ea3a0ce2f9c3538ceee5c1b790e9f1ab08d5f9', 'John', 'Doe', TRUE, FALSE, FALSE),
('user2', 'user2@example.com', 'pbkdf2:sha256:150000$GcI4pVGj$ec3c959a8c834882a6f2bef4e6ea3a0ce2f9c3538ceee5c1b790e9f1ab08d5f9', 'Jane', 'Smith', TRUE, FALSE, FALSE),
('user3', 'user3@example.com', 'pbkdf2:sha256:150000$GcI4pVGj$ec3c959a8c834882a6f2bef4e6ea3a0ce2f9c3538ceee5c1b790e9f1ab08d5f9', 'Mike', 'Johnson', TRUE, FALSE, FALSE);

-- Zespoły
INSERT INTO teams (name, description, is_active, created_by) VALUES
('IT', 'Zespół IT', TRUE, 1),
('Marketing', 'Zespół marketingowy', TRUE, 1),
('Development', 'Zespół deweloperski', TRUE, 1),
('Management', 'Zespół zarządzający', TRUE, 1),
('Support', 'Zespół wsparcia', TRUE, 1);

-- Przypisanie użytkowników do zespołów
INSERT INTO user_team (user_id, team_id, role) VALUES
(1, 1, 2), -- admin w IT (admin)
(1, 2, 2), -- admin w Marketing (admin)
(1, 3, 2), -- admin w Development (admin)
(1, 4, 2), -- admin w Management (admin)
(1, 5, 2), -- admin w Support (admin)
(2, 1, 1), -- moderator w IT (moderator)
(2, 3, 1), -- moderator w Development (moderator)
(3, 1, 0), -- członek IT (user1)
(3, 3, 0), -- członek Development (user1)
(4, 2, 0), -- członek Marketing (user2)
(4, 4, 0), -- członek Management (user2)
(5, 5, 0); -- członek Support (user3)

-- Udostępnianie zasobów między zespołami
INSERT INTO team_resource_share (team_id, resource_team_id, resource_type, created_by) VALUES
(1, 3, 'links', 1), -- IT udostępnia linki zespołowi Development
(2, 4, 'links', 1), -- Marketing udostępnia linki zespołowi Management
(3, 1, 'links', 1); -- Development udostępnia linki zespołowi IT

-- Kategorie
INSERT INTO categories (name, description, icon, color, sort_order, is_active, owner_team_id) VALUES
('Dokumentacja', 'Dokumentacja techniczna', 'file-alt', '#3498db', 1, TRUE, 1),
('Narzędzia', 'Narzędzia programistyczne', 'tools', '#e74c3c', 2, TRUE, 1),
('Infrastruktura', 'Zasoby infrastruktury', 'server', '#27ae60', 3, TRUE, 1),
('Marketing', 'Materiały marketingowe', 'ad', '#f39c12', 4, TRUE, 2),
('Projekty', 'Projekty w toku', 'project-diagram', '#9b59b6', 5, TRUE, 3),
('Administracja', 'Zasoby administracyjne', 'cogs', '#34495e', 6, TRUE, 4),
('Tutoriale', 'Materiały szkoleniowe', 'graduation-cap', '#16a085', 7, TRUE, 5);

-- Dodajemy podkategorie
INSERT INTO categories (name, description, icon, color, sort_order, is_active, parent_id, owner_team_id) VALUES
('Frontend', 'Dokumentacja frontend', 'code', '#3498db', 1, TRUE, 1, 3),
('Backend', 'Dokumentacja backend', 'database', '#e74c3c', 2, TRUE, 1, 3),
('DevOps', 'Dokumentacja DevOps', 'cloud', '#27ae60', 3, TRUE, 1, 1),
('IDE', 'Środowiska programistyczne', 'laptop-code', '#f39c12', 1, TRUE, 2, 3),
('Debuggery', 'Narzędzia do debugowania', 'bug', '#9b59b6', 2, TRUE, 2, 3),
('Serwery', 'Zasoby serwerowe', 'server', '#34495e', 1, TRUE, 3, 1),
('Sieci', 'Zasoby sieciowe', 'network-wired', '#16a085', 2, TRUE, 3, 1);

-- Tagi
INSERT INTO tags (name, color) VALUES
('python', '#3776ab'),
('java', '#5382a1'),
('javascript', '#f7df1e'),
('css', '#264de4'),
('html', '#e34c26'),
('devops', '#0db7ed'),
('cloud', '#FF9900'),
('security', '#ff5555'),
('ui', '#61dafb'),
('ux', '#FF6B6B'),
('database', '#336791'),
('testing', '#8bc34a'),
('api', '#26C6DA'),
('mobile', '#a4c639'),
('deployment', '#607D8B');

-- Linki
INSERT INTO links (title, url, description, icon, is_public, category_id, creator_id, owner_team_id) VALUES
('Python Documentation', 'https://docs.python.org/', 'Oficjalna dokumentacja języka Python', 'python', TRUE, 2, 1, 1),
('MDN Web Docs', 'https://developer.mozilla.org/', 'Dokumentacja webowa od Mozilla', 'firefox-browser', TRUE, 8, 1, 3),
('Docker Hub', 'https://hub.docker.com/', 'Repozytorium obrazów Docker', 'docker', TRUE, 10, 2, 1),
('GitHub', 'https://github.com/', 'Platforma hostingowa dla projektów', 'github', TRUE, 5, 3, 3),
('Stack Overflow', 'https://stackoverflow.com/', 'Pytania i odpowiedzi dla programistów', 'stack-overflow', TRUE, 2, 3, NULL),
('AWS Console', 'https://aws.amazon.com/', 'Konsola Amazon Web Services', 'aws', FALSE, 3, 1, 1),
('Google Analytics', 'https://analytics.google.com/', 'Analityka stron www', 'chart-line', FALSE, 4, 4, 2),
('Canva', 'https://www.canva.com/', 'Narzędzie do projektowania grafiki', 'palette', TRUE, 4, 4, 2),
('Jira', 'https://www.atlassian.com/software/jira', 'Narzędzie do zarządzania projektami', 'jira', FALSE, 5, 2, 3),
('Confluence', 'https://www.atlassian.com/software/confluence', 'Wiki dla zespołów', 'book', FALSE, 1, 2, 3),
('Visual Studio Code', 'https://code.visualstudio.com/', 'Edytor kodu od Microsoft', 'visual-studio-code', TRUE, 11, 3, 3),
('PostgreSQL Docs', 'https://www.postgresql.org/docs/', 'Dokumentacja bazy danych PostgreSQL', 'database', TRUE, 9, 3, 1),
('Nginx Docs', 'https://nginx.org/en/docs/', 'Dokumentacja serwera Nginx', 'server', FALSE, 13, 1, 1),
('React Documentation', 'https://reactjs.org/docs/getting-started.html', 'Dokumentacja biblioteki React', 'react', TRUE, 8, 3, 3),
('Bootstrap', 'https://getbootstrap.com/', 'Framework CSS', 'bootstrap', TRUE, 8, 4, 2);

-- Przypisanie linków do kategorii
INSERT INTO link_category (link_id, category_id) VALUES
(1, 2), (1, 9), (2, 8), (2, 1), (3, 10), (3, 3),
(4, 5), (5, 2), (5, 7), (6, 3), (6, 13), (7, 4),
(8, 4), (9, 5), (10, 1), (11, 11), (12, 9), (13, 13),
(14, 8), (15, 8);

-- Przypisanie tagów do linków
INSERT INTO link_tag (link_id, tag_id) VALUES
(1, 1), (2, 3), (2, 4), (2, 5), (3, 6), (3, 7),
(4, 6), (5, 1), (5, 2), (5, 3), (6, 7), (7, 10),
(8, 10), (9, 6), (10, 6), (11, 1), (11, 3), (12, 11),
(13, 6), (14, 3), (14, 9), (15, 4), (15, 9);

-- Przypisanie linków do zespołów
INSERT INTO link_team (link_id, team_id) VALUES
(1, 1), (1, 3), (2, 3), (3, 1), (4, 3),
(6, 1), (7, 2), (7, 4), (8, 2), (9, 3),
(10, 3), (11, 3), (12, 1), (12, 3), (13, 1);

-- Logi aktywności
INSERT INTO activity_log (user_id, action, details, ip_address, severity) VALUES
(1, 'login', 'Zalogowanie do systemu', '127.0.0.1', 'INFO'),
(1, 'create_link', 'Utworzenie nowego linku: Python Documentation', '127.0.0.1', 'INFO'),
(2, 'login', 'Zalogowanie do systemu', '192.168.1.10', 'INFO'),
(2, 'create_link', 'Utworzenie nowego linku: Docker Hub', '192.168.1.10', 'INFO'),
(3, 'login', 'Zalogowanie do systemu', '192.168.1.20', 'INFO'),
(3, 'create_link', 'Utworzenie nowego linku: GitHub', '192.168.1.20', 'INFO'),
(4, 'login', 'Zalogowanie do systemu', '192.168.1.30', 'INFO'),
(4, 'create_link', 'Utworzenie nowego linku: Canva', '192.168.1.30', 'INFO'),
(1, 'create_team', 'Utworzenie nowego zespołu: IT', '127.0.0.1', 'INFO'),
(1, 'add_user_to_team', 'Dodanie użytkownika moderator do zespołu IT', '127.0.0.1', 'INFO');

-- Logi systemowe
INSERT INTO system_log (level, message, source, details) VALUES
('INFO', 'System started', 'app', 'Application startup successful'),
('INFO', 'Database migration completed', 'db', 'All migrations applied successfully'),
('WARNING', 'High memory usage detected', 'system', 'Memory usage above 80%'),
('ERROR', 'Database connection error', 'db', 'Connection timeout after 30s'),
('INFO', 'Backup completed', 'system', 'Database backup completed successfully');

-- Typy zasobów
INSERT INTO asset_types (name, description, icon, is_active) VALUES
('Laptop', 'Komputery przenośne', 'laptop', TRUE),
('Desktop', 'Komputery stacjonarne', 'desktop', TRUE),
('Server', 'Serwery', 'server', TRUE),
('Network', 'Sprzęt sieciowy', 'network-wired', TRUE),
('Printer', 'Drukarki', 'print', TRUE),
('Mobile', 'Urządzenia mobilne', 'mobile-alt', TRUE),
('Other', 'Inne urządzenia', 'box', TRUE);

-- Statusy zasobów
INSERT INTO asset_statuses (name, description, color, is_active) VALUES
('In Use', 'Obecnie używany', '#28a745', TRUE),
('Available', 'Dostępny do użycia', '#17a2b8', TRUE),
('Maintenance', 'W naprawie/konserwacji', '#ffc107', TRUE),
('Retired', 'Wycofany z użycia', '#dc3545', TRUE),
('On Order', 'Zamówiony', '#6c757d', TRUE);

-- Lokalizacje
INSERT INTO locations (name, address, description, is_active) VALUES
('Główne biuro', 'ul. Przykładowa 1, 00-001 Warszawa', 'Siedziba główna firmy', TRUE),
('Oddział Kraków', 'ul. Rynek Główny 1, 30-001 Kraków', 'Biuro regionalne', TRUE),
('Oddział Gdańsk', 'ul. Długa 1, 80-001 Gdańsk', 'Biuro regionalne', TRUE),
('Serwerownia', 'ul. Przykładowa 1, 00-001 Warszawa', 'Centrum danych', TRUE),
('Magazyn', 'ul. Magazynowa 10, 00-002 Warszawa', 'Magazyn sprzętu', TRUE);

-- Dostawcy
INSERT INTO vendors (name, website, contact_info, is_active) VALUES
('Dell', 'https://www.dell.com', 'kontakt@dell.pl, tel. 123-456-789', TRUE),
('HP', 'https://www.hp.com', 'kontakt@hp.pl, tel. 987-654-321', TRUE),
('Cisco', 'https://www.cisco.com', 'kontakt@cisco.pl, tel. 111-222-333', TRUE),
('Microsoft', 'https://www.microsoft.com', 'kontakt@microsoft.pl, tel. 444-555-666', TRUE),
('Apple', 'https://www.apple.com', 'kontakt@apple.pl, tel. 777-888-999', TRUE);

-- Zasoby
INSERT INTO assets (name, serial_number, model, purchase_date, warranty_end, notes, type_id, status_id, location_id, vendor_id, owner_team_id, created_by) VALUES
('Laptop Dev-001', 'SN001122', 'Dell XPS 15', '2023-01-15', '2026-01-15', 'Przypisany do Jana Kowalskiego', 1, 1, 1, 1, 3, 1),
('Laptop Dev-002', 'SN001123', 'Dell XPS 15', '2023-01-15', '2026-01-15', 'Przypisany do Anny Nowak', 1, 1, 1, 1, 3, 1),
('Laptop IT-001', 'SN002233', 'HP EliteBook', '2022-06-10', '2025-06-10', 'Przypisany do administratora sieci', 1, 1, 1, 2, 1, 1),
('Desktop MKT-001', 'SN003344', 'Dell Precision', '2022-03-20', '2025-03-20', 'Stacja graficzna', 2, 1, 2, 1, 2, 1),
('Server-DB-001', 'SN004455', 'Dell PowerEdge', '2021-11-05', '2024-11-05', 'Serwer bazy danych', 3, 1, 4, 1, 1, 1),
('Server-Web-001', 'SN004456', 'Dell PowerEdge', '2021-11-05', '2024-11-05', 'Serwer WWW', 3, 1, 4, 1, 1, 1),
('Switch-Core-001', 'SN005566', 'Cisco Catalyst', '2022-02-18', '2027-02-18', 'Switch centralny', 4, 1, 4, 3, 1, 1),
('Printer-HR-001', 'SN006677', 'HP LaserJet', '2022-09-12', '2025-09-12', 'Drukarka działu HR', 5, 1, 1, 2, 4, 1),
('iPhone-CEO', 'SN007788', 'iPhone 14 Pro', '2023-03-01', '2025-03-01', 'Telefon prezesa', 6, 1, 1, 5, 4, 1),
('Laptop-Spare-001', 'SN008899', 'HP ProBook', '2022-07-22', '2025-07-22', 'Zapasowy laptop', 1, 2, 5, 2, 1, 1);

-- Typy licencji
INSERT INTO license_types (name, description, is_active) VALUES
('Perpetual', 'Licencja bezterminowa', TRUE),
('Subscription', 'Licencja abonamentowa', TRUE),
('OEM', 'Licencja OEM', TRUE),
('Volume', 'Licencja woluminowa', TRUE),
('Open Source', 'Licencja open source', TRUE);

-- Licencje
INSERT INTO licenses (name, key_info, software, purchase_date, expiry_date, seats, notes, type_id, vendor_id, owner_team_id, created_by) VALUES
('Microsoft 365', 'XXXX-XXXX-XXXX-XXXX', 'Microsoft 365', '2023-01-01', '2024-01-01', 50, 'Licencja dla całej firmy', 2, 4, 1, 1),
('Windows Server 2022', 'XXXX-XXXX-XXXX-XXXX', 'Windows Server', '2022-06-15', NULL, 5, 'Licencje serwerowe', 1, 4, 1, 1),
('Adobe Creative Cloud', 'XXXX-XXXX-XXXX-XXXX', 'Adobe CC', '2023-02-10', '2024-02-10', 10, 'Dla zespołu marketingu', 2, 5, 2, 1),
('JetBrains All Products', 'XXXX-XXXX-XXXX-XXXX', 'JetBrains', '2023-03-15', '2024-03-15', 15, 'Dla zespołu developerów', 2, 3, 3, 1),
('VMware vSphere', 'XXXX-XXXX-XXXX-XXXX', 'VMware', '2022-04-20', '2025-04-20', 2, 'Licencje na serwery wirtualizacyjne', 2, 3, 1, 1);

-- Umowy serwisowe
INSERT INTO support_contracts (name, contract_number, start_date, end_date, notes, vendor_id, owner_team_id, created_by) VALUES
('Dell ProSupport', 'DELL-PS-001', '2023-01-15', '2026-01-15', 'Wsparcie dla serwerów i laptopów Dell', 1, 1, 1),
('Cisco SmartNet', 'CISCO-SN-001', '2022-02-18', '2027-02-18', 'Wsparcie dla urządzeń sieciowych Cisco', 3, 1, 1),
('HP Care Pack', 'HP-CP-001', '2022-09-12', '2025-09-12', 'Wsparcie dla drukarek i laptopów HP', 2, 1, 1),
('Microsoft Premier', 'MS-PR-001', '2023-01-01', '2024-01-01', 'Wsparcie premium dla produktów Microsoft', 4, 1, 1),
('VMware Production', 'VM-PS-001', '2022-04-20', '2025-04-20', 'Wsparcie dla środowiska wirtualizacyjnego', 3, 1, 1);

-- Podsieci IP
INSERT INTO subnets (network, description, vlan, notes) VALUES
('192.168.1.0/24', 'Sieć biurowa', 10, 'Główna sieć LAN'),
('192.168.2.0/24', 'Sieć serwerowa', 20, 'Sieć dla serwerów'),
('192.168.3.0/24', 'Sieć DMZ', 30, 'Strefa DMZ'),
('10.0.0.0/24', 'Sieć VPN', 100, 'Sieć dla połączeń VPN'),
('172.16.0.0/24', 'Sieć zarządzania', 200, 'Sieć dla zarządzania urządzeniami');

-- Adresy IP
INSERT INTO ip_addresses (address, subnet_id, hostname, status, description, mac_address, last_seen) VALUES
('192.168.1.1', 1, 'gateway.local', 'used', 'Brama sieciowa', '00:11:22:33:44:55', CURRENT_TIMESTAMP),
('192.168.1.10', 1, 'desktop-it001.local', 'used', 'Komputer IT', '00:11:22:33:44:56', CURRENT_TIMESTAMP),
('192.168.1.11', 1, 'laptop-dev001.local', 'used', 'Laptop Dev', '00:11:22:33:44:57', CURRENT_TIMESTAMP),
('192.168.1.12', 1, 'laptop-dev002.local', 'used', 'Laptop Dev', '00:11:22:33:44:58', CURRENT_TIMESTAMP),
('192.168.1.100', 1, NULL, 'free', 'Wolny adres', NULL, NULL),
('192.168.2.1', 2, 'srv-gateway.local', 'used', 'Brama sieciowa serwerów', '00:11:22:33:44:59', CURRENT_TIMESTAMP),
('192.168.2.10', 2, 'srv-db001.local', 'used', 'Serwer bazy danych', '00:11:22:33:44:5A', CURRENT_TIMESTAMP),
('192.168.2.11', 2, 'srv-web001.local', 'used', 'Serwer WWW', '00:11:22:33:44:5B', CURRENT_TIMESTAMP),
('192.168.2.100', 2, NULL, 'reserved', 'Zarezerwowany do przyszłego użycia', NULL, NULL),
('192.168.3.1', 3, 'dmz-gateway.local', 'used', 'Brama DMZ', '00:11:22:33:44:5C', CURRENT_TIMESTAMP),
('192.168.3.10', 3, 'dmz-web.local', 'used', 'Serwer WWW w DMZ', '00:11:22:33:44:5D', CURRENT_TIMESTAMP),
('10.0.0.1', 4, 'vpn-gateway.local', 'used', 'Serwer VPN', '00:11:22:33:44:5E', CURRENT_TIMESTAMP),
('172.16.0.1', 5, 'mgmt-gateway.local', 'used', 'Brama zarządzająca', '00:11:22:33:44:5F', CURRENT_TIMESTAMP),
('172.16.0.10', 5, 'mgmt-switch.local', 'used', 'Switch zarządzalny', '00:11:22:33:44:60', CURRENT_TIMESTAMP);

COMMIT;

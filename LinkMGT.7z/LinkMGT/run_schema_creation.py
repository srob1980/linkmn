import os
import sys
import psycopg2
from psycopg2 import sql

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def create_database_schema():
    """Uruchom kompletny skrypt tworzenia schematu bazy danych"""
    
    # Parametry połączenia - dostosuj do swojego środowiska
    db_params = {
        'host': 'localhost',
        'port': '5432',
        'database': 'postgres',  # Połącz się z domyślną bazą
        'user': 'postgres',
        'password': 'postgres'
    }
    
    target_database = 'linkmgt'
    
    try:
        print("🔗 Łączenie z PostgreSQL...")
        
        # Połącz się z domyślną bazą danych
        conn = psycopg2.connect(**db_params)
        conn.autocommit = True
        cur = conn.cursor()
        
        # Sprawdź czy baza danych istnieje
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (target_database,))
        exists = cur.fetchone()
        
        if exists:
            print(f"⚠️  Baza danych '{target_database}' już istnieje.")
            response = input("Czy chcesz ją usunąć i utworzyć ponownie? (y/N): ")
            if response.lower() in ['y', 'yes', 'tak', 't']:
                print(f"🗑️  Usuwanie bazy danych '{target_database}'...")
                cur.execute(sql.SQL("DROP DATABASE {}").format(sql.Identifier(target_database)))
            else:
                print("❌ Operacja anulowana.")
                return False
        
        # Utwórz nową bazę danych
        print(f"🏗️  Tworzenie bazy danych '{target_database}'...")
        cur.execute(sql.SQL("CREATE DATABASE {} OWNER postgres ENCODING 'UTF8'").format(sql.Identifier(target_database)))
        
        cur.close()
        conn.close()
        
        # Połącz się z nową bazą danych
        db_params['database'] = target_database
        conn = psycopg2.connect(**db_params)
        cur = conn.cursor()
        
        # Wczytaj i wykonaj skrypt SQL
        schema_file = os.path.join(project_path, 'database', 'postgresql', 'complete_schema.sql')
        
        if not os.path.exists(schema_file):
            print(f"❌ Nie znaleziono pliku schematu: {schema_file}")
            return False
        
        print("📄 Wczytywanie schematu z pliku...")
        with open(schema_file, 'r', encoding='utf-8') as f:
            schema_sql = f.read()
        
        print("⚙️  Wykonywanie schematu bazy danych...")
        cur.execute(schema_sql)
        
        conn.commit()
        cur.close()
        conn.close()
        
        print("✅ Schema bazy danych została pomyślnie utworzona!")
        print(f"\n📊 Baza danych '{target_database}' jest gotowa do użycia.")
        print("\n🔑 Domyślne konta:")
        print("   - admin / admin123 (zmień hasło!)")
        print("   - demo / demo123")
        print("\n⚠️  WAŻNE: Zaktualizuj hasła domyślnych użytkowników przed użyciem!")
        
        return True
        
    except psycopg2.Error as e:
        print(f"❌ Błąd PostgreSQL: {e}")
        return False
    except Exception as e:
        print(f"❌ Błąd: {e}")
        return False

if __name__ == '__main__':
    print("🚀 LinkMGT - Tworzenie schematu bazy danych PostgreSQL")
    print("=" * 55)
    
    success = create_database_schema()
    
    if success:
        print("\n🎉 Schemat bazy danych został pomyślnie utworzony!")
        print("Możesz teraz uruchomić aplikację: python run.py")
    else:
        print("\n💥 Tworzenie schematu nie powiodło się.")
        sys.exit(1)

import os
import sys
from datetime import datetime

# Add project path to Python path
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def add_ad_last_updated_to_users():
    """Add ad_last_updated column to users table"""
    from app import create_app, db
    from sqlalchemy import Column, DateTime, text
    
    app = create_app()
    
    with app.app_context():
        # Check if column already exists
        exists_query = text("""
            SELECT column_name FROM information_schema.columns 
            WHERE table_name = 'users' AND column_name = 'ad_last_updated'
        """)
        
        result = db.session.execute(exists_query).fetchone()
        
        if result:
            print("Column 'ad_last_updated' already exists in 'users' table.")
            return
        
        # Add the column
        add_column_query = text("""
            ALTER TABLE users ADD COLUMN ad_last_updated TIMESTAMP WITHOUT TIME ZONE
        """)
        
        db.session.execute(add_column_query)
        db.session.commit()
        
        print("Successfully added 'ad_last_updated' column to 'users' table.")

if __name__ == "__main__":
    add_ad_last_updated_to_users()

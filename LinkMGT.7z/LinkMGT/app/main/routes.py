from flask import render_template, redirect, url_for, flash, request, jsonify, current_app
from flask_login import login_required, current_user
from app import db
from app.main import bp
from datetime import datetime, date, timedelta
from app.models.infrastructure import Asset, License, SupportContract
from app.models.ip_management import IPAddress
from app.models.user import User
from sqlalchemy import inspect, text
from app.models import Link, Category # Category import is already here
from sqlalchemy.orm import joinedload # Import joinedload

@bp.route('/')
@login_required
def index():
    """Dashboard page"""
    try:
        today = date.today()
        thirty_days = today + timedelta(days=30)
        fifteen_mins_ago = datetime.utcnow() - timedelta(minutes=15)

        # Update current user's last seen time
        if current_user.is_authenticated:
            current_user.last_seen = datetime.utcnow()
            db.session.commit()

        # Create inspector to check if tables exist
        inspector = inspect(db.engine)

        # Get quick stats with proper table existence checking
        stats = {
            'assets': Asset.query.count() if 'assets' in inspector.get_table_names() else 0,
            'licenses': License.query.count() if 'licenses' in inspector.get_table_names() else 0,
            'contracts': SupportContract.query.count() if 'support_contracts' in inspector.get_table_names() else 0,
            'network': IPAddress.query.count() if 'ip_addresses' in inspector.get_table_names() else 0
        }

        # Get expiring items with table existence checking
        expiring = {
            'warranties': Asset.query.filter(
                Asset.warranty_end.isnot(None),
                Asset.warranty_end <= thirty_days,
                Asset.warranty_end >= today
            ).order_by(Asset.warranty_end).limit(5).all() if 'assets' in inspector.get_table_names() else [],

            'licenses': License.query.filter(
                License.expiry_date.isnot(None),
                License.expiry_date <= thirty_days,
                License.expiry_date >= today
            ).order_by(License.expiry_date).limit(5).all() if 'licenses' in inspector.get_table_names() else [],

            'contracts': SupportContract.query.filter(
                SupportContract.end_date <= thirty_days,
                SupportContract.end_date >= today
            ).order_by(SupportContract.end_date).limit(5).all() if 'support_contracts' in inspector.get_table_names() else []
        }

        # Populate categories with Link data
        categories = {}
        if 'links' in inspector.get_table_names() and 'categories' in inspector.get_table_names():
            try:
                # Sprawdź jakie kolumny istnieją w tabeli links
                links_columns = [c['name'] for c in inspector.get_columns('links')]
                current_app.logger.info(f"Available links columns: {links_columns}")
                
                # Sprawdź jakie kolumny istnieją w tabeli categories  
                categories_columns = [c['name'] for c in inspector.get_columns('categories')]
                current_app.logger.info(f"Available categories columns: {categories_columns}")
                
                # Sprawdź czy tabela link_category istnieje
                has_link_category = 'link_category' in inspector.get_table_names()
                current_app.logger.info(f"Has link_category table: {has_link_category}")
                
                # Pobierz wszystkie kategorie z relacjami do linków
                all_categories = Category.query.filter_by(is_active=True).order_by(Category.sort_order, Category.name).all()
                
                for category in all_categories:
                    # Pobierz linki dla tej kategorii (maksymalnie 10)
                    category_links = []
                    
                    try:
                        # Jeśli istnieje tabela łącząca, użyj join
                        if has_link_category:
                            # Użyj raw SQL dla bezpiecznego dostępu
                            query = text("""
                                SELECT l.id, l.title, l.url, l.description, 
                                       CASE WHEN :has_icon THEN l.icon ELSE 'link' END as icon
                                FROM links l
                                INNER JOIN link_category lc ON l.id = lc.link_id
                                WHERE lc.category_id = :category_id 
                                AND l.is_public = true 
                                AND l.is_active = true
                                LIMIT 10
                            """)
                            
                            result = db.session.execute(query, {
                                'category_id': category.id,
                                'has_icon': 'icon' in links_columns
                            })
                            
                            for row in result:
                                link_data = {
                                    'id': row.id,
                                    'name': row.title or 'Unnamed Link',
                                    'url': row.url or '#',
                                    'icon': row.icon or 'link'
                                }
                                category_links.append(link_data)
                        else:
                            # Fallback do relacji bezpośredniej przez foreign key
                            if hasattr(category, 'links'):
                                links = category.links.filter_by(is_public=True, is_active=True).limit(10).all()
                            else:
                                links = Link.query.filter_by(category_id=category.id, is_public=True, is_active=True).limit(10).all()
                            
                            for link in links:
                                # Bezpieczne pobieranie atrybutów linku z sprawdzeniem kolumn
                                link_name = getattr(link, 'title', None) or getattr(link, 'name', None) or 'Unnamed Link'
                                link_url = getattr(link, 'url', '#')
                                
                                # Sprawdź czy kolumna icon istnieje w tabeli
                                if 'icon' in links_columns:
                                    link_icon = getattr(link, 'icon', 'link')
                                else:
                                    link_icon = 'link'  # domyślna ikona
                                
                                link_data = {
                                    'id': link.id,
                                    'name': link_name,
                                    'url': link_url,
                                    'icon': link_icon
                                }
                                category_links.append(link_data)
                    
                    except Exception as link_error:
                        current_app.logger.error(f"Error processing links for category {category.name}: {str(link_error)}")
                        # Rollback w przypadku błędu
                        db.session.rollback()
                        continue
                    
                    # Dodaj kategorię tylko jeśli ma linki lub chcemy pokazać puste kategorie
                    if category_links:  # lub zawsze: if True
                        # Bezpieczne pobieranie atrybutów kategorii
                        category_icon = 'folder'
                        category_color = '#6c757d'
                        
                        if 'icon' in categories_columns:
                            category_icon = getattr(category, 'icon', 'folder')
                        if 'color' in categories_columns:
                            category_color = getattr(category, 'color', '#6c757d')
                            
                        categories[category.name] = {
                            'id': category.id,
                            'name': category.name,
                            'icon': category_icon,
                            'color': category_color,
                            'links': category_links
                        }
                
                # Jeśli nie ma kategorii lub linków, spróbuj pobrać linki bez kategorii
                if not categories:
                    current_app.logger.info("No categories found, trying to get links without categories")
                    try:
                        # Użyj raw SQL dla bezpiecznego dostępu
                        query = text("""
                            SELECT l.id, l.title, l.url, l.description,
                                   CASE WHEN :has_icon THEN l.icon ELSE 'link' END as icon
                            FROM links l
                            WHERE l.is_public = true AND l.is_active = true
                            LIMIT 10
                        """)
                        
                        result = db.session.execute(query, {
                            'has_icon': 'icon' in links_columns
                        })
                        
                        uncategorized_links = []
                        for row in result:
                            link_data = {
                                'id': row.id,
                                'name': row.title or 'Unnamed Link',
                                'url': row.url or '#',
                                'icon': row.icon or 'link'
                            }
                            uncategorized_links.append(link_data)
                        
                        if uncategorized_links:
                            categories['Bez kategorii'] = {
                                'id': 0,
                                'name': 'Bez kategorii',
                                'icon': 'question-circle',
                                'color': '#6c757d',
                                'links': uncategorized_links
                            }
                    except Exception as uncategorized_error:
                        current_app.logger.error(f"Error processing uncategorized links: {str(uncategorized_error)}")
                        db.session.rollback()
                        
                current_app.logger.info(f"Prepared categories data: {list(categories.keys())}")
                
            except Exception as e:
                current_app.logger.error(f"Error preparing categories data: {str(e)}")
                # Rollback transakcji w przypadku błędu
                db.session.rollback()
                categories = {}
        else:
            current_app.logger.info("Links or categories table not found")
        
        # Fetch active users with error handling
        active_users = []
        if 'users' in inspector.get_table_names():
            try:
                active_users = User.query.filter(User.last_seen > fifteen_mins_ago).order_by(User.last_seen.desc()).limit(5).all()
            except Exception as user_error:
                current_app.logger.error(f"Error fetching active users: {str(user_error)}")
                db.session.rollback()
                active_users = []
        
        # Fetch recent IP changes with error handling
        recent_ips = []
        if 'ip_addresses' in inspector.get_table_names():
            try:
                if hasattr(IPAddress, 'updated_at'):
                    recent_ips = IPAddress.query.order_by(IPAddress.updated_at.desc()).limit(5).all()
                elif hasattr(IPAddress, 'last_seen'):
                     recent_ips = IPAddress.query.order_by(IPAddress.last_seen.desc()).limit(5).all()
                else:
                    recent_ips = IPAddress.query.limit(5).all()
            except Exception as ip_error:
                current_app.logger.error(f"Error fetching recent IPs: {str(ip_error)}")
                db.session.rollback()
                recent_ips = []

        return render_template('main/index.html',
                          title='Dashboard',
                          stats=stats,
                          categories=categories,
                          expiring=expiring,
                          recent_ips=recent_ips,
                          active_users=active_users,
                          today=today)

    except Exception as e:
        current_app.logger.error(f"Dashboard error: {str(e)}")
        # Rollback transakcji w przypadku głównego błędu
        try:
            db.session.rollback()
        except:
            pass
        flash('Wystąpił błąd podczas ładowania danych', 'danger')
        
        # Zwróć pustą stronę dashboard z minimalnymi danymi
        return render_template('main/index.html',
                          title='Dashboard',
                          stats={'assets': 0, 'licenses': 0, 'contracts': 0, 'network': 0},
                          categories={},
                          expiring={'warranties': [], 'licenses': [], 'contracts': []},
                          recent_ips=[],
                          active_users=[],
                          today=date.today())

@bp.route('/home')
def home():
    """Redirect to index"""
    return redirect(url_for('main.index'))

from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length, Optional, ValidationError
from app.models import Category

class CategoryForm(FlaskForm):
    """Formularz do tworzenia i edycji kategorii"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=500)])
    icon = StringField('Ikona (Font Awesome)', validators=[Optional(), Length(max=50)], default='folder')
    color = StringField('Kolor (HEX)', validators=[Optional(), Length(max=7)], default='#6c757d')
    sort_order = IntegerField('Kolejność sortowania', default=0)
    parent_id = SelectField('Kategoria nadrzędna', choices=[], default='0')
    is_active = BooleanField('Aktywna', default=True)
    owner_team_id = SelectField('Właściciel (zespół)', choices=[], default='0', validators=[Optional()])
    submit = SubmitField('Zapisz')
    
    def validate_name(self, field):
        # Sprawdź unikalność nazwy kategorii
        category = Category.query.filter(Category.name == field.data).first()
        if category and (not hasattr(self, 'category') or category.id != self.category.id):
            raise ValidationError('Kategoria o takiej nazwie już istnieje.')
    
    def validate_color(self, field):
        # Sprawdź poprawność formatu koloru HEX
        if field.data and not field.data.startswith('#'):
            field.data = '#' + field.data
        
        # Sprawdź, czy jest to poprawny kolor HEX
        import re
        if not re.match(r'^#(?:[0-9a-fA-F]{3}){1,2}$', field.data):
            raise ValidationError('Nieprawidłowy format koloru HEX. Użyj formatu #RGB lub #RRGGBB.')

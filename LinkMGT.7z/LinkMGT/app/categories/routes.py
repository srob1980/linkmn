from flask import render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from app import db
from app.categories import bp
from app.models import Category, Team
from app.categories.forms import CategoryForm
from sqlalchemy import func

@bp.route('/')
@login_required
def index():
    """Wyświetl listę wszystkich kategorii"""
    # Pobierz parametry sortowania
    sort = request.args.get('sort', 'sort_order')
    order = request.args.get('order', 'asc')
    
    # Podstawowe zapytanie
    query = Category.query
    
    # Zastosuj sortowanie
    if sort == 'name':
        query = query.order_by(Category.name.asc() if order == 'asc' else Category.name.desc())
    elif sort == 'sort_order':
        query = query.order_by(Category.sort_order.asc() if order == 'asc' else Category.sort_order.desc())
    else:
        query = query.order_by(Category.sort_order.asc(), Category.name.asc())
    
    # Wykonaj zapytanie
    categories = query.all()
    
    # Pobierz liczbę linków w każdej kategorii
    from app.models import Link, link_category
    category_counts = {}
    
    # Sprawdź, czy istnieje kolumna category_id w tabeli links
    inspector = db.inspect(db.engine)
    links_columns = [c['name'] for c in inspector.get_columns('links')]
    has_category_id = 'category_id' in links_columns
    
    if has_category_id:
        # Jeśli istnieje bezpośrednia relacja
        for category in categories:
            count = Link.query.filter_by(category_id=category.id).count()
            category_counts[category.id] = count
    else:
        # Jeśli istnieje tylko relacja many-to-many
        for category in categories:
            count = db.session.query(func.count(link_category.c.link_id)).\
                    filter(link_category.c.category_id == category.id).scalar()
            category_counts[category.id] = count or 0
    
    return render_template('categories/index.html',
                          title='Kategorie',
                          categories=categories,
                          category_counts=category_counts,
                          sort=sort,
                          order=order)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Utwórz nową kategorię"""
    form = CategoryForm()
    
    # Pobierz zespoły dostępne dla użytkownika
    user_teams = []
    for team in current_user.teams:
        if team.can_user_manage_resources(current_user.id):
            user_teams.append((str(team.id), team.name))
    
    # Dodaj opcję "Brak zespołu" (prywatna kategoria)
    form.owner_team_id.choices = [('0', 'Prywatna (tylko ja)')] + user_teams
    
    # Pobierz kategorie nadrzędne
    form.parent_id.choices = [('0', 'Brak (kategoria główna)')] + [
        (str(c.id), c.name) for c in Category.query.filter(Category.parent_id.is_(None)).order_by(Category.name).all()
    ]
    
    if form.validate_on_submit():
        category = Category(
            name=form.name.data,
            description=form.description.data,
            icon=form.icon.data,
            color=form.color.data,
            sort_order=form.sort_order.data,
            is_active=form.is_active.data
        )
        
        # Obsługa relacji parent_id
        if form.parent_id.data and form.parent_id.data != '0':
            category.parent_id = int(form.parent_id.data)
        
        # Obsługa owner_team_id
        if form.owner_team_id.data and form.owner_team_id.data != '0':
            category.owner_team_id = int(form.owner_team_id.data)
        else:
            category.owner_team_id = None
        
        db.session.add(category)
        db.session.commit()
        
        flash(f'Kategoria "{category.name}" została utworzona.', 'success')
        return redirect(url_for('categories.index'))
    
    # Pobierz wszystkie kategorie do listy rozwijanej
    parent_categories = Category.query.filter(Category.parent_id.is_(None)).order_by(Category.name).all()
    
    return render_template('categories/form.html',
                          title='Nowa kategoria',
                          form=form,
                          parent_categories=parent_categories,
                          user_teams=user_teams)

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    """Edytuj istniejącą kategorię"""
    category = Category.query.get_or_404(id)
    
    # Sprawdź uprawnienia
    if category.owner_team_id:
        team = Team.query.get(category.owner_team_id)
        if team and not team.can_user_manage_resources(current_user.id) and not current_user.is_admin and not current_user.is_global_admin:
            flash('Nie masz uprawnień do edycji tej kategorii.', 'danger')
            return redirect(url_for('categories.index'))
    
    form = CategoryForm(obj=category)
    
    # Pobierz zespoły dostępne dla użytkownika
    user_teams = []
    for team in current_user.teams:
        if team.can_user_manage_resources(current_user.id):
            user_teams.append((str(team.id), team.name))
    
    # Dodaj opcję "Brak zespołu" (prywatna kategoria)
    form.owner_team_id.choices = [('0', 'Prywatna (tylko ja)')] + user_teams
    
    if request.method == 'GET':
        # Na początku ustaw prawidłowe wartości w formularzu
        if category.parent_id:
            form.parent_id.data = str(category.parent_id)
        else:
            form.parent_id.data = '0'  # "Brak rodzica"
            
        if category.owner_team_id:
            form.owner_team_id.data = str(category.owner_team_id)
        else:
            form.owner_team_id.data = '0'  # "Prywatna"
    
    if form.validate_on_submit():
        # Sprawdź czy kategoria nie będzie rodzicem samej siebie
        if form.parent_id.data and int(form.parent_id.data) == id:
            flash('Kategoria nie może być rodzicem samej siebie.', 'danger')
            return redirect(url_for('categories.edit', id=id))
        
        category.name = form.name.data
        category.description = form.description.data
        category.icon = form.icon.data
        category.color = form.color.data
        category.sort_order = form.sort_order.data
        category.is_active = form.is_active.data
        
        # Obsługa relacji parent_id
        if form.parent_id.data and form.parent_id.data != '0':
            category.parent_id = int(form.parent_id.data)
        else:
            category.parent_id = None
            
        # Obsługa owner_team_id
        if form.owner_team_id.data and form.owner_team_id.data != '0':
            category.owner_team_id = int(form.owner_team_id.data)
        else:
            category.owner_team_id = None
            
        db.session.commit()
        
        flash(f'Kategoria "{category.name}" została zaktualizowana.', 'success')
        return redirect(url_for('categories.index'))
    
    # Pobierz wszystkie kategorie do listy rozwijanej (oprócz edytowanej i jej dzieci)
    def get_child_ids(category_id):
        children = Category.query.filter_by(parent_id=category_id).all()
        child_ids = [child.id for child in children]
        for child_id in child_ids.copy():
            child_ids.extend(get_child_ids(child_id))
        return child_ids
    
    excluded_ids = [id] + get_child_ids(id)
    parent_categories = Category.query.filter(~Category.id.in_(excluded_ids)).order_by(Category.name).all()
    
    # Ustaw opcje dla listy rozwijanej parent_id
    form.parent_id.choices = [('0', 'Brak (kategoria główna)')] + [
        (str(c.id), c.name) for c in parent_categories
    ]
    
    return render_template('categories/form.html',
                          title=f'Edytuj kategorię: {category.name}',
                          form=form,
                          category=category,
                          parent_categories=parent_categories,
                          user_teams=user_teams)

@bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    """Usuń kategorię"""
    category = Category.query.get_or_404(id)
    
    # Sprawdź czy kategoria ma dzieci
    children = Category.query.filter_by(parent_id=id).all()
    if children:
        flash('Nie można usunąć kategorii, która ma podkategorie.', 'danger')
        return redirect(url_for('categories.index'))
    
    # Sprawdź czy kategoria ma przypisane linki
    from app.models import link_category
    
    # Sprawdź, czy istnieje kolumna category_id w tabeli links
    inspector = db.inspect(db.engine)
    links_columns = [c['name'] for c in inspector.get_columns('links')]
    has_category_id = 'category_id' in links_columns
    
    has_links = False
    if has_category_id:
        from app.models import Link
        links_count = Link.query.filter_by(category_id=id).count()
        has_links = links_count > 0
    else:
        # Sprawdź relację many-to-many
        links_count = db.session.query(func.count(link_category.c.link_id)).\
                    filter(link_category.c.category_id == id).scalar()
        has_links = links_count > 0
    
    if has_links:
        flash('Nie można usunąć kategorii, która ma przypisane linki.', 'danger')
        return redirect(url_for('categories.index'))
    
    name = category.name  # Zapisujemy nazwę przed usunięciem
    db.session.delete(category)
    db.session.commit()
    
    flash(f'Kategoria "{name}" została usunięta.', 'success')
    return redirect(url_for('categories.index'))

@bp.route('/icons')
@login_required
def icons():
    """Wyświetl dostępne ikony Font Awesome"""
    icons = [
        'folder', 'folder-open', 'link', 'external-link', 'globe', 'cog', 'cogs',
        'wrench', 'tools', 'server', 'database', 'cloud', 'desktop', 'laptop',
        'mobile', 'tablet', 'phone', 'envelope', 'user', 'users', 'file',
        'file-text', 'file-pdf', 'file-word', 'file-excel', 'file-image',
        'file-video', 'file-audio', 'file-code', 'file-archive', 'code', 'terminal',
        'git', 'github', 'gitlab', 'bitbucket', 'jira', 'trello', 'slack',
        'chart-bar', 'chart-line', 'chart-pie', 'chart-area', 'dashboard',
        'clipboard', 'clipboard-list', 'clipboard-check', 'book', 'bookmark',
        'calendar', 'clock', 'bell', 'lock', 'unlock', 'key', 'shield',
        'shield-alt', 'bug', 'home', 'briefcase', 'building', 'industry',
        'store', 'shopping-cart', 'credit-card', 'money-bill', 'wallet',
        'map', 'map-marker', 'map-marker-alt', 'compass', 'location-arrow',
        'camera', 'image', 'video', 'play', 'music', 'headphones', 'microphone',
        'heart', 'star', 'thumbs-up', 'thumbs-down', 'comment', 'comments',
        'envelope-open', 'paper-plane', 'share', 'share-alt', 'wifi',
        'signal', 'bluetooth', 'network-wired'
    ]
    
    return render_template('categories/icons.html',
                          title='Ikony Font Awesome',
                          icons=icons)

from flask import render_template, redirect, url_for, flash, request, current_app, jsonify
from flask_login import login_required, current_user
from app import db
from app.teams import bp
from app.teams.forms import TeamForm, MemberForm
from app.models.team import Team
from app.models import User, user_team
from app.auth.decorators import admin_required
from sqlalchemy import or_

from app.models.team import ROLE_MEMBER, ROLE_MODERATOR, ROLE_ADMIN

@bp.route('/')
@login_required
def index():
    """View all teams"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('ITEMS_PER_PAGE', 10)
    
    # Get query filters
    search = request.args.get('search', '')
    
    # Base query
    query = Team.query
    
    # Apply filters
    if search:
        query = query.filter(Team.name.ilike(f'%{search}%'))
    
    # Get paginated results
    teams = query.order_by(Team.name).paginate(page=page, per_page=per_page)
    
    return render_template('teams/index.html',
                          title='Zespoły',
                          teams=teams,
                          search=search)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create():
    """Create a new team"""
    form = TeamForm()
    
    if form.validate_on_submit():
        team = Team(
            name=form.name.data,
            description=form.description.data,
            is_active=form.is_active.data
        )
        
        try:
            db.session.add(team)
            db.session.commit()
            flash(f'Zespół "{team.name}" został utworzony pomyślnie.', 'success')
            return redirect(url_for('teams.index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas tworzenia zespołu: {str(e)}', 'danger')
    
    return render_template('teams/form.html',
                          title='Nowy zespół',
                          form=form)

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit(id):
    """Edit an existing team"""
    team = Team.query.get_or_404(id)
    form = TeamForm(obj=team)
    
    if form.validate_on_submit():
        team.name = form.name.data
        team.description = form.description.data
        team.is_active = form.is_active.data
        
        try:
            db.session.commit()
            flash(f'Zespół "{team.name}" został zaktualizowany pomyślnie.', 'success')
            return redirect(url_for('teams.index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas aktualizacji zespołu: {str(e)}', 'danger')
    
    return render_template('teams/form.html',
                          title=f'Edytuj zespół: {team.name}',
                          form=form,
                          team=team)

@bp.route('/<int:id>/delete', methods=['POST'])
@login_required
@admin_required
def delete(id):
    """Delete a team"""
    team = Team.query.get_or_404(id)
    
    try:
        name = team.name
        db.session.delete(team)
        db.session.commit()
        flash(f'Zespół "{name}" został usunięty.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Wystąpił błąd podczas usuwania zespołu: {str(e)}', 'danger')
    
    return redirect(url_for('teams.index'))

@bp.route('/<int:id>/members')
@login_required
def members(id):
    """View team members"""
    team = Team.query.get_or_404(id)
    
    # Get all users not in team
    users = User.query.filter(
        ~User.teams.any(Team.id == id)
    ).all()
    
    # Get users in the team with their roles
    members = db.session.query(User, user_team.c.role).join(user_team).filter(user_team.c.team_id == id).all()
    
    # Check user permissions
    can_manage = team.can_user_manage_members(current_user.id)
    
    form = MemberForm()
    
    # Handle member invite
    if form.validate_on_submit():
        email = form.email.data.strip()
        role = form.role.data
        
        # Find user by email
        user = User.query.filter_by(email=email).first()
        
        if user:
            # User exists, add to team
            try:
                stmt = user_team.insert().values(user_id=user.id, team_id=id, role=role)
                db.session.execute(stmt)
                db.session.commit()
                flash(f'Użytkownik {user.username} został dodany do zespołu.', 'success')
            except Exception as e:
                db.session.rollback()
                flash(f'Wystąpił błąd podczas dodawania użytkownika do zespołu: {str(e)}', 'danger')
        else:
            # User does not exist, handle accordingly (e.g., send invite)
            flash(f'Użytkownik z adresem email {email} nie istnieje.', 'warning')
        
        return redirect(url_for('teams.members', id=id))
    
    return render_template('teams/members.html',
                          title=f'Członkowie zespołu: {team.name}',
                          team=team,
                          members=members,
                          users=users,
                          can_manage=can_manage,
                          form=form,
                          ROLE_MEMBER=ROLE_MEMBER,
                          ROLE_MODERATOR=ROLE_MODERATOR,
                          ROLE_ADMIN=ROLE_ADMIN)

@bp.route('/<int:id>/add_member', methods=['POST'])
@login_required
def add_member(id):
    """Add a user to the team"""
    team = Team.query.get_or_404(id)
    
    # Check permissions
    if not team.can_user_manage_members(current_user.id):
        flash('Nie masz uprawnień do zarządzania członkami tego zespołu.', 'danger')
        return redirect(url_for('teams.members', id=id))
    
    user_id = request.form.get('user_id')
    role = int(request.form.get('role', ROLE_MEMBER))
    
    if not user_id:
        flash('Nie wybrano użytkownika.', 'danger')
        return redirect(url_for('teams.members', id=id))
    
    user = User.query.get_or_404(user_id)
    
    # Check if user is already in the team
    is_member = db.session.query(user_team).filter(
        user_team.c.user_id == user_id,
        user_team.c.team_id == id
    ).first() is not None
    
    if is_member:
        flash(f'Użytkownik {user.username} jest już członkiem tego zespołu.', 'warning')
    else:
        try:
            # Add user to team with specified role
            stmt = user_team.insert().values(user_id=user_id, team_id=id, role=role)
            db.session.execute(stmt)
            db.session.commit()
            flash(f'Użytkownik {user.username} został dodany do zespołu.', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania użytkownika do zespołu: {str(e)}', 'danger')
    
    return redirect(url_for('teams.members', id=id))

@bp.route('/<int:team_id>/change_role/<int:user_id>', methods=['POST'])
@login_required
def change_role(team_id, user_id):
    """Change a user's role in the team"""
    team = Team.query.get_or_404(team_id)
    user = User.query.get_or_404(user_id)
    
    # Check permissions
    if not team.can_user_manage_members(current_user.id):
        flash('Nie masz uprawnień do zarządzania członkami tego zespołu.', 'danger')
        return redirect(url_for('teams.members', id=team_id))
    
    new_role = int(request.form.get('role', ROLE_MEMBER))
    
    try:
        # Update role
        stmt = user_team.update().\
            where(user_team.c.user_id == user_id).\
            where(user_team.c.team_id == team_id).\
            values(role=new_role)
        db.session.execute(stmt)
        db.session.commit()
        
        role_names = {ROLE_MEMBER: "Członek", ROLE_MODERATOR: "Moderator", ROLE_ADMIN: "Administrator"}
        flash(f'Rola użytkownika {user.username} została zmieniona na {role_names.get(new_role, "Nieznana")}', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Wystąpił błąd podczas zmiany roli: {str(e)}', 'danger')
    
    return redirect(url_for('teams.members', id=team_id))

@bp.route('/<int:id>/sharing')
@login_required
def sharing(id):
    """Manage team resource sharing"""
    team = Team.query.get_or_404(id)
    
    # Check permissions
    if not team.can_user_share_resources(current_user.id):
        flash('Nie masz uprawnień do zarządzania udostępnianiem zasobów tego zespołu.', 'danger')
        return redirect(url_for('teams.index'))
    
    # Get all other teams
    other_teams = Team.query.filter(Team.id != id).all()
    
    # Get teams with which resources are shared
    shared_with = db.session.query(
        Team, 
        team_resource_share.c.resource_type
    ).join(
        team_resource_share, 
        Team.id == team_resource_share.c.resource_team_id
    ).filter(
        team_resource_share.c.team_id == id
    ).all()
    
    return render_template('teams/sharing.html',
                          title=f'Udostępnianie zasobów: {team.name}',
                          team=team,
                          other_teams=other_teams,
                          shared_with=shared_with)

@bp.route('/<int:id>/share', methods=['POST'])
@login_required
def share_resources(id):
    """Share team resources with another team"""
    team = Team.query.get_or_404(id)
    
    # Check permissions
    if not team.can_user_share_resources(current_user.id):
        flash('Nie masz uprawnień do udostępniania zasobów tego zespołu.', 'danger')
        return redirect(url_for('teams.index'))
    
    target_team_id = request.form.get('team_id')
    resource_type = request.form.get('resource_type')
    
    if not target_team_id or not resource_type:
        flash('Nieprawidłowe dane formularza.', 'danger')
        return redirect(url_for('teams.sharing', id=id))
    
    # Check if already shared
    existing = db.session.query(team_resource_share).filter(
        team_resource_share.c.team_id == id,
        team_resource_share.c.resource_team_id == target_team_id,
        team_resource_share.c.resource_type == resource_type
    ).first()
    
    if existing:
        flash('Te zasoby są już udostępnione temu zespołowi.', 'warning')
        return redirect(url_for('teams.sharing', id=id))
    
    try:
        # Create sharing record
        stmt = team_resource_share.insert().values(
            team_id=id,
            resource_team_id=target_team_id,
            resource_type=resource_type,
            created_by=current_user.id
        )
        db.session.execute(stmt)
        db.session.commit()
        
        target_team = Team.query.get(target_team_id)
        flash(f'Zasoby typu {resource_type} zostały udostępnione zespołowi {target_team.name}.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Wystąpił błąd podczas udostępniania zasobów: {str(e)}', 'danger')
    
    return redirect(url_for('teams.sharing', id=id))

@bp.route('/<int:team_id>/unshare/<int:target_team_id>/<resource_type>', methods=['POST'])
@login_required
def unshare_resources(team_id, target_team_id, resource_type):
    """Remove resource sharing with another team"""
    team = Team.query.get_or_404(team_id)
    
    # Check permissions
    if not team.can_user_share_resources(current_user.id):
        flash('Nie masz uprawnień do zarządzania udostępnianiem zasobów tego zespołu.', 'danger')
        return redirect(url_for('teams.index'))
    
    try:
        # Remove sharing record
        stmt = team_resource_share.delete().where(
            team_resource_share.c.team_id == team_id,
            team_resource_share.c.resource_team_id == target_team_id,
            team_resource_share.c.resource_type == resource_type
        )
        db.session.execute(stmt)
        db.session.commit()
        
        target_team = Team.query.get(target_team_id)
        flash(f'Udostępnianie zasobów typu {resource_type} dla zespołu {target_team.name} zostało anulowane.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Wystąpił błąd podczas anulowania udostępniania: {str(e)}', 'danger')
    
    return redirect(url_for('teams.sharing', id=team_id))
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, BooleanField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length, Optional, ValidationError
from app.models.team import Team, ROLE_MEMBER, ROLE_MODERATOR, ROLE_ADMIN

class TeamForm(FlaskForm):
    """Form for creating and editing teams"""
    name = StringField('Nazwa zespołu', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=500)])
    is_active = BooleanField('Aktywny', default=True)
    submit = SubmitField('Zapisz')
    
    def validate_name(self, field):
        # Check for uniqueness of team name
        team = Team.query.filter(Team.name == field.data).first()
        if team and (not hasattr(self, 'team') or team.id != self.team.id):
            raise ValidationError('Zespół o takiej nazwie już istnieje.')

class MemberForm(FlaskForm):
    """Form for adding team members"""
    user_id = SelectField('Użytkownik', coerce=int, validators=[DataRequired()])
    role = SelectField('Rola', choices=[
        (ROLE_MEMBER, 'Członek'),
        (ROLE_MODERATOR, 'Moderator'),
        (ROLE_ADMIN, 'Administrator')
    ], coerce=int, default=ROLE_MEMBER)
    submit = SubmitField('Dodaj do zespołu')

class ShareResourceForm(FlaskForm):
    """Form for sharing resources with other teams"""
    team_id = SelectField('Zespół', coerce=int, validators=[DataRequired()])
    resource_type = SelectField('Typ zasobu', choices=[
        ('links', 'Linki'),
        ('categories', 'Kategorie')
    ], validators=[DataRequired()])
    submit = SubmitField('Udostępnij')

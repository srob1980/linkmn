from datetime import datetime, date, timedelta
from flask import current_app
from app.models.infrastructure import Asset
from app.utils.logger import log_activity
from app.models.config import AppConfig

class WarrantyChecker:
    @staticmethod
    def check_warranties():
        """Check warranties and generate notifications"""
        try:
            # Get notification thresholds from config
            warning_days = int(AppConfig.get_value('WARRANTY_WARNING_DAYS', '30'))
            critical_days = int(AppConfig.get_value('WARRANTY_CRITICAL_DAYS', '7'))
            
            today = date.today()
            assets = Asset.query.filter(Asset.warranty_end.isnot(None)).all()
            
            notifications = []
            
            for asset in assets:
                days_left = asset.warranty_days_left
                
                if days_left < 0:
                    if not asset.warranty_notified:
                        notifications.append({
                            'asset': asset,
                            'severity': 'danger',
                            'message': f'Gwarancja wygasła {abs(days_left)} dni temu'
                        })
                        asset.warranty_notified = True
                
                elif days_left <= critical_days:
                    notifications.append({
                        'asset': asset,
                        'severity': 'danger',
                        'message': f'Gwarancja wygasa za {days_left} dni'
                    })
                
                elif days_left <= warning_days:
                    notifications.append({
                        'asset': asset,
                        'severity': 'warning',
                        'message': f'Gwarancja wygasa za {days_left} dni'
                    })
            
            return notifications
            
        except Exception as e:
            current_app.logger.error(f"Error checking warranties: {str(e)}")
            return []

import psutil
import os
import platform
from datetime import datetime
import logging

class SystemMonitor:
    @staticmethod
    def get_system_metrics():
        """Get current system metrics"""
        try:
            # CPU metrics
            cpu_percent = psutil.cpu_percent(interval=0.1)
            cpu_count = psutil.cpu_count()

            # Memory metrics
            memory = psutil.virtual_memory()
            memory_total = memory.total
            memory_used = memory.used
            memory_percent = memory.percent

            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_total = disk.total
            disk_used = disk.used
            disk_percent = disk.percent

            return {
                'cpu': {
                    'percent': cpu_percent,
                    'cores': cpu_count
                },
                'memory': {
                    'total': memory_total,
                    'used': memory_used,
                    'percent': memory_percent
                },
                'disk': {
                    'total': disk_total,
                    'used': disk_used,
                    'percent': disk_percent
                }
            }
        except Exception as e:
            print(f"Error getting system metrics: {e}")
            return {
                'cpu': {'percent': 0, 'cores': 0},
                'memory': {'total': 0, 'used': 0, 'percent': 0},
                'disk': {'total': 0, 'used': 0, 'percent': 0}
            }

    @staticmethod
    def get_historical_metrics(period='hour'):
        """Get historical system metrics"""
        # Implementation depends on how you store historical data
        pass

    @staticmethod
    def get_service_status():
        """Get status of system services"""
        services = {}
        try:
            # Database status
            from app import db
            services['database'] = {
                'name': 'Database',
                'status': 'running',
                'type': db.engine.name
            }
        except:
            services['database'] = {
                'name': 'Database',
                'status': 'error',
                'type': 'unknown'
            }
            
        return services

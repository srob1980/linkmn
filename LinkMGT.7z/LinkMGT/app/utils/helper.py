"""Helper utilities for the application"""
import os
import re
import json
import random
import string
import datetime
from flask import current_app

def get_environment_info():
    """Get information about the current environment"""
    flask_env = os.environ.get('FLASK_ENV', 'production')
    debug_mode = os.environ.get('FLASK_DEBUG', 'False').lower() in ('true', '1', 't')
    
    return {
        'environment': flask_env,
        'debug': debug_mode,
        'python_version': os.environ.get('PYTHON_VERSION', ''),
        'timezone': datetime.datetime.now().astimezone().tzinfo,
    }

def update_env_var(env_file, key, value):
    """Update a value in the .env file"""
    if not os.path.exists(env_file):
        # Create the file if it doesn't exist
        with open(env_file, 'w') as f:
            f.write(f'{key}={value}\n')
        return True
    
    # Read existing file
    with open(env_file, 'r') as f:
        lines = f.readlines()
    
    # Check if key exists and update it
    key_exists = False
    new_lines = []
    for line in lines:
        if line.startswith('#') or '=' not in line:
            new_lines.append(line)
            continue
            
        line_key, line_value = line.strip().split('=', 1)
        if line_key == key:
            new_lines.append(f'{key}={value}\n')
            key_exists = True
        else:
            new_lines.append(line)
    
    # Add key if it doesn't exist
    if not key_exists:
        new_lines.append(f'{key}={value}\n')
    
    # Write the file back
    with open(env_file, 'w') as f:
        f.writelines(new_lines)
    
    return True

def get_database_drivers():
    """Check which database drivers are available"""
    drivers = {
        'sqlite': 'Built-in',  # SQLite is always available
        'postgresql': 'Not installed',
        'mysql': 'Not installed',
        'oracle': 'Not installed'
    }
    
    # Check for PostgreSQL driver (psycopg2)
    try:
        import psycopg2
        drivers['postgresql'] = psycopg2.__version__
    except ImportError:
        pass
    
    # Check for MySQL driver (PyMySQL)
    try:
        import pymysql
        drivers['mysql'] = pymysql.__version__
    except ImportError:
        pass
    
    # Check for Oracle drivers (cx_Oracle or oracledb)
    try:
        try:
            import cx_Oracle
            drivers['oracle'] = cx_Oracle.version
        except ImportError:
            try:
                import oracledb
                drivers['oracle'] = oracledb.__version__
            except ImportError:
                pass
    except Exception:
        pass
    
    return drivers

def generate_random_string(length=12):
    """Generate a random string of specified length"""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def sanitize_filename(filename):
    """Sanitize a filename to be safe for filesystem storage"""
    # Remove any non-alphanumeric characters except for period, underscore, and dash
    sanitized = re.sub(r'[^\w\.-]', '_', filename)
    
    # Ensure filename doesn't start with a period (hidden file in Unix)
    if sanitized.startswith('.'):
        sanitized = 'f' + sanitized
    
    return sanitized

def create_directory_if_not_exists(directory):
    """Create a directory if it doesn't exist"""
    if not os.path.exists(directory):
        os.makedirs(directory)
        return True
    return False

def get_file_size_human_readable(file_path):
    """Get human-readable file size"""
    if not os.path.exists(file_path):
        return "0 B"
    
    size = os.path.getsize(file_path)
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0

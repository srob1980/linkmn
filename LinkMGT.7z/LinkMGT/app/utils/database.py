"""
Database utility functions for testing connections, executing migrations,
and creating backups for different database types.
"""
import os
import sys
import importlib.util
import re
import shutil
import subprocess
from datetime import datetime
from urllib.parse import urlparse
from flask import current_app

# Check available drivers
def check_drivers():
    """Check which database drivers are available in the current environment"""
    drivers = {
        'sqlite': True,  # SQLite is part of Python standard library
        'postgresql': False,
        'mysql': False,
        'oracle': False
    }
    
    # Check PostgreSQL
    try:
        import psycopg2
        drivers['postgresql'] = True
    except ImportError:
        pass
    
    # Check MySQL/MariaDB
    try:
        import pymysql
        drivers['mysql'] = True
    except ImportError:
        pass
    
    # Check Oracle
    try:
        try:
            import oracledb
            drivers['oracle'] = True
        except ImportError:
            import cx_Oracle
            drivers['oracle'] = True
    except ImportError:
        pass
    
    return drivers

def parse_db_url(db_url):
    """Parse database URL into components"""
    result = {
        'engine': None,
        'user': None,
        'password': None,
        'host': None,
        'port': None,
        'database': None,
        'params': {}
    }
    
    # Handle SQLite specially
    if db_url.startswith('sqlite:///'):
        result['engine'] = 'sqlite'
        result['database'] = db_url.replace('sqlite:///', '')
        return result
    
    # Parse URL for other database types
    pattern = r'(\w+)://([^:@]+):([^@]*)@([^:/]+)(?::(\d+))?/([^?]+)(?:\?(.+))?'
    match = re.match(pattern, db_url)
    
    if match:
        result['engine'] = match.group(1)
        result['user'] = match.group(2)
        result['password'] = match.group(3)
        result['host'] = match.group(4)
        result['port'] = match.group(5)
        result['database'] = match.group(6)
        
        # Parse query parameters
        if match.group(7):
            params = match.group(7).split('&')
            for param in params:
                if '=' in param:
                    key, value = param.split('=', 1)
                    result['params'][key] = value
    
    return result

def test_connection(db_url):
    """Test database connection for the specified URL"""
    try:
        parsed = parse_db_url(db_url)
        engine = parsed['engine']
        
        if engine == 'sqlite':
            # Test SQLite connection
            import sqlite3
            db_path = parsed['database']
            conn = sqlite3.connect(db_path)
            conn.execute('SELECT 1')
            conn.close()
            return True, "SQLite connection successful"
        
        elif engine == 'postgresql':
            # Test PostgreSQL connection
            import psycopg2
            conn = psycopg2.connect(
                host=parsed['host'],
                port=parsed['port'] or '5432',
                user=parsed['user'],
                password=parsed['password'],
                dbname=parsed['database'],
                connect_timeout=5
            )
            conn.cursor().execute('SELECT 1')
            conn.close()
            return True, "PostgreSQL connection successful"
        
        elif engine in ('mysql', 'mariadb'):
            # Test MySQL/MariaDB connection
            import pymysql
            conn = pymysql.connect(
                host=parsed['host'],
                port=int(parsed['port'] or 3306),
                user=parsed['user'],
                password=parsed['password'],
                database=parsed['database'],
                connect_timeout=5
            )
            conn.cursor().execute('SELECT 1')
            conn.close()
            return True, "MySQL/MariaDB connection successful"
        
        elif engine == 'oracle':
            # Test Oracle connection - try with oracledb first, then cx_Oracle
            try:
                import oracledb
                conn = oracledb.connect(
                    user=parsed['user'],
                    password=parsed['password'],
                    dsn=f"{parsed['host']}:{parsed['port'] or '1521'}/{parsed['database']}"
                )
            except ImportError:
                import cx_Oracle
                conn = cx_Oracle.connect(
                    user=parsed['user'],
                    password=parsed['password'],
                    dsn=f"{parsed['host']}:{parsed['port'] or '1521'}/{parsed['database']}"
                )
            
            conn.cursor().execute('SELECT 1 FROM DUAL')
            conn.close()
            return True, "Oracle connection successful"
        
        else:
            return False, f"Unsupported database engine: {engine}"
    
    except Exception as e:
        return False, f"Connection error: {str(e)}"

def create_backup(db_url, backup_path, backup_type='full', compress=True):
    """Create a database backup"""
    try:
        parsed = parse_db_url(db_url)
        engine = parsed['engine']
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if not os.path.exists(os.path.dirname(backup_path)):
            os.makedirs(os.path.dirname(backup_path), exist_ok=True)
        
        if engine == 'sqlite':
            # SQLite backup - just copy the file
            db_path = parsed['database']
            backup_file = f"{backup_path}/sqlite_backup_{backup_type}_{timestamp}.db"
            shutil.copy2(db_path, backup_file)
            
            if compress:
                import zipfile
                zip_file = f"{backup_file}.zip"
                with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    zipf.write(backup_file, os.path.basename(backup_file))
                os.remove(backup_file)
                backup_file = zip_file
            
            return True, backup_file
        
        elif engine == 'postgresql':
            # PostgreSQL backup using pg_dump
            backup_file = f"{backup_path}/pg_backup_{backup_type}_{timestamp}.sql"
            
            env = os.environ.copy()
            env['PGPASSWORD'] = parsed['password']
            
            cmd = [
                'pg_dump',
                '-h', parsed['host'],
                '-p', parsed['port'] or '5432',
                '-U', parsed['user'],
                '-d', parsed['database'],
                '-f', backup_file
            ]
            
            if backup_type == 'schema':
                cmd.append('--schema-only')
            elif backup_type == 'data':
                cmd.append('--data-only')
            
            result = subprocess.run(cmd, env=env, capture_output=True, text=True)
            
            if result.returncode != 0:
                return False, f"pg_dump error: {result.stderr}"
            
            if compress:
                import zipfile
                zip_file = f"{backup_file}.zip"
                with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    zipf.write(backup_file, os.path.basename(backup_file))
                os.remove(backup_file)
                backup_file = zip_file
            
            return True, backup_file
        
        elif engine in ('mysql', 'mariadb'):
            # MySQL/MariaDB backup using mysqldump
            backup_file = f"{backup_path}/mysql_backup_{backup_type}_{timestamp}.sql"
            
            cmd = [
                'mysqldump',
                '-h', parsed['host'],
                '-P', parsed['port'] or '3306',
                '-u', parsed['user'],
                f"-p{parsed['password']}",
                parsed['database'],
                '-r', backup_file
            ]
            
            if backup_type == 'schema':
                cmd.append('--no-data')
            elif backup_type == 'data':
                cmd.append('--no-create-info')
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                return False, f"mysqldump error: {result.stderr}"
            
            if compress:
                import zipfile
                zip_file = f"{backup_file}.zip"
                with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    zipf.write(backup_file, os.path.basename(backup_file))
                os.remove(backup_file)
                backup_file = zip_file
            
            return True, backup_file
        
        elif engine == 'oracle':
            # Oracle backup using expdp (Data Pump)
            backup_file = f"{backup_path}/oracle_backup_{backup_type}_{timestamp}.dmp"
            log_file = f"{backup_path}/oracle_backup_{backup_type}_{timestamp}.log"
            
            # Oracle connection string
            conn_str = f"{parsed['user']}/{parsed['password']}@{parsed['host']}:{parsed['port'] or '1521'}/{parsed['database']}"
            
            cmd = [
                'expdp', conn_str,
                'DIRECTORY=DATA_PUMP_DIR',
                f"DUMPFILE={os.path.basename(backup_file)}",
                f"LOGFILE={os.path.basename(log_file)}"
            ]
            
            if backup_type == 'schema':
                cmd.append('CONTENT=METADATA_ONLY')
            elif backup_type == 'data':
                cmd.append('CONTENT=DATA_ONLY')
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                # If expdp fails, try with exp (original export utility)
                cmd = [
                    'exp', conn_str,
                    f"FILE={backup_file}",
                    f"LOG={log_file}"
                ]
                
                if backup_type == 'schema':
                    cmd.append('ROWS=N')
                
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode != 0:
                    return False, f"Oracle export error: {result.stderr}"
            
            if compress:
                import zipfile
                zip_file = f"{backup_file}.zip"
                with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    zipf.write(backup_file, os.path.basename(backup_file))
                    if os.path.exists(log_file):
                        zipf.write(log_file, os.path.basename(log_file))
                
                if os.path.exists(backup_file):
                    os.remove(backup_file)
                if os.path.exists(log_file):
                    os.remove(log_file)
                
                backup_file = zip_file
            
            return True, backup_file
        
        else:
            return False, f"Unsupported database engine: {engine}"
    
    except Exception as e:
        return False, f"Backup error: {str(e)}"

def get_database_info(db_url):
    """Get database information"""
    try:
        parsed = parse_db_url(db_url)
        engine = parsed['engine']
        info = {
            'engine': engine,
            'version': 'Unknown',
            'server': parsed.get('host', 'local'),
            'connected': False,
            'tables': 0,
            'size': 'Unknown'
        }
        
        if engine == 'sqlite':
            # Get SQLite information
            import sqlite3
            db_path = parsed['database']
            
            if os.path.exists(db_path):
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                
                # Get version
                cursor.execute('SELECT sqlite_version()')
                info['version'] = cursor.fetchone()[0]
                
                # Get table count
                cursor.execute("SELECT count(*) FROM sqlite_master WHERE type='table'")
                info['tables'] = cursor.fetchone()[0]
                
                # Get database size
                info['size'] = f"{os.path.getsize(db_path) / (1024*1024):.2f} MB"
                
                info['connected'] = True
                conn.close()
        
        elif engine == 'postgresql':
            # Get PostgreSQL information
            import psycopg2
            conn = psycopg2.connect(
                host=parsed['host'],
                port=parsed['port'] or '5432',
                user=parsed['user'],
                password=parsed['password'],
                dbname=parsed['database'],
                connect_timeout=5
            )
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT version()')
            info['version'] = cursor.fetchone()[0]
            
            # Get table count
            cursor.execute("SELECT count(*) FROM information_schema.tables WHERE table_schema='public'")
            info['tables'] = cursor.fetchone()[0]
            
            # Get database size
            cursor.execute("SELECT pg_size_pretty(pg_database_size(current_database()))")
            info['size'] = cursor.fetchone()[0]
            
            info['connected'] = True
            conn.close()
        
        elif engine in ('mysql', 'mariadb'):
            # Get MySQL/MariaDB information
            import pymysql
            conn = pymysql.connect(
                host=parsed['host'],
                port=int(parsed['port'] or 3306),
                user=parsed['user'],
                password=parsed['password'],
                database=parsed['database'],
                connect_timeout=5
            )
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT VERSION()')
            info['version'] = cursor.fetchone()[0]
            
            # Get table count
            cursor.execute("SELECT count(*) FROM information_schema.tables WHERE table_schema=DATABASE()")
            info['tables'] = cursor.fetchone()[0]
            
            # Get database size
            cursor.execute("""
                SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2)
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
            """)
            size = cursor.fetchone()[0]
            info['size'] = f"{size or 0} MB"
            
            info['connected'] = True
            conn.close()
        
        elif engine == 'oracle':
            # Get Oracle information
            try:
                import oracledb as oracle_module
            except ImportError:
                import cx_Oracle as oracle_module
            
            conn = oracle_module.connect(
                user=parsed['user'],
                password=parsed['password'],
                dsn=f"{parsed['host']}:{parsed['port'] or '1521'}/{parsed['database']}"
            )
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT banner FROM v$version WHERE banner LIKE \'Oracle%\'')
            info['version'] = cursor.fetchone()[0]
            
            # Get table count
            cursor.execute("SELECT COUNT(*) FROM user_tables")
            info['tables'] = cursor.fetchone()[0]
            
            # Get database size (requires DBA privileges)
            try:
                cursor.execute("""
                    SELECT ROUND(SUM(bytes)/1024/1024,2) FROM dba_segments
                """)
                size = cursor.fetchone()[0]
                info['size'] = f"{size or 0} MB"
            except:
                # If we don't have DBA privileges, just show a message
                info['size'] = 'Requires DBA privileges'
            
            info['connected'] = True
            conn.close()
        
        return info
    
    except Exception as e:
        return {
            'engine': parsed.get('engine', 'unknown') if 'parsed' in locals() else 'unknown',
            'version': 'Error',
            'server': parsed.get('host', 'unknown') if 'parsed' in locals() else 'unknown',
            'connected': False,
            'tables': 0,
            'size': 'Unknown',
            'error': str(e)
        }

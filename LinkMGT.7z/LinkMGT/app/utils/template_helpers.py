from flask import current_app
from datetime import datetime, date
import humanize

def format_date(value):
    """Format a date or datetime object to string."""
    if not value:
        return ""
    if isinstance(value, datetime):
        return value.strftime('%Y-%m-%d %H:%M')
    if isinstance(value, date):
        return value.strftime('%Y-%m-%d')
    return value

def humanize_date(value):
    """Convert a date or datetime object to a human-readable string."""
    if not value:
        return ""
    try:
        if isinstance(value, str):
            value = datetime.strptime(value, '%Y-%m-%d')
        return humanize.naturalday(value)
    except:
        return value

def currency(value):
    """Format a number as currency."""
    if not value:
        return "$0.00"
    return "${:,.2f}".format(float(value))

def format_filesize(value):
    """Format a number of bytes to a human-readable string."""
    if not value:
        return "0 bytes"
    return humanize.naturalsize(value)

def asset_status_color(status):
    """Return a Bootstrap color class based on asset status."""
    if not status:
        return "secondary"
        
    status_map = {
        'active': 'success',
        'in_use': 'success',
        'operational': 'success',
        'deployed': 'primary',
        'spare': 'primary',
        'maintenance': 'warning',
        'repair': 'warning',
        'pending': 'info',
        'stock': 'info',
        'inactive': 'secondary',
        'retired': 'secondary',
        'disposed': 'dark',
        'lost': 'danger',
        'stolen': 'danger',
        'broken': 'danger'
    }
    
    # Convert to lowercase and replace spaces with underscores for standardization
    clean_status = str(status).lower().replace(' ', '_')
    
    # Return the mapped color or default to secondary
    return status_map.get(clean_status, 'secondary')

def warranty_status_color(asset):
    """Return a Bootstrap color class based on asset warranty status."""
    if not asset or not hasattr(asset, 'warranty_end'):
        return "secondary"
        
    if not asset.warranty_end:
        return "secondary"
        
    today = date.today()
    days_left = (asset.warranty_end - today).days
    
    if days_left < 0:
        return "danger"  # Expired
    elif days_left < 30:
        return "warning"  # Expiring soon (less than 30 days)
    elif days_left < 90:
        return "info"  # Expiring in less than 90 days
    else:
        return "success"  # Valid for more than 90 days

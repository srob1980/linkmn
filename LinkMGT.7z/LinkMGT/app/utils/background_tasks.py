import threading
import uuid
from datetime import datetime
from queue import Queue
import json
from flask import current_app

class TaskManager:
    _tasks = {}
    _lock = threading.Lock()
    _app = None

    @classmethod
    def init_app(cls, app):
        """Initialize TaskManager with Flask app"""
        cls._app = app

    @classmethod
    def start_task(cls, func, *args, **kwargs):
        """Start a new background task"""
        if not cls._app:
            raise RuntimeError("TaskManager not initialized with Flask app")

        task_id = str(uuid.uuid4())
        
        task = {
            'id': task_id,
            'status': 'running',
            'progress': 0,
            'start_time': datetime.now(),
            'result': None,
            'error': None,
            'details': '',
            'events': Queue()
        }

        cls._tasks[task_id] = task

        def run_task():
            with cls._app.app_context():
                try:
                    task['result'] = func(task, *args, **kwargs)
                    task['status'] = 'completed'
                except Exception as e:
                    task['status'] = 'error'
                    task['error'] = str(e)
                finally:
                    task['end_time'] = datetime.now()

        thread = threading.Thread(target=run_task)
        thread.daemon = True
        thread.start()

        return task_id

    @classmethod
    def get_task(cls, task_id):
        """Get task status"""
        task = cls._tasks.get(task_id)
        if not task:
            return None

        return {
            'id': task['id'],
            'status': task['status'],
            'progress': task['progress'],
            'details': task['details'],
            'error': task['error']
        }

    @classmethod
    def cancel_task(cls, task_id):
        """Cancel running task"""
        with cls._lock:
            task = cls._tasks.get(task_id)
            if task and task['status'] == 'running':
                task['status'] = 'cancelled'
                return True
        return False

    @classmethod
    def get_task_events(cls, task_id):
        """Generator for task events"""
        task = cls._tasks.get(task_id)
        if not task:
            return

        while True:
            if task['status'] in ['completed', 'error', 'cancelled']:
                data = {
                    'status': task['status'],
                    'progress': 100 if task['status'] == 'completed' else task['progress'],
                    'details': task['details']
                }
                if task['error']:
                    data['message'] = task['error']
                yield f"data: {json.dumps(data)}\n\n"
                break

            yield f"data: {json.dumps({'status': 'scanning', 'progress': task['progress'], 'details': task['details']})}\n\n"

            if not task['events'].empty():
                event = task['events'].get()
                yield f"data: {json.dumps(event)}\n\n"

    @classmethod
    def get_active_tasks(cls):
        """Get list of active tasks"""
        return [
            {
                'id': task_id,
                'status': task['status'],
                'progress': task['progress'],
                'start_time': task['start_time'].isoformat(),
                'details': task['details']
            }
            for task_id, task in cls._tasks.items()
            if task['status'] == 'running'
        ]

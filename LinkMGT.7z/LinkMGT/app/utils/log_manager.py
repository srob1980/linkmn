import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from app.models.system_log import SystemLog
from app import db

class LogManager:
    def __init__(self, app=None):
        self.app = app
        self.log_dir = app.config.get('LOG_DIR', 'logs')
        self.setup_logging()

    def setup_logging(self):
        """Configure logging system"""
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        # Configure file handler for app.log
        file_handler = RotatingFileHandler(
            os.path.join(self.log_dir, 'app.log'),
            maxBytes=10*1024*1024,  # 10MB
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(module)s: %(message)s'
        ))
        file_handler.setLevel(logging.INFO)
        
        # Add handlers to app logger
        self.app.logger.addHandler(file_handler)
        self.app.logger.setLevel(logging.INFO)

    def log_event(self, level, message, source=None, details=None, user_id=None):
        """Log an event to both file and database"""
        try:
            # Log to file
            if level.upper() == 'ERROR':
                self.app.logger.error(message)
            elif level.upper() == 'WARNING':
                self.app.logger.warning(message)
            else:
                self.app.logger.info(message)

            # Log to database
            log = SystemLog(
                level=level.upper(),
                message=message,
                source=source,
                details=details,
                user_id=user_id
            )
            db.session.add(log)
            db.session.commit()

        except Exception as e:
            self.app.logger.error(f"Error saving log: {str(e)}")

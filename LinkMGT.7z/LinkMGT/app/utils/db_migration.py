"""
Narzędzia do migracji danych między różnymi silnikami baz danych.
"""
import os
import sys
import tempfile
import shutil
import sqlite3
import csv
import datetime
from flask import current_app
from app.utils.db_utils import parse_db_url, test_connection

def export_table_to_csv(conn, table_name, output_file):
    """Eksportuje tabelę do pliku CSV"""
    cursor = conn.cursor()
    
    # Pobierz informacje o strukturze tabeli
    cursor.execute(f"SELECT * FROM {table_name} LIMIT 0")
    header = [col[0] for col in cursor.description]
    
    # Pobierz dane
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    
    # Zapisz do CSV
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)
    
    return len(rows)

def import_csv_to_table(conn, table_name, csv_file):
    """Importuje dane z pliku CSV do tabeli"""
    cursor = conn.cursor()
    
    # Wczytaj dane z CSV
    with open(csv_file, 'r', newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)
    
    # Jeśli tabela nie istnieje, nie możemy zaimportować danych
    if not rows:
        return 0
    
    # Przygotuj zapytanie SQL
    placeholders = ', '.join(['?'] * len(header))
    columns = ', '.join([f'"{col}"' for col in header])
    insert_query = f'INSERT INTO {table_name} ({columns}) VALUES ({placeholders})'
    
    # Wykonaj zapytanie dla każdego wiersza
    for row in rows:
        try:
            cursor.execute(insert_query, row)
        except Exception as e:
            current_app.logger.error(f"Błąd importu wiersza do {table_name}: {e}")
    
    conn.commit()
    return len(rows)

def migrate_database(source_url, target_url, tables=None):
    """Migruje dane z jednej bazy do drugiej"""
    # Sprawdź połączenia
    source_ok, source_msg = test_connection(source_url)
    if not source_ok:
        return False, f"Błąd połączenia z bazą źródłową: {source_msg}"
    
    target_ok, target_msg = test_connection(target_url)
    if not target_ok:
        return False, f"Błąd połączenia z bazą docelową: {target_msg}"
    
    # Parsuj URL
    source_parsed = parse_db_url(source_url)
    target_parsed = parse_db_url(target_url)
    
    if not source_parsed or not target_parsed:
        return False, "Nieprawidłowy format URL bazy danych"
    
    # Utwórz katalog tymczasowy
    temp_dir = tempfile.mkdtemp()
    
    try:
        # Połącz z bazą źródłową
        if source_parsed['engine'] == 'sqlite':
            import sqlite3
            source_conn = sqlite3.connect(source_parsed['database'])
            source_conn.row_factory = sqlite3.Row
            
            # Pobierz listę tabel
            cursor = source_conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            all_tables = [row[0] for row in cursor.fetchall()]
            
            if tables is None:
                tables = all_tables
            
            # Eksportuj dane
            exported_data = {}
            for table in tables:
                if table in all_tables:
                    output_file = os.path.join(temp_dir, f"{table}.csv")
                    rows = export_table_to_csv(source_conn, table, output_file)
                    exported_data[table] = {'file': output_file, 'rows': rows}
            
            source_conn.close()
        
        elif source_parsed['engine'] == 'postgresql':
            import psycopg2
            import psycopg2.extras
            
            source_conn = psycopg2.connect(
                host=source_parsed['host'],
                port=source_parsed['port'] or '5432',
                user=source_parsed['user'],
                password=source_parsed['password'],
                dbname=source_parsed['database']
            )
            
            # Pobierz listę tabel
            cursor = source_conn.cursor()
            cursor.execute("SELECT tablename FROM pg_tables WHERE schemaname='public'")
            all_tables = [row[0] for row in cursor.fetchall()]
            
            if tables is None:
                tables = all_tables
            
            # Eksportuj dane
            exported_data = {}
            for table in tables:
                if table in all_tables:
                    output_file = os.path.join(temp_dir, f"{table}.csv")
                    rows = export_table_to_csv(source_conn, table, output_file)
                    exported_data[table] = {'file': output_file, 'rows': rows}
            
            source_conn.close()
        
        # ... podobna implementacja dla MySQL i Oracle ...
        
        # Połącz z bazą docelową i zaimportuj dane
        if target_parsed['engine'] == 'sqlite':
            import sqlite3
            target_conn = sqlite3.connect(target_parsed['database'])
            
            for table, data in exported_data.items():
                try:
                    rows = import_csv_to_table(target_conn, table, data['file'])
                    print(f"Zaimportowano {rows} wierszy do tabeli {table}")
                except Exception as e:
                    print(f"Błąd importu do tabeli {table}: {e}")
            
            target_conn.close()
        
        elif target_parsed['engine'] == 'postgresql':
            import psycopg2
            
            target_conn = psycopg2.connect(
                host=target_parsed['host'],
                port=target_parsed['port'] or '5432',
                user=target_parsed['user'],
                password=target_parsed['password'],
                dbname=target_parsed['database']
            )
            
            for table, data in exported_data.items():
                try:
                    rows = import_csv_to_table(target_conn, table, data['file'])
                    print(f"Zaimportowano {rows} wierszy do tabeli {table}")
                except Exception as e:
                    print(f"Błąd importu do tabeli {table}: {e}")
            
            target_conn.close()
        
        # ... podobna implementacja dla MySQL i Oracle ...
        
        return True, f"Migracja zakończona pomyślnie. Przeniesiono dane z {len(exported_data)} tabel."
    
    except Exception as e:
        return False, f"Błąd podczas migracji: {str(e)}"
    
    finally:
        # Usuń pliki tymczasowe
        shutil.rmtree(temp_dir, ignore_errors=True)

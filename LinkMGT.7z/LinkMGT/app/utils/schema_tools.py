"""
Narzędzia do analizy i eksportu schematów baz danych.
"""
import os
import sys
import re
from flask import current_app
from app.utils.db_utils import parse_db_url, test_connection

def get_db_schema(db_url):
    """Pobiera schemat bazy danych"""
    # Testuj połączenie
    conn_ok, conn_msg = test_connection(db_url)
    if not conn_ok:
        return False, f"Błąd połączenia z bazą danych: {conn_msg}"
    
    # Parsuj URL
    parsed = parse_db_url(db_url)
    if not parsed:
        return False, "Nieprawidłowy format URL bazy danych"
    
    engine = parsed['engine']
    schema = {
        'tables': [],
        'views': [],
        'relationships': [],
        'engine': engine,
        'database': parsed['database']
    }
    
    try:
        if engine == 'sqlite':
            import sqlite3
            conn = sqlite3.connect(parsed['database'])
            cursor = conn.cursor()
            
            # Pobierz tabele
            cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            for name, sql in cursor.fetchall():
                table = {'name': name, 'columns': [], 'constraints': []}
                
                # Pobierz kolumny
                cursor.execute(f"PRAGMA table_info({name})")
                for col in cursor.fetchall():
                    cid, col_name, col_type, not_null, default_value, pk = col
                    column = {
                        'name': col_name,
                        'type': col_type,
                        'nullable': not not_null,
                        'primary_key': pk > 0,
                        'default': default_value
                    }
                    table['columns'].append(column)
                
                # Pobierz klucze obce
                cursor.execute(f"PRAGMA foreign_key_list({name})")
                for fk in cursor.fetchall():
                    id, seq, ref_table, from_col, to_col, on_update, on_delete, match = fk
                    constraint = {
                        'from_column': from_col,
                        'to_table': ref_table,
                        'to_column': to_col,
                        'on_delete': on_delete,
                        'on_update': on_update
                    }
                    table['constraints'].append(constraint)
                    
                    # Dodaj do relacji
                    relationship = {
                        'from_table': name,
                        'from_column': from_col,
                        'to_table': ref_table,
                        'to_column': to_col
                    }
                    schema['relationships'].append(relationship)
                
                schema['tables'].append(table)
            
            # Pobierz widoki
            cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='view'")
            for name, sql in cursor.fetchall():
                view = {
                    'name': name,
                    'sql': sql
                }
                schema['views'].append(view)
            
            conn.close()
        
        elif engine == 'postgresql':
            import psycopg2
            conn = psycopg2.connect(
                host=parsed['host'],
                port=parsed['port'] or '5432',
                user=parsed['user'],
                password=parsed['password'],
                dbname=parsed['database']
            )
            cursor = conn.cursor()
            
            # Pobierz tabele
            cursor.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
            """)
            
            for (table_name,) in cursor.fetchall():
                table = {'name': table_name, 'columns': [], 'constraints': []}
                
                # Pobierz kolumny
                cursor.execute("""
                    SELECT column_name, data_type, is_nullable, column_default,
                           (SELECT true FROM information_schema.table_constraints tc
                            JOIN information_schema.key_column_usage kcu 
                            ON tc.constraint_name = kcu.constraint_name
                            WHERE tc.table_name = c.table_name
                            AND kcu.column_name = c.column_name
                            AND tc.constraint_type = 'PRIMARY KEY') as is_primary
                    FROM information_schema.columns c
                    WHERE table_schema = 'public' AND table_name = %s
                    ORDER BY ordinal_position
                """, (table_name,))
                
                for col_name, col_type, nullable, default, is_primary in cursor.fetchall():
                    column = {
                        'name': col_name,
                        'type': col_type,
                        'nullable': nullable == 'YES',
                        'primary_key': is_primary is not None,
                        'default': default
                    }
                    table['columns'].append(column)
                
                # Pobierz klucze obce
                cursor.execute("""
                    SELECT
                        kcu.column_name,
                        ccu.table_name AS referenced_table,
                        ccu.column_name AS referenced_column,
                        rc.delete_rule,
                        rc.update_rule
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage kcu
                      ON tc.constraint_name = kcu.constraint_name
                    JOIN information_schema.constraint_column_usage ccu
                      ON ccu.constraint_name = tc.constraint_name
                    JOIN information_schema.referential_constraints rc
                      ON rc.constraint_name = tc.constraint_name
                    WHERE tc.constraint_type = 'FOREIGN KEY'
                      AND tc.table_name = %s
                """, (table_name,))
                
                for from_col, to_table, to_col, on_delete, on_update in cursor.fetchall():
                    constraint = {
                        'from_column': from_col,
                        'to_table': to_table,
                        'to_column': to_col,
                        'on_delete': on_delete,
                        'on_update': on_update
                    }
                    table['constraints'].append(constraint)
                    
                    relationship = {
                        'from_table': table_name,
                        'from_column': from_col,
                        'to_table': to_table,
                        'to_column': to_col
                    }
                    schema['relationships'].append(relationship)
                
                schema['tables'].append(table)
            
            # Pobierz widoki
            cursor.execute("""
                SELECT table_name, view_definition
                FROM information_schema.views
                WHERE table_schema = 'public'
            """)
            
            for view_name, view_def in cursor.fetchall():
                view = {
                    'name': view_name,
                    'sql': view_def
                }
                schema['views'].append(view)
            
            conn.close()
        
        # ... podobna implementacja dla MySQL i Oracle ...
        
        return True, schema
        
    except Exception as e:
        return False, f"Błąd podczas pobierania schematu: {str(e)}"

def export_schema_to_sql(schema, output_file, target_engine=None):
    """Eksportuje schemat bazy danych do pliku SQL"""
    if not schema or not isinstance(schema, dict) or 'tables' not in schema:
        return False, "Nieprawidłowy schemat bazy danych"
    
    source_engine = schema.get('engine', 'sqlite')
    target_engine = target_engine or source_engine
    
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            # Nagłówek
            f.write(f"-- Schema for {schema.get('database', 'unknown')}\n")
            f.write(f"-- Generated on {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"-- Source engine: {source_engine}\n")
            f.write(f"-- Target engine: {target_engine}\n\n")
            
            # Dla każdej tabeli
            for table in schema['tables']:
                table_name = table['name']
                f.write(f"-- Table: {table_name}\n")
                
                if target_engine == 'sqlite':
                    f.write(f"CREATE TABLE IF NOT EXISTS {table_name} (\n")
                    
                    # Kolumny
                    columns = []
                    for col in table['columns']:
                        col_def = f"  {col['name']} {col['type']}"
                        
                        if col['primary_key']:
                            col_def += " PRIMARY KEY"
                        
                        if not col['nullable']:
                            col_def += " NOT NULL"
                        
                        if col['default'] is not None:
                            col_def += f" DEFAULT {col['default']}"
                        
                        columns.append(col_def)
                    
                    # Klucze obce
                    for constraint in table['constraints']:
                        fk_def = f"  FOREIGN KEY ({constraint['from_column']}) REFERENCES {constraint['to_table']}({constraint['to_column']})"
                        
                        if 'on_delete' in constraint and constraint['on_delete']:
                            fk_def += f" ON DELETE {constraint['on_delete']}"
                        
                        if 'on_update' in constraint and constraint['on_update']:
                            fk_def += f" ON UPDATE {constraint['on_update']}"
                        
                        columns.append(fk_def)
                    
                    f.write(',\n'.join(columns))
                    f.write("\n);\n\n")
                
                elif target_engine == 'postgresql':
                    f.write(f"CREATE TABLE IF NOT EXISTS {table_name} (\n")
                    
                    # Kolumny
                    columns = []
                    for col in table['columns']:
                        col_type = col['type']
                        
                        # Konwersja typów SQLite -> PostgreSQL
                        if source_engine == 'sqlite':
                            if 'INTEGER' in col_type.upper():
                                col_type = 'INTEGER'
                            elif 'TEXT' in col_type.upper():
                                col_type = 'TEXT'
                            elif 'REAL' in col_type.upper():
                                col_type = 'REAL'
                            elif 'BLOB' in col_type.upper():
                                col_type = 'BYTEA'
                        
                        col_def = f"  {col['name']} {col_type}"
                        
                        if col['primary_key']:
                            col_def += " PRIMARY KEY"
                        
                        if not col['nullable']:
                            col_def += " NOT NULL"
                        
                        if col['default'] is not None:
                            col_def += f" DEFAULT {col['default']}"
                        
                        columns.append(col_def)
                    
                    f.write(',\n'.join(columns))
                    f.write("\n);\n\n")
                    
                    # Klucze obce jako oddzielne polecenia ALTER TABLE
                    for constraint in table['constraints']:
                        f.write(f"ALTER TABLE {table_name} ADD CONSTRAINT fk_{table_name}_{constraint['from_column']} ")
                        f.write(f"FOREIGN KEY ({constraint['from_column']}) ")
                        f.write(f"REFERENCES {constraint['to_table']}({constraint['to_column']});\n")
                
                # ... podobna implementacja dla MySQL i Oracle ...
            
            # Widoki
            for view in schema['views']:
                f.write(f"-- View: {view['name']}\n")
                
                if target_engine == source_engine:
                    # Jeśli silniki są takie same, możemy użyć oryginalnego SQL
                    f.write(f"{view['sql']};\n\n")
                else:
                    # W przeciwnym razie dodajemy komentarz
                    f.write(f"-- Original view definition (may need adaptation for {target_engine}):\n")
                    f.write(f"-- {view['sql']}\n\n")
            
            f.write("-- End of schema\n")
        
        return True, f"Schemat wyeksportowany do pliku {output_file}"
        
    except Exception as e:
        return False, f"Błąd podczas eksportu schematu: {str(e)}"

import psutil
import platform
import os
import json
from datetime import datetime
from app.models.system_info import SystemInfo
from app.utils.logger import log_activity

class SystemMonitor:
    @staticmethod
    def collect_metrics():
        """Collect current system metrics"""
        metrics = {
            'timestamp': datetime.utcnow().isoformat(),
            'cpu': {
                'percent': psutil.cpu_percent(interval=1),
                'cores': psutil.cpu_count(),
                'physical_cores': psutil.cpu_count(logical=False)
            },
            'memory': {
                'total': psutil.virtual_memory().total,
                'available': psutil.virtual_memory().available,
                'percent': psutil.virtual_memory().percent
            },
            'disk': {
                'total': psutil.disk_usage('/').total,
                'used': psutil.disk_usage('/').used,
                'free': psutil.disk_usage('/').free,
                'percent': psutil.disk_usage('/').percent
            }
        }
        
        # Save metrics to database
        SystemInfo.set('system_metrics', json.dumps(metrics))
        
        # Log if resources are running low
        if metrics['cpu']['percent'] > 90:
            log_activity('system_alert', 'High CPU usage detected', severity='WARNING')
        if metrics['memory']['percent'] > 90:
            log_activity('system_alert', 'High memory usage detected', severity='WARNING')
        if metrics['disk']['percent'] > 90:
            log_activity('system_alert', 'Low disk space detected', severity='WARNING')
            
        return metrics

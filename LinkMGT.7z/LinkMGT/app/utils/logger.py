from flask import request, current_app
from flask_login import current_user
import logging
from logging.handlers import RotatingFileHandler
import os
import traceback
from datetime import datetime
from sqlalchemy.exc import ProgrammingError, OperationalError

# Konfiguracja loggera Pythona
logger = logging.getLogger('linkmgt')

def setup_logger(app):
    """Setup application logger"""
    # Create logs directory if it doesn't exist
    log_dir = os.path.join(app.root_path, '..', 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Configure file logger
    log_file = os.path.join(log_dir, 'linkmgt.log')
    file_handler = RotatingFileHandler(log_file, maxBytes=10485760, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    ))
    file_handler.setLevel(logging.INFO)
    
    # Configure Flask logger
    app.logger.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    
    # Log application startup
    app.logger.info(f"Logger initialized at {datetime.now()} with level {logging.getLevelName(app.logger.level)}")
    return app.logger

def log_activity(action, details=None, severity='INFO', user_id=None, module=None):
    """Log activity with proper type handling"""
    try:
        from flask import request
        from flask_login import current_user
        from app.models.activity_log import ActivityLog
        from app import db
        
        # Ensure user_id is an integer or None
        if isinstance(user_id, str):
            user_id = None
        elif user_id is None and not current_user.is_anonymous:
            user_id = current_user.id
            
        log = ActivityLog(
            timestamp=datetime.utcnow(),
            user_id=user_id,
            action=action,
            details=str(details) if details else None,
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string if request.user_agent else None,
            module=module,
            severity=severity,
            status=200,
            request_path=request.path,
            request_method=request.method
        )
        
        db.session.add(log)
        db.session.commit()
        
    except Exception as e:
        current_app.logger.error(f"Error saving activity log: {str(e)}")
        return None

    try:
        # Log to database if possible
        try:
            from app.models.activity_log import ActivityLog
            ActivityLog.log(action, details, severity, user_id)
        except Exception as e:
            current_app.logger.error(f"Failed to log to database: {e}")
        
        # Log to application log
        user_info = ""
        if current_user and current_user.is_authenticated:
            user_info = f"User: {current_user.username} (ID: {current_user.id})"
        elif user_id:
            user_info = f"User ID: {user_id}"
        else:
            user_info = "User: Anonymous"
        
        ip_info = f"IP: {request.remote_addr}" if request else ""
        
        log_message = f"[{action}] {user_info} {ip_info} - {details}"
        
        if severity == 'INFO':
            current_app.logger.info(log_message)
        elif severity == 'WARNING':
            current_app.logger.warning(log_message)
        elif severity == 'ERROR':
            current_app.logger.error(log_message)
        elif severity == 'CRITICAL':
            current_app.logger.critical(log_message)
        else:
            current_app.logger.info(log_message)
            
    except Exception as e:
        # Last resort logging to stderr
        print(f"Error in log_activity: {e}")
        traceback.print_exc()

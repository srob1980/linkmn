import os
import platform
import psutil
from datetime import datetime

def get_system_resources():
    """Get current system resource usage"""
    cpu_info = get_cpu_info()
    memory_info = get_memory_info()
    disk_info = get_disk_info()
    
    return {
        'cpu': cpu_info,
        'memory': memory_info,
        'disk': disk_info
    }

def get_cpu_info():
    """Get CPU information and usage"""
    try:
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        cpu_count_physical = psutil.cpu_count(logical=False)
        
        # Get CPU load averages on Unix systems
        if hasattr(os, 'getloadavg'):
            load_avg = os.getloadavg()
        else:
            load_avg = None
        
        return {
            'usage_percent': cpu_percent,
            'count': cpu_count,
            'physical_count': cpu_count_physical,
            'load_avg': load_avg
        }
    except Exception as e:
        print(f"Error getting CPU info: {e}")
        return {
            'usage_percent': 0,
            'count': 0,
            'physical_count': 0,
            'load_avg': None
        }

def get_memory_info():
    """Get memory usage information"""
    try:
        memory = psutil.virtual_memory()
        
        # Convert to GB with 2 decimal places
        total_gb = round(memory.total / (1024**3), 2)
        used_gb = round((memory.total - memory.available) / (1024**3), 2)
        available_gb = round(memory.available / (1024**3), 2)
        
        return {
            'total': memory.total,
            'available': memory.available,
            'percent': memory.percent,
            'used': memory.used,
            'total_gb': total_gb,
            'used_gb': used_gb,
            'available_gb': available_gb
        }
    except Exception as e:
        print(f"Error getting memory info: {e}")
        return {
            'total': 0,
            'available': 0,
            'percent': 0,
            'used': 0,
            'total_gb': 0,
            'used_gb': 0,
            'available_gb': 0
        }

def get_disk_info(path='/'):
    """Get disk usage information"""
    try:
        disk = psutil.disk_usage(path)
        
        # Convert to GB with 2 decimal places
        total_gb = round(disk.total / (1024**3), 2)
        used_gb = round(disk.used / (1024**3), 2)
        free_gb = round(disk.free / (1024**3), 2)
        
        return {
            'total': disk.total,
            'used': disk.used,
            'free': disk.free,
            'percent': disk.percent,
            'total_gb': total_gb,
            'used_gb': used_gb,
            'free_gb': free_gb
        }
    except Exception as e:
        print(f"Error getting disk info: {e}")
        return {
            'total': 0,
            'used': 0,
            'free': 0,
            'percent': 0,
            'total_gb': 0,
            'used_gb': 0,
            'free_gb': 0
        }

def get_system_info():
    """Get detailed system information"""
    return {
        'system': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'platform': platform.platform(),
        'python_version': platform.python_version(),
        'node': platform.node(),
        'architecture': platform.architecture()
    }

import os
import json
from app.models.config import AppConfig
from app import db

class ConfigManager:
    @staticmethod
    def update_database_settings(settings):
        """Update database connection settings"""
        for key, value in settings.items():
            AppConfig.set_value(
                key=f'DB_{key.upper()}',
                value=value,
                category='database',
                description='Database connection setting'
            )

    @staticmethod
    def update_ssl_settings(cert_file=None, key_file=None):
        """Update SSL certificate settings"""
        ssl_dir = 'ssl'
        if not os.path.exists(ssl_dir):
            os.makedirs(ssl_dir)

        if cert_file:
            cert_path = os.path.join(ssl_dir, 'cert.pem')
            cert_file.save(cert_path)
            AppConfig.set_value('SSL_CERT', cert_path, category='ssl')

        if key_file:
            key_path = os.path.join(ssl_dir, 'key.pem')
            key_file.save(key_path)
            AppConfig.set_value('SSL_KEY', key_path, category='ssl')

    @staticmethod
    def update_ad_settings(settings):
        """Update Active Directory settings"""
        for key, value in settings.items():
            AppConfig.set_value(
                key=f'AD_{key.upper()}',
                value=value,
                category='active_directory',
                description='Active Directory setting'
            )

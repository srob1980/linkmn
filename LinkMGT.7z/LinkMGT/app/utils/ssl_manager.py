import os
import shutil
from datetime import datetime
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

class SSLManager:
    def __init__(self, ssl_dir='ssl'):
        self.ssl_dir = ssl_dir
        if not os.path.exists(ssl_dir):
            os.makedirs(ssl_dir)

    def save_certificate(self, cert_file, cert_type='cert'):
        """Save uploaded certificate"""
        if not cert_file:
            return False, "No file provided"
            
        filename = f"{cert_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pem"
        filepath = os.path.join(self.ssl_dir, filename)
        
        try:
            # Save file
            cert_file.save(filepath)
            
            # Verify certificate format
            if cert_type == 'cert':
                with open(filepath, 'rb') as f:
                    x509.load_pem_x509_certificate(f.read(), default_backend())
            elif cert_type == 'key':
                with open(filepath, 'rb') as f:
                    serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())
                    
            return True, filename
            
        except Exception as e:
            if os.path.exists(filepath):
                os.remove(filepath)
            return False, str(e)
            
    def get_certificate_info(self, filename):
        """Get certificate information"""
        filepath = os.path.join(self.ssl_dir, filename)
        if not os.path.exists(filepath):
            return None
            
        try:
            with open(filepath, 'rb') as f:
                cert = x509.load_pem_x509_certificate(f.read(), default_backend())
                
            return {
                'subject': cert.subject.rfc4514_string(),
                'issuer': cert.issuer.rfc4514_string(),
                'valid_from': cert.not_valid_before,
                'valid_until': cert.not_valid_after,
                'serial_number': cert.serial_number,
                'version': cert.version
            }
        except:
            return None

    def delete_certificate(self, filename):
        """Delete certificate file"""
        filepath = os.path.join(self.ssl_dir, filename)
        if os.path.exists(filepath):
            os.remove(filepath)
            return True
        return False

"""
Narzędzia do zarządzania bazami danych.
"""
import os
import sys
import importlib.util
import shutil
import subprocess
import json
import tempfile
import time
from datetime import datetime
from urllib.parse import urlparse
from sqlalchemy import create_engine, text

# Try to import psutil, but don't fail if it's not available
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("Warning: psutil module not available. System resource monitoring will be limited.")

def test_connection(db_url):
    """Test database connection with provided URL"""
    if not db_url:
        return False, "Nie podano URL bazy danych"
    
    try:
        # SQLite connection test
        if db_url.startswith('sqlite:///'):
            import sqlite3
            db_path = db_url.replace('sqlite:///', '')
            
            if not os.path.isabs(db_path):
                # Jeśli ścieżka jest względna, traktujemy ją jako względną do katalogu aplikacji
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

                db_path = os.path.join(base_dir, db_path)
            
            # Sprawdź czy katalog istnieje
            db_dir = os.path.dirname(db_path)
            if db_dir and not os.path.exists(db_dir):
                try:
                    os.makedirs(db_dir, exist_ok=True)
                except Exception as e:
                    return False, f"Nie można utworzyć katalogu dla bazy SQLite: {str(e)}"
            
            # Testuj połączenie
            conn = sqlite3.connect(db_path)
            conn.execute('SELECT 1')
            conn.close()
            return True, "Połączenie z bazą SQLite udane"
        
        # PostgreSQL connection test
        elif db_url.startswith('postgresql://'):
            try:
                import psycopg2
                
                # Parse URL
                parsed = urlparse(db_url)
                dbname = parsed.path.strip('/')
                user = parsed.username
                password = parsed.password
                host = parsed.hostname
                port = parsed.port or 5432
                
                # Connect
                conn = psycopg2.connect(
                    dbname=dbname,
                    user=user,
                    password=password,
                    host=host,
                    port=port,
                    connect_timeout=3
                )
                cursor = conn.cursor()
                cursor.execute('SELECT 1')
                cursor.close()
                conn.close()
                return True, "Połączenie z bazą PostgreSQL udane"
            except ImportError:
                return False, "Brak modułu psycopg2 - zainstaluj go używając: pip install psycopg2-binary"
        
        # MySQL/MariaDB connection test
        elif db_url.startswith('mysql://') or db_url.startswith('mariadb://'):
            try:
                import pymysql
                
                # Parse URL
                parsed = urlparse(db_url)
                database = parsed.path.strip('/')
                user = parsed.username
                password = parsed.password
                host = parsed.hostname
                port = parsed.port or 3306
                
                # Connect
                conn = pymysql.connect(
                    database=database,
                    user=user,
                    password=password,
                    host=host,
                    port=port,
                    connect_timeout=3
                )
                cursor = conn.cursor()
                cursor.execute('SELECT 1')
                cursor.close()
                conn.close()
                return True, "Połączenie z bazą MySQL/MariaDB udane"
            except ImportError:
                return False, "Brak modułu pymysql - zainstaluj go używając: pip install pymysql"
        
        # Oracle connection test
        elif db_url.startswith('oracle://'):
            # Parse URL
            parsed = urlparse(db_url)
            dsn = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 1521
            
            # Check if thick mode is enabled
            thick_mode = False
            if parsed.query:
                from urllib.parse import parse_qs
                params = parse_qs(parsed.query)
                thick_mode = params.get('thick_mode', ['false'])[0].lower() in ('true', '1', 't')
            
            # Try oracledb first (newer API)
            try:
                import oracledb
                
                if thick_mode:
                    try:
                        oracledb.init_oracle_client()
                    except Exception as e:
                        return False, f"Nie można zainicjować klienta Oracle w trybie thick: {str(e)}"
                
                conn = oracledb.connect(
                    user=user,
                    password=password,
                    dsn=f"{host}:{port}/{dsn}"
                )
                cursor = conn.cursor()
                cursor.execute('SELECT 1 FROM DUAL')
                cursor.close()
                conn.close()
                return True, "Połączenie z bazą Oracle udane"
            
            except ImportError:
                # Fall back to cx_Oracle
                try:
                    import cx_Oracle
                    
                    conn = cx_Oracle.connect(
                        user=user,
                        password=password,
                        dsn=f"{host}:{port}/{dsn}"
                    )
                    cursor = conn.cursor()
                    cursor.execute('SELECT 1 FROM DUAL')
                    cursor.close()
                    conn.close()
                    return True, "Połączenie z bazą Oracle udane (używając cx_Oracle)"
                
                except ImportError:
                    return False, "Brak zainstalowanych sterowników Oracle (oracledb lub cx_Oracle)"
                except Exception as e:
                    return False, f"Błąd połączenia z Oracle: {str(e)}"
        
        else:
            return False, f"Nieobsługiwany typ bazy danych: {db_url.split('://')[0]}"
    
    except ImportError as e:
        return False, f"Brak wymaganego modułu bazy danych: {str(e)}"
    except Exception as e:
        return False, f"Błąd połączenia: {str(e)}"

def create_backup(db_url, backup_dir, backup_name=None):
    """Create a database backup"""
    if not os.path.exists(backup_dir):
        try:
            os.makedirs(backup_dir, exist_ok=True)
        except Exception as e:
            return False, f"Nie można utworzyć katalogu kopii zapasowych: {str(e)}"
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = backup_name or f"backup_{timestamp}"
    
    try:
        # SQLite backup
        if db_url.startswith('sqlite:///'):
            db_path = db_url.replace('sqlite:///', '')
            
            # Handle relative path
            if not os.path.isabs(db_path):
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

                db_path = os.path.join(base_dir, db_path)
            
            if not os.path.exists(db_path):
                return False, f"Plik bazy danych SQLite nie istnieje: {db_path}"
            
            backup_file = os.path.join(backup_dir, f"{backup_name}.db")
            shutil.copy2(db_path, backup_file)
            return True, backup_file
        
        # PostgreSQL backup
        elif db_url.startswith('postgresql://'):
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 5432
            
            backup_file = os.path.join(backup_dir, f"{backup_name}.sql")
            
            # Use pg_dump for backup
            env = os.environ.copy()
            env['PGPASSWORD'] = password
            
            cmd = [
                'pg_dump',
                '-h', host,
                '-p', str(port),
                '-U', user,
                '-F', 'c',  # Custom format
                '-b',       # Include large objects
                '-v',       # Verbose
                '-f', backup_file,
                dbname
            ]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env
            )
            
            stdout, stderr = process.communicate()
            
            if process.returncode != 0:
                return False, f"Błąd podczas tworzenia kopii zapasowej PostgreSQL: {stderr.decode('utf-8')}"
            
            return True, backup_file
        
        # MySQL/MariaDB backup
        elif db_url.startswith('mysql://') or db_url.startswith('mariadb://'):
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 3306
            
            backup_file = os.path.join(backup_dir, f"{backup_name}.sql")
            
            # Use mysqldump for backup
            cmd = [
                'mysqldump',
                f'--host={host}',
                f'--port={port}',
                f'--user={user}',
                f'--password={password}',
                '--single-transaction',
                '--routines',
                '--triggers',
                '--events',
                dbname
            ]
            
            with open(backup_file, 'w') as f:
                process = subprocess.Popen(
                    cmd,
                    stdout=f,
                    stderr=subprocess.PIPE
                )
                
                _, stderr = process.communicate()
                
                if process.returncode != 0:
                    return False, f"Błąd podczas tworzenia kopii zapasowej MySQL/MariaDB: {stderr.decode('utf-8')}"
            
            return True, backup_file
        
        # Oracle backup - simplistic approach using exp/expdp
        elif db_url.startswith('oracle://'):
            parsed = urlparse(db_url)
            sid = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 1521
            
            backup_dir_oracle = os.path.join(backup_dir, backup_name)
            os.makedirs(backup_dir_oracle, exist_ok=True)
            
            # Create parameter file
            param_file = os.path.join(backup_dir_oracle, 'exp.par')
            with open(param_file, 'w') as f:
                f.write(f"USERID={user}/{password}@{host}:{port}/{sid}\n")
                f.write(f"FILE={os.path.join(backup_dir_oracle, 'backup.dmp')}\n")
                f.write("FULL=y\n")
                f.write("STATISTICS=NONE\n")
            
            # Use exp/expdp for backup
            cmd = ['exp', 'parfile=' + param_file]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            stdout, stderr = process.communicate()
            
            # Remove parameter file with credentials
            if os.path.exists(param_file):
                os.remove(param_file)
            
            if process.returncode != 0:
                return False, f"Błąd podczas tworzenia kopii zapasowej Oracle: {stderr.decode('utf-8')}"
            
            return True, backup_dir_oracle
        
        else:
            return False, f"Nieobsługiwany typ bazy danych dla kopii zapasowej: {db_url.split('://')[0]}"
    
    except Exception as e:
        return False, f"Błąd podczas tworzenia kopii zapasowej: {str(e)}"

def restore_backup(db_url, backup_file):
    """Restore database from backup"""
    try:
        # SQLite restore
        if db_url.startswith('sqlite:///'):
            db_path = db_url.replace('sqlite:///', '')
            
            # Handle relative path
            if not os.path.isabs(db_path):
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

                db_path = os.path.join(base_dir, db_path)
            
            # Create a backup of the current database before restoring
            if os.path.exists(db_path):
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                backup_before_restore = f"{db_path}.{timestamp}.bak"
                shutil.copy2(db_path, backup_before_restore)
            
            # Restore from backup
            shutil.copy2(backup_file, db_path)
            return True, f"Baza danych przywrócona pomyślnie z {backup_file}"
        
        # PostgreSQL restore
        elif db_url.startswith('postgresql://'):
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 5432
            
            # Use pg_restore for restore
            env = os.environ.copy()
            env['PGPASSWORD'] = password
            
            cmd = [
                'pg_restore',
                '-h', host,
                '-p', str(port),
                '-U', user,
                '-d', dbname,
                '-v',       # Verbose
                '--clean',  # Clean (drop) database objects before recreating
                backup_file
            ]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env
            )
            
            stdout, stderr = process.communicate()
            
            if process.returncode != 0:
                return False, f"Błąd podczas przywracania bazy danych PostgreSQL: {stderr.decode('utf-8')}"
            
            return True, "Baza danych PostgreSQL przywrócona pomyślnie"
        
        # MySQL/MariaDB restore
        elif db_url.startswith('mysql://') or db_url.startswith('mariadb://'):
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 3306
            
            # Use mysql client for restore
            cmd = [
                'mysql',
                f'--host={host}',
                f'--port={port}',
                f'--user={user}',
                f'--password={password}',
                dbname
            ]
            
            with open(backup_file, 'r') as f:
                process = subprocess.Popen(
                    cmd,
                    stdin=f,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                
                stdout, stderr = process.communicate()
                
                if process.returncode != 0:
                    return False, f"Błąd podczas przywracania bazy MySQL/MariaDB: {stderr.decode('utf-8')}"
            
            return True, "Baza danych MySQL/MariaDB przywrócona pomyślnie"
        
        # Oracle restore - simplistic approach using imp/impdp
        elif db_url.startswith('oracle://'):
            parsed = urlparse(db_url)
            sid = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 1521
            
            # Assume backup_file is directory with Oracle backup
            dump_file = os.path.join(backup_file, 'backup.dmp')
            if not os.path.exists(dump_file):
                return False, f"Plik kopii zapasowej Oracle nie istnieje: {dump_file}"
            
            # Create parameter file
            param_file = os.path.join(backup_file, 'imp.par')
            with open(param_file, 'w') as f:
                f.write(f"USERID={user}/{password}@{host}:{port}/{sid}\n")
                f.write(f"FILE={dump_file}\n")
                f.write("FULL=y\n")
                f.write("IGNORE=y\n")
            
            # Use imp/impdp for restore
            cmd = ['imp', 'parfile=' + param_file]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            stdout, stderr = process.communicate()
            
            # Remove parameter file with credentials
            if os.path.exists(param_file):
                os.remove(param_file)
            
            if process.returncode != 0:
                return False, f"Błąd podczas przywracania bazy Oracle: {stderr.decode('utf-8')}"
            
            return True, "Baza danych Oracle przywrócona pomyślnie"
        
        else:
            return False, f"Nieobsługiwany typ bazy danych dla przywracania: {db_url.split('://')[0]}"
    
    except Exception as e:
        return False, f"Błąd podczas przywracania bazy danych: {str(e)}"

def get_database_info(db_url):
    """Get database information"""
    info = {
        'engine': 'Nieznany',
        'version': 'Nieznana',
        'connected': False
    }
    
    if not db_url:
        info['error'] = 'Nie podano URL bazy danych'
        return info
    
    # Basic info from URL
    info['engine'] = db_url.split('://')[0]
    
    # Get detailed information based on database type
    try:
        if db_url.startswith('sqlite:///'):
            import sqlite3
            
            db_path = db_url.replace('sqlite:///', '')
            
            # Handle relative path
            if not os.path.isabs(db_path):
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

                db_path = os.path.join(base_dir, db_path)
            
            if not os.path.exists(db_path):
                info['error'] = f"Plik bazy danych nie istnieje: {db_path}"
                return info
            
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT sqlite_version()')
            info['version'] = cursor.fetchone()[0]
            
            # Get table count
            cursor.execute("SELECT count(*) FROM sqlite_master WHERE type='table'")
            info['tables'] = cursor.fetchone()[0]
            
            # Get size
            info['size'] = f"{os.path.getsize(db_path) / (1024*1024):.2f} MB"
            
            # Get table info
            cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name")
            tables = cursor.fetchall()
            
            info['table_list'] = []
            for table_name, table_sql in tables:
                # Get row count for each table
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM '{table_name}'")
                    row_count = cursor.fetchone()[0]
                except sqlite3.OperationalError:
                    row_count = "N/A"
                
                info['table_list'].append({
                    'name': table_name,
                    'row_count': row_count,
                    'creation_sql': table_sql
                })
            
            info['connected'] = True
            conn.close()
        
        elif db_url.startswith('postgresql://'):
            import psycopg2
            
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 5432
            
            conn = psycopg2.connect(
                dbname=dbname,
                user=user,
                password=password,
                host=host,
                port=port,
                connect_timeout=3
            )
            
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT version()')
            info['version'] = cursor.fetchone()[0]
            
            # Get database size
            cursor.execute("""
                SELECT pg_size_pretty(pg_database_size(current_database()))
            """)
            info['size'] = cursor.fetchone()[0]
            
            # Get table count
            cursor.execute("""
                SELECT count(*)
                FROM information_schema.tables
                WHERE table_schema = 'public'
            """)
            info['tables'] = cursor.fetchone()[0]
            
            # Get table information
            cursor.execute("""
                SELECT 
                    table_name,
                    (SELECT count(*) FROM information_schema.columns WHERE table_name = t.table_name) as column_count
                FROM information_schema.tables t
                WHERE table_schema = 'public'
                ORDER BY table_name
            """)
            
            tables = cursor.fetchall()
            info['table_list'] = []
            
            for table_name, column_count in tables:
                # Get row count
                cursor.execute(f"SELECT COUNT(*) FROM \"{table_name}\"")
                row_count = cursor.fetchone()[0]
                
                # Get table size
                cursor.execute(f"""
                    SELECT pg_size_pretty(pg_total_relation_size('{table_name}'::regclass))
                """)
                table_size = cursor.fetchone()[0]
                
                info['table_list'].append({
                    'name': table_name,
                    'row_count': row_count,
                    'column_count': column_count,
                    'size': table_size
                })
            
            # Get index information
            cursor.execute("""
                SELECT
                    indexname,
                    tablename,
                    indexdef
                FROM pg_indexes
                WHERE schemaname = 'public'
                ORDER BY tablename, indexname
            """)
            
            indexes = cursor.fetchall()
            info['indexes'] = []
            
            for index_name, table_name, index_def in indexes:
                info['indexes'].append({
                    'name': index_name,
                    'table': table_name,
                    'definition': index_def
                })
            
            info['connected'] = True
            cursor.close()
            conn.close()
        
        elif db_url.startswith('mysql://') or db_url.startswith('mariadb://'):
            import pymysql
            
            parsed = urlparse(db_url)
            database = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 3306
            
            conn = pymysql.connect(
                database=database,
                user=user,
                password=password,
                host=host,
                port=port,
                connect_timeout=3
            )
            
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT VERSION()')
            info['version'] = cursor.fetchone()[0]
            
            # Get table count
            cursor.execute("""
                SELECT COUNT(*)
                FROM information_schema.tables
                WHERE table_schema = %s
            """, (database,))
            info['tables'] = cursor.fetchone()[0]
            
            # Get database size
            cursor.execute("""
                SELECT 
                    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) 
                FROM information_schema.tables
                WHERE table_schema = %s
            """, (database,))
            size_mb = cursor.fetchone()[0] or 0
            info['size'] = f"{size_mb} MB"
            
            # Get table information
            cursor.execute("""
                SELECT 
                    table_name,
                    table_rows,
                    ROUND((data_length + index_length) / 1024 / 1024, 2) AS size_mb,
                    (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = t.table_schema AND table_name = t.table_name) AS column_count
                FROM information_schema.tables t
                WHERE table_schema = %s
                ORDER BY table_name
            """, (database,))
            
            tables = cursor.fetchall()
            info['table_list'] = []
            
            for table_name, row_count, size_mb, column_count in tables:
                info['table_list'].append({
                    'name': table_name,
                    'row_count': row_count or 'N/A',
                    'size': f"{size_mb} MB",
                    'column_count': column_count
                })
            
            # Get index information
            cursor.execute("""
                SELECT
                    table_name,
                    index_name,
                    GROUP_CONCAT(column_name ORDER BY seq_in_index) AS columns,
                    non_unique
                FROM information_schema.statistics
                WHERE table_schema = %s
                GROUP BY table_name, index_name
                ORDER BY table_name, index_name
            """, (database,))
            
            indexes = cursor.fetchall()
            info['indexes'] = []
            
            for table_name, index_name, columns, non_unique in indexes:
                info['indexes'].append({
                    'name': index_name,
                    'table': table_name,
                    'columns': columns,
                    'unique': not non_unique
                })
            
            info['connected'] = True
            cursor.close()
            conn.close()
        
        elif db_url.startswith('oracle://'):
            try:
                import oracledb
                driver = 'oracledb'
            except ImportError:
                import cx_Oracle
                driver = 'cx_Oracle'
            
            parsed = urlparse(db_url)
            dsn = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 1521
            
            # Check if thick mode is enabled
            thick_mode = False
            if parsed.query:
                params = parse_qs(parsed.query)
                thick_mode = params.get('thick_mode', ['false'])[0].lower() in ('true', '1', 't')
            
            # Connect to Oracle
            if driver == 'oracledb':
                if thick_mode:
                    oracledb.init_oracle_client()
                conn = oracledb.connect(
                    user=user,
                    password=password,
                    dsn=f"{host}:{port}/{dsn}"
                )
            else:
                conn = cx_Oracle.connect(
                    user=user,
                    password=password,
                    dsn=f"{host}:{port}/{dsn}"
                )
            
            cursor = conn.cursor()
            
            # Get version
            cursor.execute('SELECT banner FROM v$version WHERE banner LIKE \'Oracle%\'')
            info['version'] = cursor.fetchone()[0]
            
            # Get database size (approximate)
            cursor.execute("""
                SELECT ROUND(SUM(bytes)/1024/1024/1024, 2) FROM dba_data_files
            """)
            try:
                size_gb = cursor.fetchone()[0] or 0
                info['size'] = f"{size_gb} GB"
            except:
                # User might not have DBA privileges
                info['size'] = "Wymaga uprawnień DBA"
            
            # Get table count
            cursor.execute("""
                SELECT COUNT(*) FROM user_tables
            """)
            info['tables'] = cursor.fetchone()[0]
            
            # Get table information
            cursor.execute("""
                SELECT table_name FROM user_tables ORDER BY table_name
            """)
            
            tables = cursor.fetchall()
            info['table_list'] = []
            
            for (table_name,) in tables:
                # Get row count
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    row_count = cursor.fetchone()[0]
                except:
                    row_count = "N/A"
                
                # Get column count
                cursor.execute(f"""
                    SELECT COUNT(*) FROM user_tab_columns WHERE table_name = '{table_name}'
                """)
                column_count = cursor.fetchone()[0]
                
                info['table_list'].append({
                    'name': table_name,
                    'row_count': row_count,
                    'column_count': column_count
                })
            
            info['connected'] = True
            cursor.close()
            conn.close()
        
        else:
            info['error'] = f"Nieobsługiwany typ bazy danych: {info['engine']}"
        
    except Exception as e:
        info['error'] = f"Błąd podczas uzyskiwania informacji: {str(e)}"
    
    return info

def get_database_stats(db_url):
    """Get database performance statistics"""
    stats = {
        'engine': db_url.split('://')[0] if db_url else 'unknown',
        'connections': 0,
        'queries_per_second': 0,
        'slow_queries': 0,
        'uptime': 'N/A',
        'memory_usage': 'N/A'
    }
    
    try:
        if db_url.startswith('postgresql://'):
            import psycopg2
            
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 5432
            
            conn = psycopg2.connect(
                dbname=dbname,
                user=user,
                password=password,
                host=host,
                port=port,
                connect_timeout=3
            )
            
            cursor = conn.cursor()
            
            # Get active connections
            cursor.execute("""
                SELECT count(*) FROM pg_stat_activity
            """)
            stats['connections'] = cursor.fetchone()[0]
            
            # Get database stats
            cursor.execute("""
                SELECT 
                    pg_stat_reset_time() as reset_time,
                    (SELECT sum(numbackends) FROM pg_stat_database) as connections,
                    (SELECT sum(xact_commit + xact_rollback) FROM pg_stat_database) as transactions,
                    (SELECT sum(blks_read) FROM pg_stat_database) as disk_reads,
                    (SELECT sum(blks_hit) FROM pg_stat_database) as buffer_hits
            """)
            
            reset_time, conn_count, transactions, disk_reads, buffer_hits = cursor.fetchone()
            
            stats['connections'] = conn_count
            stats['transactions'] = transactions
            stats['disk_reads'] = disk_reads
            stats['buffer_hits'] = buffer_hits
            stats['cache_hit_ratio'] = f"{buffer_hits * 100 / (buffer_hits + disk_reads):.2f}%" if (buffer_hits + disk_reads) > 0 else "N/A"
            
            # Get slow queries
            cursor.execute("""
                SELECT count(*) 
                FROM pg_stat_activity 
                WHERE state = 'active' 
                AND (now() - query_start) > interval '5 seconds'
            """)
            stats['slow_queries'] = cursor.fetchone()[0]
            
            # Get uptime
            cursor.execute("SELECT date_trunc('second', current_timestamp - pg_postmaster_start_time())")
            stats['uptime'] = str(cursor.fetchone()[0])
            
            # Get index usage statistics
            cursor.execute("""
                SELECT 
                    relname, 
                    idx_scan as index_scans,
                    seq_scan as sequential_scans,
                    idx_tup_read as tuples_read_by_index,
                    seq_tup_read as tuples_read_sequentially,
                    n_tup_ins as tuples_inserted,
                    n_tup_upd as tuples_updated,
                    n_tup_del as tuples_deleted
                FROM pg_stat_user_tables 
                ORDER BY (idx_scan+seq_scan) DESC
                LIMIT 10
            """)
            
            table_stats = []
            for row in cursor.fetchall():
                table_stats.append({
                    'table': row[0],
                    'index_scans': row[1],
                    'seq_scans': row[2],
                    'idx_reads': row[3],
                    'seq_reads': row[4],
                    'inserts': row[5],
                    'updates': row[6],
                    'deletes': row[7]
                })
            
            stats['table_stats'] = table_stats
            
            # Get unused indexes
            cursor.execute("""
                SELECT
                    s.schemaname,
                    s.relname AS tablename,
                    s.indexrelname AS indexname,
                    pg_relation_size(s.indexrelid) as index_size
                FROM pg_catalog.pg_stat_user_indexes s
                JOIN pg_catalog.pg_index i ON s.indexrelid = i.indexrelid
                WHERE s.idx_scan = 0      -- has never been scanned
                AND 0 <> ALL(i.indkey)    -- no index column is an expression
                AND NOT i.indisunique     -- is not a UNIQUE index
                AND NOT EXISTS           -- does not enforce a constraint
                    (SELECT 1 FROM pg_catalog.pg_constraint c 
                     WHERE c.conindid = s.indexrelid)
                ORDER BY pg_relation_size(s.indexrelid) DESC
                LIMIT 10
            """)
            
            unused_indexes = []
            for schema, table, index, size in cursor.fetchall():
                unused_indexes.append({
                    'schema': schema,
                    'table': table,
                    'index': index,
                    'size': f"{size / (1024*1024):.2f} MB"
                })
            
            stats['unused_indexes'] = unused_indexes
            
            cursor.close()
            conn.close()
        
        elif db_url.startswith('mysql://') or db_url.startswith('mariadb://'):
            import pymysql
            
            parsed = urlparse(db_url)
            database = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 3306
            
            conn = pymysql.connect(
                database=database,
                user=user,
                password=password,
                host=host,
                port=port,
                connect_timeout=3
            )
            
            cursor = conn.cursor()
            
            # Get global status
            cursor.execute("SHOW GLOBAL STATUS")
            global_status = {}
            for name, value in cursor.fetchall():
                global_status[name] = value
            
            # Active connections
            stats['connections'] = global_status.get('Threads_connected', 0)
            
            # Queries per second (approximate)
            stats['queries'] = global_status.get('Questions', 0)
            
            # Slow queries
            stats['slow_queries'] = global_status.get('Slow_queries', 0)
            
            # Uptime
            uptime_seconds = int(global_status.get('Uptime', 0))
            days, remainder = divmod(uptime_seconds, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            stats['uptime'] = f"{days}d {hours}h {minutes}m {seconds}s"
            
            # Get table statistics
            cursor.execute("""
                SELECT 
                    table_name,
                    table_rows,
                    data_length,
                    index_length,
                    create_time,
                    update_time
                FROM information_schema.tables
                WHERE table_schema = %s
                ORDER BY data_length + index_length DESC
                LIMIT 10
            """, (database,))
            
            table_stats = []
            for name, rows, data_len, idx_len, created, updated in cursor.fetchall():
                table_stats.append({
                    'table': name,
                    'rows': rows,
                    'data_size': f"{data_len / (1024*1024):.2f} MB",
                    'index_size': f"{idx_len / (1024*1024):.2f} MB",
                    'created': created.strftime('%Y-%m-%d %H:%M:%S') if created else 'N/A',
                    'updated': updated.strftime('%Y-%m-%d %H:%M:%S') if updated else 'N/A'
                })
            
            stats['table_stats'] = table_stats
            
            # Get index statistics if available
            try:
                cursor.execute("""
                    SELECT 
                        t.name AS table_name,
                        s.index_name,
                        s.rows_read,
                        s.rows_inserted,
                        s.rows_updated,
                        s.rows_deleted
                    FROM performance_schema.table_io_waits_summary_by_index_usage s
                    JOIN performance_schema.tables t ON s.object_schema = t.table_schema AND s.object_name = t.table_name
                    WHERE t.table_schema = %s
                    ORDER BY s.rows_read DESC
                    LIMIT 10
                """, (database,))
                
                index_stats = []
                for table, index, reads, inserts, updates, deletes in cursor.fetchall():
                    index_stats.append({
                        'table': table,
                        'index': index,
                        'reads': reads,
                        'inserts': inserts,
                        'updates': updates,
                        'deletes': deletes
                    })
                
                stats['index_stats'] = index_stats
            except:
                # Performance schema might not be enabled
                pass
            
            cursor.close()
            conn.close()
        
        elif db_url.startswith('sqlite:///'):
            # SQLite doesn't have built-in performance stats
            # We can only provide some basic file information
            
            db_path = db_url.replace('sqlite:///', '')
            
            # Handle relative path
            if not os.path.isabs(db_path):
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

                db_path = os.path.join(base_dir, db_path)
            
            import sqlite3
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get statistics from sqlite_stat tables if available
            try:
                cursor.execute("SELECT * FROM sqlite_stat1 LIMIT 1")
                has_stats = True
            except sqlite3.OperationalError:
                has_stats = False
            
            if has_stats:
                cursor.execute("""
                    SELECT tbl, idx, stat FROM sqlite_stat1
                    ORDER BY tbl, idx
                """)
                
                index_stats = []
                for table, index, stat_info in cursor.fetchall():
                    index_stats.append({
                        'table': table,
                        'index': index,
                        'stats': stat_info
                    })
                
                stats['index_stats'] = index_stats
            
            # Get file metadata
            stats['file_size'] = f"{os.path.getsize(db_path) / (1024*1024):.2f} MB"
            stats['last_modified'] = datetime.fromtimestamp(os.path.getmtime(db_path)).strftime('%Y-%m-%d %H:%M:%S')
            
            # Get page count and size
            cursor.execute("PRAGMA page_count")
            page_count = cursor.fetchone()[0]
            
            cursor.execute("PRAGMA page_size")
            page_size = cursor.fetchone()[0]
            
            stats['page_count'] = page_count
            stats['page_size'] = f"{page_size / 1024:.2f} KB"
            
            # Get some database info
            cursor.execute("PRAGMA database_list")
            db_list = cursor.fetchall()
            stats['attached_databases'] = len(db_list)
            
            conn.close()
        
    except Exception as e:
        stats['error'] = str(e)
    
    return stats

def optimize_database(db_url):
    """Perform database optimization tasks"""
    result = {
        'success': False,
        'message': '',
        'operations': []
    }
    
    try:
        if db_url.startswith('sqlite:///'):
            db_path = db_url.replace('sqlite:///', '')
            
            # Handle relative path
            if not os.path.isabs(db_path):
                base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

                db_path = os.path.join(base_dir, db_path)
            
            import sqlite3
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Vacuum the database
            start_time = time.time()
            cursor.execute("VACUUM")
            vacuum_time = time.time() - start_time
            result['operations'].append({
                'operation': 'VACUUM',
                'duration': f"{vacuum_time:.2f} seconds",
                'status': 'success'
            })
            
            # Analyze the database
            start_time = time.time()
            cursor.execute("ANALYZE")
            analyze_time = time.time() - start_time
            result['operations'].append({
                'operation': 'ANALYZE',
                'duration': f"{analyze_time:.2f} seconds",
                'status': 'success'
            })
            
            # Get integrity check
            start_time = time.time()
            cursor.execute("PRAGMA integrity_check")
            integrity = cursor.fetchone()[0]
            integrity_time = time.time() - start_time
            result['operations'].append({
                'operation': 'INTEGRITY CHECK',
                'result': integrity,
                'duration': f"{integrity_time:.2f} seconds",
                'status': 'success' if integrity == 'ok' else 'warning'
            })
            
            conn.close()
            
            result['success'] = True
            result['message'] = 'Optymalizacja bazy SQLite zakończona pomyślnie'
        
        elif db_url.startswith('postgresql://'):
            import psycopg2
            
            parsed = urlparse(db_url)
            dbname = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 5432
            
            conn = psycopg2.connect(
                dbname=dbname,
                user=user,
                password=password,
                host=host,
                port=port,
                connect_timeout=3
            )
            
            cursor = conn.cursor()
            
            # Start transaction
            conn.autocommit = False
            
            # VACUUM ANALYZE
            try:
                # First VACUUM
                conn.autocommit = True  # VACUUM requires autocommit
                start_time = time.time()
                cursor.execute("VACUUM")
                vacuum_time = time.time() - start_time
                result['operations'].append({
                    'operation': 'VACUUM',
                    'duration': f"{vacuum_time:.2f} seconds",
                    'status': 'success'
                })
                conn.autocommit = False
            except Exception as e:
                result['operations'].append({
                    'operation': 'VACUUM',
                    'error': str(e),
                    'status': 'error'
                })
            
            # ANALYZE
            try:
                start_time = time.time()
                cursor.execute("ANALYZE")
                conn.commit()
                analyze_time = time.time() - start_time
                result['operations'].append({
                    'operation': 'ANALYZE',
                    'duration': f"{analyze_time:.2f} seconds",
                    'status': 'success'
                })
            except Exception as e:
                conn.rollback()
                result['operations'].append({
                    'operation': 'ANALYZE',
                    'error': str(e),
                    'status': 'error'
                })
            
            # REINDEX
            try:
                start_time = time.time()
                cursor.execute("REINDEX DATABASE %s", (dbname,))
                conn.commit()
                reindex_time = time.time() - start_time
                result['operations'].append({
                    'operation': 'REINDEX',
                    'duration': f"{reindex_time:.2f} seconds",
                    'status': 'success'
                })
            except Exception as e:
                conn.rollback()
                result['operations'].append({
                    'operation': 'REINDEX',
                    'error': str(e),
                    'status': 'error'
                })
            
            cursor.close()
            conn.close()
            
            result['success'] = True
            result['message'] = 'Optymalizacja bazy PostgreSQL zakończona pomyślnie'
        
        elif db_url.startswith('mysql://') or db_url.startswith('mariadb://'):
            import pymysql
            
            parsed = urlparse(db_url)
            database = parsed.path.strip('/')
            user = parsed.username
            password = parsed.password
            host = parsed.hostname
            port = parsed.port or 3306
            
            conn = pymysql.connect(
                database=database,
                user=user,
                password=password,
                host=host,
                port=port,
                connect_timeout=3
            )
            
            cursor = conn.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = %s
            """, (database,))
            
            tables = cursor.fetchall()
            
            # Optimize each table
            for (table_name,) in tables:
                try:
                    start_time = time.time()
                    cursor.execute(f"OPTIMIZE TABLE {table_name}")
                    optimize_result = cursor.fetchone()
                    optimize_time = time.time() - start_time
                    
                    result['operations'].append({
                        'operation': f"OPTIMIZE TABLE {table_name}",
                        'result': optimize_result[3] if optimize_result else 'Unknown',
                        'duration': f"{optimize_time:.2f} seconds",
                        'status': 'success' if optimize_result and optimize_result[3] == 'OK' else 'warning'
                    })
                except Exception as e:
                    result['operations'].append({
                        'operation': f"OPTIMIZE TABLE {table_name}",
                        'error': str(e),
                        'status': 'error'
                    })
            
            # Analyze each table
            for (table_name,) in tables:
                try:
                    start_time = time.time()
                    cursor.execute(f"ANALYZE TABLE {table_name}")
                    analyze_result = cursor.fetchone()
                    analyze_time = time.time() - start_time
                    
                    result['operations'].append({
                        'operation': f"ANALYZE TABLE {table_name}",
                        'result': analyze_result[3] if analyze_result else 'Unknown',
                        'duration': f"{analyze_time:.2f} seconds",
                        'status': 'success' if analyze_result and analyze_result[3] == 'OK' else 'warning'
                    })
                except Exception as e:
                    result['operations'].append({
                        'operation': f"ANALYZE TABLE {table_name}",
                        'error': str(e),
                        'status': 'error'
                    })
            
            cursor.close()
            conn.close()
            
            result['success'] = True
            result['message'] = 'Optymalizacja bazy MySQL/MariaDB zakończona pomyślnie'
        
        else:
            result['message'] = f"Nieobsługiwany typ bazy danych dla optymalizacji: {db_url.split('://')[0]}"
        
    except Exception as e:
        result['message'] = f"Błąd podczas optymalizacji bazy danych: {str(e)}"
    
    return result

def get_system_resources():
    """Get system resources information"""
    resources = {
        'cpu': {'usage_percent': 0},
        'memory': {'percent': 0, 'total_gb': 0, 'used_gb': 0},
        'disk': {'percent': 0, 'total_gb': 0, 'used_gb': 0},
    }
    
    try:
        if not PSUTIL_AVAILABLE:
            resources['error'] = "Module psutil not installed. Install with: pip install psutil"
            return resources
            
        # CPU information
        resources['cpu']['usage_percent'] = psutil.cpu_percent(interval=1)
        resources['cpu']['count'] = psutil.cpu_count(logical=True)
        resources['cpu']['physical_count'] = psutil.cpu_count(logical=False)
        resources['cpu']['load_avg'] = [round(x, 2) for x in os.getloadavg()] if hasattr(os, 'getloadavg') else []
        
        cpu_times = psutil.cpu_times_percent(interval=1)
        resources['cpu']['user'] = cpu_times.user
        resources['cpu']['system'] = cpu_times.system
        resources['cpu']['idle'] = cpu_times.idle
        
        # Memory information
        memory = psutil.virtual_memory()
        resources['memory']['total'] = memory.total
        resources['memory']['total_gb'] = round(memory.total / (1024**3), 2)
        resources['memory']['available'] = memory.available
        resources['memory']['available_gb'] = round(memory.available / (1024**3), 2)
        resources['memory']['used'] = memory.used
        resources['memory']['used_gb'] = round(memory.used / (1024**3), 2)
        resources['memory']['percent'] = memory.percent
        
        # Disk information
        disk = psutil.disk_usage('/')
        resources['disk']['total'] = disk.total
        resources['disk']['total_gb'] = round(disk.total / (1024**3), 2)
        resources['disk']['used'] = disk.used
        resources['disk']['used_gb'] = round(disk.used / (1024**3), 2)
        resources['disk']['free'] = disk.free
        resources['disk']['free_gb'] = round(disk.free / (1024**3), 2)
        resources['disk']['percent'] = disk.percent
        
    except Exception as e:
        resources['error'] = str(e)
    
    return resources

"""Database utility functions for LinkMGT"""

def test_connection(db_type, db_host=None, db_port=None, db_name=None, 
                   db_user=None, db_password=None, sqlite_path=None,
                   oracle_thick_mode=False):
    """Test connection to a database"""
    try:
        # Validate required parameters
        if db_type == 'sqlite':
            if not sqlite_path:
                return {'success': False, 'error': 'SQLite path is required'}
        else:
            if not all([db_host, db_name, db_user]):
                return {'success': False, 'error': 'Host, database name, and username are required'}
        
        # Check for required driver
        if db_type == 'postgresql':
            try:
                import psycopg2
            except ImportError:
                return {'success': False, 'error': 'PostgreSQL driver (psycopg2) is not installed'}
        elif db_type in ('mysql', 'mariadb'):
            try:
                import pymysql
            except ImportError:
                return {'success': False, 'error': 'MySQL/MariaDB driver (PyMySQL) is not installed'}
        elif db_type == 'oracle':
            oracle_available = False
            try:
                try:
                    import oracledb
                    oracle_available = True
                except ImportError:
                    try:
                        import cx_Oracle
                        oracle_available = True
                    except ImportError:
                        pass
            except Exception:
                pass
                
            if not oracle_available:
                return {'success': False, 'error': 'Oracle driver (oracledb or cx_Oracle) is not installed'}
        
        # Build connection URL
        if db_type == 'sqlite':
            # Clean up SQLite path
            if sqlite_path.startswith('sqlite:///'):
                connection_url = sqlite_path
            else:
                connection_url = f'sqlite:///{sqlite_path}'
        else:
            # Build connection URL for other database types
            if db_port:
                connection_url = f'{db_type}://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}'
            else:
                connection_url = f'{db_type}://{db_user}:{db_password}@{db_host}/{db_name}'
            
            # Add special parameters for Oracle
            if db_type == 'oracle' and oracle_thick_mode:
                connection_url += '?thick_mode=True'
        
        # Create engine
        engine_args = {}
        
        # Add special connection arguments based on database type
        if db_type == 'postgresql':
            engine_args['connect_args'] = {'connect_timeout': 5}
        elif db_type in ('mysql', 'mariadb'):
            engine_args['connect_args'] = {'connect_timeout': 5}
        elif db_type == 'oracle':
            engine_args['connect_args'] = {'timeout': 5}
        
        engine = create_engine(connection_url, **engine_args)
        
        # Test connection
        with engine.connect() as conn:
            # Execute a simple query
            result = conn.execute(text("SELECT 1"))
            one = result.scalar()
            
            if one != 1:
                return {'success': False, 'error': 'Connection test failed'}
            
            # Get database version if possible
            try:
                if db_type == 'postgresql':
                    version_query = text("SELECT version()")
                elif db_type in ('mysql', 'mariadb'):
                    version_query = text("SELECT VERSION()")
                elif db_type == 'oracle':
                    version_query = text("SELECT banner FROM v$version WHERE banner LIKE 'Oracle%'")
                elif db_type == 'sqlite':
                    version_query = text("SELECT sqlite_version()")
                else:
                    version_query = None
                
                if version_query:
                    version_result = conn.execute(version_query)
                    version = version_result.scalar()
                else:
                    version = "Unknown"
            except Exception:
                version = "Unknown"
        
        return {
            'success': True, 
            'message': f'Successfully connected to {db_type.upper()} database. Version: {version}'
        }
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

def get_db_info(db_url=None):
    """Get information about the database"""
    from flask import current_app
    import os
    
    if not db_url:
        db_url = current_app.config.get('SQLALCHEMY_DATABASE_URI')
    
    info = {
        'type': db_url.split('://')[0] if db_url else 'unknown',
        'engine': 'SQLAlchemy',
        'tables': []
    }
    
    try:
        # Get database connection details
        if info['type'] == 'sqlite':
            # Parse SQLite file path
            path = db_url.replace('sqlite:///', '')
            info['path'] = path
            
            # Get file size if available
            if os.path.exists(path):
                size_bytes = os.path.getsize(path)
                if size_bytes < 1024:
                    info['size'] = f"{size_bytes} B"
                elif size_bytes < 1024 * 1024:
                    info['size'] = f"{size_bytes / 1024:.1f} KB"
                else:
                    info['size'] = f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            # Parse other database connection URLs
            if '@' in db_url:
                auth_host, rest = db_url.split('@', 1)
                user_pass = auth_host.split('://', 1)[1]
                if ':' in user_pass:
                    info['user'], info['password'] = user_pass.split(':', 1)
                else:
                    info['user'] = user_pass
                
                if '/' in rest:
                    host_port, db_name = rest.split('/', 1)
                    info['name'] = db_name
                    
                    if ':' in host_port:
                        info['host'], info['port'] = host_port.split(':', 1)
                    else:
                        info['host'] = host_port
        
        # Get table list from database
        from sqlalchemy import inspect
        from flask import current_app
        
        with current_app.app_context():
            inspector = inspect(current_app.extensions['sqlalchemy'].db.engine)
            info['tables'] = inspector.get_table_names()
        
        return info
    except Exception as e:
        current_app.logger.error(f"Error getting database info: {e}")
        return info

import ldap
from flask import current_app
from app import db
from app.models.user import User
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class ADAuth:
    """Active Directory authentication and integration"""
    
    @staticmethod
    def get_ldap_connection():
        """Create LDAP connection with current config"""
        conn = ldap.initialize(current_app.config['AD_SERVER'])
        conn.protocol_version = 3
        conn.set_option(ldap.OPT_REFERRALS, 0)
        
        if current_app.config.get('AD_USE_TLS'):
            conn.start_tls_s()
            
        return conn
    
    @classmethod
    def authenticate(cls, username, password):
        """Authenticate user against AD"""
        try:
            conn = cls.get_ldap_connection()
            
            # Try to bind with service account first
            if current_app.config.get('AD_SERVICE_USER'):
                conn.simple_bind_s(
                    current_app.config['AD_SERVICE_USER'],
                    current_app.config['AD_SERVICE_PASSWORD']
                )
            
            # Search for user
            base_dn = current_app.config['AD_BASE_DN']
            search_filter = f"(sAMAccountName={username})"
            
            result = conn.search_s(base_dn, ldap.SCOPE_SUBTREE, search_filter)
            
            if not result:
                return None
                
            user_dn = result[0][0]
            
            # Try to bind as user
            try:
                conn.simple_bind_s(user_dn, password)
            except ldap.INVALID_CREDENTIALS:
                return None
            
            # Get user details
            attrs = result[0][1]
            
            # Create or update user
            user = User.query.filter_by(username=username).first()
            
            if user:
                user.email = attrs.get('mail', [b''])[0].decode()
                user.first_name = attrs.get('givenName', [b''])[0].decode()
                user.last_name = attrs.get('sn', [b''])[0].decode()
                user.ad_dn = user_dn
                user.last_login = datetime.utcnow()
            else:
                user = User(
                    username=username,
                    email=attrs.get('mail', [b''])[0].decode(),
                    first_name=attrs.get('givenName', [b''])[0].decode(),
                    last_name=attrs.get('sn', [b''])[0].decode(),
                    ad_dn=user_dn,
                    is_active=True
                )
                db.session.add(user)
            
            # Check if user is admin
            admin_group = current_app.config.get('AD_ADMIN_GROUP')
            if admin_group and cls.check_group_membership(user, [admin_group]):
                user.is_admin = True
            
            db.session.commit()
            return user
            
        except Exception as e:
            current_app.logger.error(f"AD authentication error: {str(e)}")
            return None
        finally:
            try:
                conn.unbind_s()
            except:
                pass
    
    @classmethod
    def check_group_membership(cls, user, groups):
        """Check if user is member of any of the given groups"""
        if not user.ad_dn:
            return False
            
        try:
            conn = cls.get_ldap_connection()
            
            # Bind with service account
            conn.simple_bind_s(
                current_app.config['AD_SERVICE_USER'],
                current_app.config['AD_SERVICE_PASSWORD']
            )
            
            # Get user's groups
            base_dn = current_app.config['AD_BASE_DN']
            search_filter = f"(&(objectClass=group)(member:1.2.840.113556.1.4.1941:={user.ad_dn}))"
            
            result = conn.search_s(base_dn, ldap.SCOPE_SUBTREE, search_filter)
            
            user_groups = [g[0] for g in result]
            
            # Check if user is in any of the required groups
            for group in groups:
                group_dn = f"CN={group},{base_dn}"
                if group_dn in user_groups:
                    return True
            
            return False
            
        except Exception as e:
            current_app.logger.error(f"AD group check error: {str(e)}")
            return False
        finally:
            try:
                conn.unbind_s()
            except:
                pass

import re
from flask import render_template, redirect, url_for, flash, request, current_app
from flask_login import current_user, login_user, logout_user
from werkzeug.urls import url_parse
from app.auth import bp
from app.auth.forms import LoginForm, RegistrationForm, ForgotPasswordForm, ResetPasswordForm
from app.models.user import User
from app.models.config import AppConfig
from app import db
from datetime import datetime
from app.auth.ad import ADAuth
from app.utils.logger import log_activity

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
        
    form = LoginForm()
    if form.validate_on_submit():
        try:
            user = User.query.filter_by(username=form.username.data).first()
            if user is None or not user.check_password(form.password.data):
                log_activity(
                    action='failed_login',
                    details=f"Failed login attempt for user: {form.username.data}",
                    severity='WARNING'
                )
                flash('Nieprawidłowa nazwa użytkownika lub hasło', 'danger')
                return render_template('auth/login.html', title='Logowanie', form=form), 400
            
            if not user.is_active:
                log_activity(
                    action='inactive_login',
                    details=f"Login attempt for inactive user: {user.username}",
                    severity='WARNING'
                )
                flash('To konto jest nieaktywne', 'warning')
                return render_template('auth/login.html', title='Logowanie', form=form), 400

            login_user(user, remember=form.remember_me.data)
            log_activity(
                action='login',
                user_id=user.id,
                details=f"User logged in: {user.username}",
                severity='INFO'
            )
            
            next_page = request.args.get('next')
            if not next_page or url_parse(next_page).netloc != '':
                next_page = url_for('main.index')
            return redirect(next_page)
            
        except Exception as e:
            current_app.logger.error(f"Login error: {str(e)}")
            flash('Wystąpił błąd podczas logowania', 'danger')
            return render_template('auth/login.html', title='Logowanie', form=form), 400

    return render_template('auth/login.html', title='Logowanie', form=form)

@bp.route('/logout')
def logout():
    logout_user()
    flash('Zostałeś wylogowany.', 'info')
    return redirect(url_for('auth.login'))

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    # Sprawdź czy rejestracja jest włączona
    try:
        registration_enabled = AppConfig.get_value('ENABLE_REGISTRATION', 'true').lower() == 'true'
        if not registration_enabled:
            flash('Rejestracja jest obecnie wyłączona.', 'warning')
            return redirect(url_for('auth.login'))
    except Exception:
        # W przypadku błędu, domyślnie włącz rejestrację
        pass
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            is_active=True
        )
        user.set_password(form.password.data)
        
        try:
            db.session.add(user)
            db.session.commit()
            flash('Rejestracja zakończona sukcesem! Możesz się teraz zalogować.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas rejestracji: {str(e)}', 'danger')
    
    return render_template('auth/register.html', title='Rejestracja', form=form)

@bp.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = ForgotPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            # W pełnej implementacji należy wysłać email z tokenem
            # Tutaj tylko pokazujemy komunikat
            flash('Instrukcje resetowania hasła zostały wysłane na Twój adres email.', 'info')
            return redirect(url_for('auth.login'))
            
    return render_template('auth/forgot_password.html', title='Resetowanie hasła', form=form)

@bp.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    # W pełnej implementacji należy zweryfikować token
    # Tutaj tylko pokazujemy formularz
    
    form = ResetPasswordForm()
    if form.validate_on_submit():
        flash('Twoje hasło zostało pomyślnie zresetowane.', 'success')
        return redirect(url_for('auth.login'))
        
    return render_template('auth/reset_password.html', title='Resetowanie hasła', form=form)

from functools import wraps
from flask import flash, redirect, url_for, current_app
from flask_login import current_user
from app.auth.ad import ADAuth

def admin_required(f):
    """Decorator to require admin privileges for a route"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login', next=url_for(request.endpoint)))
        if not current_user.is_admin and not current_user.is_global_admin:
            flash('Dostęp zabroniony. Wymagane uprawnienia administratora.', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

def global_admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login', next=url_for(request.endpoint)))
        if not current_user.is_global_admin:
            flash('Dostęp zabroniony. Wymagane uprawnienia administratora globalnego.', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

def team_admin_required(team_id_arg='team_id'):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            team_id = kwargs.get(team_id_arg)
            if not team_id:
                flash('Nieprawidłowy identyfikator zespołu.', 'warning')
                return redirect(url_for('teams.index'))
                
            if not current_user.is_authenticated:
                return redirect(url_for('auth.login'))
                
            if current_user.is_admin:
                return f(*args, **kwargs)
                
            # Sprawdź czy użytkownik jest administratorem zespołu
            from app.models.team import Team
            team = Team.query.get_or_404(team_id)
            user_role = current_user.get_role_in_team(team.id)
            
            if user_role < 2:  # 2 = admin zespołu
                flash('Nie masz uprawnień administratora tego zespołu.', 'warning')
                return redirect(url_for('teams.view', id=team_id))
                
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def ad_group_required(groups):
    """Decorator to require AD group membership"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Skip check if AD is disabled
            if not current_app.config.get('AD_ENABLED', False):
                return f(*args, **kwargs)
                
            if not current_user.is_authenticated:
                return redirect(url_for('auth.login'))
                
            # Admin users always have access
            if current_user.is_admin:
                return f(*args, **kwargs)
                
            # Skip check for non-AD users
            if not current_user.is_ad_user:
                flash('Ta funkcja wymaga autoryzacji z Active Directory.', 'warning')
                return redirect(url_for('main.index'))
                
            # Convert single group to list if needed
            required_groups = groups if isinstance(groups, list) else [groups]
            
            # Check if user is member of any required group
            if ADAuth.check_group_membership(current_user, required_groups):
                return f(*args, **kwargs)
                
            flash('Nie masz uprawnień do tej funkcji. Wymagane członkostwo w grupie AD.', 'warning')
            return redirect(url_for('main.index'))
            
        return decorated_function
    return decorator
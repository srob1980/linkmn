from flask import render_template, request, current_app
from app import db
from app.errors import bp
from flask_login import current_user

def should_ignore_404(path):
    """Check if 404 error should be ignored for certain paths"""
    ignored_paths = [
        '/.well-known/',
        '/favicon.ico',
        '/robots.txt',
        '/sitemap.xml',
        '/apple-touch-icon',
        '/manifest.json'
    ]
    return any(path.startswith(ignore) for ignore in ignored_paths)

@bp.app_errorhandler(404)
def not_found_error(error):
    """Handle 404 errors"""
    # Check if request is for source map or devtools
    if request.path.endswith(('.map', '.json')) and (
        '.well-known' in request.path or 
        'bootstrap.min.css.map' in request.path
    ):
        return '', 404  # Return empty response for source maps
        
    # Log only for real 404s, not source maps or devtools requests
    if not request.path.endswith(('.map', '.json')):
        try:
            from app.utils.logger import log_activity
            log_activity(
                action='page_not_found',
                user_id=current_user.id if not current_user.is_anonymous else None,
                details=request.path,
                severity='INFO'
            )
        except Exception as e:
            current_app.logger.error(f"Error logging 404: {str(e)}")
    
    return render_template('errors/404.html', 
                         is_error_page=True, 
                         error_code=404,
                         error_message="Strona nie została znaleziona"), 404

@bp.app_errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('errors/500.html', 
                         is_error_page=True,
                         error_code=500,
                         error_message="Wystąpił błąd wewnętrzny serwera"), 500

@bp.app_errorhandler(403)
def forbidden_error(error):
    return render_template('errors/403.html'), 403

@bp.app_errorhandler(401)
def unauthorized_error(error):
    return render_template('errors/401.html'), 401

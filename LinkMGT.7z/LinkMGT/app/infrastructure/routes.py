from flask import render_template, redirect, url_for, flash, request, current_app, jsonify
from flask_login import login_required, current_user
from app import db
from app.infrastructure import bp
from app.infrastructure.forms import (
    AssetForm, LicenseForm, LocationForm, VendorForm, 
    AssetStatusForm, LicenseTypeForm
)
from app.models.infrastructure import (
    Asset, AssetType, Location, Vendor, License, 
    LicenseType, AssetStatus, SupportContract, MaintenanceLog  # Add MaintenanceLog here
)
from app.auth.decorators import admin_required  # Add this import
from datetime import date, datetime, timedelta  # Add datetime to imports

@bp.route('/')
@login_required
def index():
    """Infrastructure dashboard"""
    today = date.today()
    
    # Get stats
    assets = Asset.query.count()
    licenses = License.query.count()
    contracts = SupportContract.query.count()
    
    # Get expiring items
    thirty_days = today + timedelta(days=30)
    expiring_warranties = Asset.query.filter(
        Asset.warranty_end.isnot(None),
        Asset.warranty_end <= thirty_days,
        Asset.warranty_end >= today
    ).all()
    
    expiring_licenses = License.query.filter(
        License.expiry_date.isnot(None),
        License.expiry_date <= thirty_days,
        License.expiry_date >= today
    ).all()
    
    expiring_contracts = SupportContract.query.filter(
        SupportContract.end_date <= thirty_days,
        SupportContract.end_date >= today
    ).all()
    
    return render_template('infrastructure/index.html',
                         title='Panel Infrastruktury',
                         assets=assets,
                         licenses=licenses,
                         contracts=contracts,
                         expiring_warranties=expiring_warranties,
                         expiring_licenses=expiring_licenses,
                         expiring_contracts=expiring_contracts,
                         today=today)  # Add today to template context

@bp.route('/assets')
@login_required
def assets_list():
    """List all assets"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('ITEMS_PER_PAGE', 10)
    
    # Get query parameters for filtering
    search = request.args.get('search', '')
    selected_type = request.args.get('type', '')
    selected_status = request.args.get('status', '')
    selected_location = request.args.get('location', '')
    
    # Build query
    query = Asset.query
    
    # Apply filters
    if search:
        query = query.filter(
            Asset.name.ilike(f'%{search}%') | 
            Asset.asset_tag.ilike(f'%{search}%') |
            Asset.serial_number.ilike(f'%{search}%')
        )
    
    if selected_type:
        query = query.filter(Asset.asset_type_id == selected_type)
    
    if selected_status:
        query = query.filter(Asset.status_id == selected_status)
    
    if selected_location:
        query = query.filter(Asset.location_id == selected_location)
    
    # Paginate results - this returns a pagination object with pages attribute
    assets = query.order_by(Asset.name).paginate(page=page, per_page=per_page)
    
    # Get data for filters
    types = AssetType.query.order_by(AssetType.name).all()
    statuses = AssetStatus.query.order_by(AssetStatus.name).all()
    locations = Location.query.filter_by(is_active=True).order_by(Location.name).all()
    
    return render_template('infrastructure/assets.html',
                         title='Zasoby IT',
                         assets=assets,
                         types=types,
                         statuses=statuses,
                         locations=locations,
                         search=search,
                         selected_type=selected_type,
                         selected_status=selected_status,
                         selected_location=selected_location)

@bp.route('/asset/create', methods=['GET', 'POST'])
@login_required
def asset_create():
    """Create new asset"""
    form = AssetForm()
    
    # Update choices before validation
    form.status_id.choices = [(s.id, s.name) for s in AssetStatus.query.order_by(AssetStatus.name).all()]
    form.asset_type_id.choices = [(t.id, t.name) for t in AssetType.query.order_by(AssetType.name).all()]
    form.location_id.choices = [(0, '-- Wybierz lokalizację --')] + \
        [(l.id, l.name) for l in Location.query.filter_by(is_active=True).order_by(Location.name).all()]
    form.vendor_id.choices = [(0, '-- Wybierz dostawcę --')] + \
        [(v.id, v.name) for v in Vendor.query.filter_by(is_active=True).order_by(Vendor.name).all()]

    if form.validate_on_submit():
        try:
            asset = Asset()
            form.populate_obj(asset)
            
            # Handle optional relations
            if form.location_id.data == 0:
                asset.location_id = None
            if form.vendor_id.data == 0:
                asset.vendor_id = None

            db.session.add(asset)
            db.session.commit()
            flash('Zasób został dodany pomyślnie.', 'success')
            return redirect(url_for('infrastructure.assets_list'))
        except Exception as e:
            db.session.rollback()
            flash(f'Wystąpił błąd podczas dodawania zasobu: {str(e)}', 'danger')

    return render_template('infrastructure/asset_form.html',
                         title='Nowy zasób',
                         form=form)

@bp.route('/assets/<int:asset_id>/edit', methods=['GET', 'POST'])
@login_required
def asset_edit(asset_id):
    """Edytuj zasób IT"""
    asset = Asset.query.get_or_404(asset_id)
    form = AssetForm(obj=asset)
    
    if form.validate_on_submit():
        try:
            form.populate_obj(asset)
            asset.updated_at = datetime.utcnow()  # Add timestamp update
            
            # Handle optional relations
            if form.location_id.data == 0:
                asset.location_id = None
            if form.vendor_id.data == 0:
                asset.vendor_id = None

            db.session.commit()
            flash('Zasób został zaktualizowany pomyślnie.', 'success')
            return redirect(url_for('infrastructure.assets_list'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji zasobu: {str(e)}', 'danger')
    
    return render_template('infrastructure/asset_form.html',
                         title='Edycja zasobu',
                         form=form,
                         asset=asset)

@bp.route('/asset/<int:asset_id>/delete', methods=['POST'])
@login_required
def asset_delete(asset_id):
    """Usuń zasób"""
    asset = Asset.query.get_or_404(asset_id)
    db.session.delete(asset)
    db.session.commit()
    flash('Zasób został pomyślnie usunięty.', 'success')
    return redirect(url_for('infrastructure.assets'))

@bp.route('/licenses')
@login_required
def licenses():
    """List all licenses"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    vendor_filter = request.args.get('vendor')
    status_filter = request.args.get('status')
    
    query = License.query
    
    if search:
        query = query.filter(
            License.name.ilike(f'%{search}%') |
            License.software.ilike(f'%{search}%')
        )
    
    if vendor_filter:
        query = query.filter_by(vendor_id=vendor_filter)
        
    if status_filter:
        today = date.today()
        if status_filter == 'valid':
            query = query.filter(License.expiry_date > today)
        elif status_filter == 'expired':
            query = query.filter(License.expiry_date <= today)
        elif status_filter == 'expiring':
            thirty_days = today + timedelta(days=30)
            query = query.filter(License.expiry_date.between(today, thirty_days))
    
    # Get all vendors for filter dropdown
    vendors = Vendor.query.filter_by(is_active=True).order_by(Vendor.name).all()
    
    # Get paginated licenses
    licenses = query.order_by(License.name).paginate(
        page=page, per_page=current_app.config.get('ITEMS_PER_PAGE', 10)
    )
    
    return render_template('infrastructure/licenses.html',
                         title='Licencje',
                         licenses=licenses,
                         vendors=vendors,
                         search=search,
                         vendor_filter=vendor_filter,
                         status_filter=status_filter,
                         today=date.today())  # Add today's date

@bp.route('/license/create', methods=['GET', 'POST'])
@login_required
def license_create():
    """Dodaj nową licencję"""
    form = LicenseForm()
    
    # Populate vendor select field
    form.vendor_id.choices = [(0, '-- Wybierz dostawcę --')] + [(v.id, v.name) for v in Vendor.query.filter_by(is_active=True).all()]
    
    if form.validate_on_submit():
        license = License(
            name=form.name.data,
            software=form.software.data,
            license_key=form.license_key.data,
            license_type=form.license_type.data,
            purchase_date=form.purchase_date.data,
            expiry_date=form.expiry_date.data,
            seats=form.seats.data,
            used_seats=form.used_seats.data,
            cost=form.cost.data,
            notes=form.notes.data,
            created_by=current_user.id
        )
        
        if form.vendor_id.data and form.vendor_id.data > 0:
            license.vendor_id = form.vendor_id.data
            
        db.session.add(license)
        db.session.commit()
        flash('Licencja została pomyślnie dodana.', 'success')
        return redirect(url_for('infrastructure.licenses'))
    
    return render_template('infrastructure/license_form.html',
                         title='Dodaj nową licencję',
                         form=form)

@bp.route('/license/<int:license_id>/edit', methods=['GET', 'POST'])
@login_required
def license_edit(license_id):
    """Edytuj licencję"""
    license = License.query.get_or_404(license_id)
    form = LicenseForm(obj=license)
    
    # Populate vendor select field
    form.vendor_id.choices = [(0, '-- Wybierz dostawcę --')] + [(v.id, v.name) for v in Vendor.query.filter_by(is_active=True).all()]
    
    if form.validate_on_submit():
        try:
            # Use populate_obj for most fields
            form.populate_obj(license)
            
            # Handle optional relationships
            if form.license_type_id.data == 0:
                license.license_type_id = None
            if form.vendor_id.data == 0:
                license.vendor_id = None
                
            db.session.commit()
            flash('Licencja została zaktualizowana pomyślnie.', 'success')
            return redirect(url_for('infrastructure.licenses'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji licencji: {str(e)}', 'danger')
    
    return render_template('infrastructure/license_form.html',
                         title='Edycja licencji',
                         form=form,
                         license=license)

@bp.route('/license/<int:license_id>/view')
@login_required
def license_view(license_id):
    """Podgląd licencji"""
    license = License.query.get_or_404(license_id)
    return render_template('infrastructure/license_view.html',
                         title=license.name,
                         license=license,
                         now=datetime.now())

@bp.route('/license/<int:license_id>/delete', methods=['POST'])
@login_required
def license_delete(license_id):
    """Usuń licencję"""
    license = License.query.get_or_404(license_id)
    db.session.delete(license)
    db.session.commit()
    flash('Licencja została pomyślnie usunięta.', 'success')
    return redirect(url_for('infrastructure.licenses'))

@bp.route('/contracts')
@login_required
def support_contracts():
    """List all support contracts"""
    page = request.args.get('page', 1, type=int)
    contracts = SupportContract.query.order_by(SupportContract.name).paginate(
        page=page, per_page=current_app.config.get('ITEMS_PER_PAGE', 10)
    )
    vendors = Vendor.query.filter_by(is_active=True).all()
    return render_template('infrastructure/support_contracts.html',
                         title='Umowy serwisowe',
                         contracts=contracts,
                         vendors=vendors)

@bp.route('/contract/create', methods=['GET', 'POST'])
@login_required
def contract_create():
    """Create new support contract"""
    form = SupportContractForm()
    if form.validate_on_submit():
        contract = SupportContract()
        form.populate_obj(contract)
        try:
            db.session.add(contract)
            db.session.commit()
            flash('Umowa serwisowa została dodana pomyślnie.', 'success')
            return redirect(url_for('infrastructure.support_contracts'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania umowy: {str(e)}', 'danger')
    
    return render_template('infrastructure/contract_form.html',
                         title='Nowa umowa serwisowa',
                         form=form)

@bp.route('/contract/<int:contract_id>/edit', methods=['GET', 'POST'])
@login_required
def contract_edit(contract_id):
    """Edit support contract"""
    contract = SupportContract.query.get_or_404(contract_id)
    form = SupportContractForm(obj=contract)
    
    if form.validate_on_submit():
        form.populate_obj(contract)
        try:
            db.session.commit()
            flash('Umowa serwisowa została zaktualizowana.', 'success')
            return redirect(url_for('infrastructure.support_contracts'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji umowy: {str(e)}', 'danger')
    
    return render_template('infrastructure/contract_form.html',
                         title='Edycja umowy serwisowej',
                         form=form)

@bp.route('/contract/<int:contract_id>/delete', methods=['POST'])
@login_required
def contract_delete(contract_id):
    """Delete support contract"""
    contract = SupportContract.query.get_or_404(contract_id)
    try:
        db.session.delete(contract)
        db.session.commit()
        flash('Umowa serwisowa została usunięta.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania umowy: {str(e)}', 'danger')
    
    return redirect(url_for('infrastructure.support_contracts'))

@bp.route('/contract/<int:contract_id>')
@login_required
def contract_view(contract_id):
    """View support contract details"""
    contract = SupportContract.query.get_or_404(contract_id)
    return render_template('infrastructure/contract_detail.html',
                         title='Szczegóły umowy serwisowej',
                         contract=contract)

@bp.route('/asset/<int:asset_id>/view')
@login_required
def asset_view(asset_id):
    """View asset details"""
    asset = Asset.query.get_or_404(asset_id)
    today = date.today()
    expiring_soon = today + timedelta(days=30)
    
    return render_template('infrastructure/asset_detail.html',
                         title=f'Zasób: {asset.name}',
                         asset=asset,
                         today=today,
                         expiring_soon=expiring_soon)

@bp.route('/asset/<int:id>')
@login_required
def asset_detail(id):
    """Display asset details"""
    asset = Asset.query.get_or_404(id)
    
    # Get related maintenance logs if they exist
    maintenance_logs = []
    if hasattr(asset, 'maintenance_logs'):
        # Fix: Query MaintenanceLog directly instead of using the relationship attribute
        from app.models.infrastructure import MaintenanceLog
        maintenance_logs = MaintenanceLog.query.filter_by(asset_id=id).order_by(MaintenanceLog.created_at.desc()).all()
    
    # Get support contracts if they exist
    contracts = []
    if hasattr(asset, 'contracts'):
        contracts = asset.contracts.all()
    
    return render_template('infrastructure/asset_detail.html',
                          title=f'Zasób: {asset.name}',
                          asset=asset,
                          maintenance_logs=maintenance_logs,
                          contracts=contracts)

@bp.route('/statuses')
@login_required
def statuses():
    """View asset statuses"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('ITEMS_PER_PAGE', 10)
    
    statuses = AssetStatus.query.order_by(AssetStatus.name).paginate(
        page=page, per_page=per_page
    )
    
    return render_template('infrastructure/statuses.html',
                          title='Statusy zasobów',
                          statuses=statuses)

@bp.route('/status/create', methods=['GET', 'POST'])
@login_required
def status_create():
    """Create new asset status"""
    form = AssetStatusForm()
    if form.validate_on_submit():
        status = AssetStatus()
        form.populate_obj(status)
        
        try:
            db.session.add(status)
            db.session.commit()
            flash('Status został dodany pomyślnie.', 'success')
            return redirect(url_for('infrastructure.statuses'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania statusu: {str(e)}', 'danger')
    
    return render_template('infrastructure/status_form.html',
                         title='Nowy status',
                         form=form)

@bp.route('/status/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def status_edit(id):
    """Edit asset status"""
    status = AssetStatus.query.get_or_404(id)
    form = AssetStatusForm(obj=status)
    
    if form.validate_on_submit():
        form.populate_obj(status)
        try:
            db.session.commit()
            flash(f'Status "{status.name}" został zaktualizowany pomyślnie.', 'success')
            return redirect(url_for('infrastructure.statuses'))  # Change from asset_statuses to statuses
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji statusu: {str(e)}', 'danger')
    
    return render_template('infrastructure/status_form.html',
                          title=f'Edytuj status: {status.name}',
                          form=form,
                          status=status)

@bp.route('/status/<int:id>/delete', methods=['POST'])
@login_required
@admin_required
def status_delete(id):
    """Delete asset status"""
    status = AssetStatus.query.get_or_404(id)
    
    # Check if status is used by any assets
    if status.assets:
        flash('Nie można usunąć statusu, który jest używany przez zasoby.', 'danger')
        return redirect(url_for('infrastructure.statuses'))
    
    try:
        db.session.delete(status)
        db.session.commit()
        flash('Status został usunięty.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania statusu: {str(e)}', 'danger')
    
    return redirect(url_for('infrastructure.statuses'))

@bp.route('/vendors')
@login_required
def vendors():
    """List all vendors"""
    vendors = Vendor.query.order_by(Vendor.name).all()
    return render_template('infrastructure/vendors.html',
                         title='Dostawcy',
                         vendors=vendors)

@bp.route('/vendor/create', methods=['GET', 'POST'])
@login_required
def vendor_create():
    """Create new vendor"""
    form = VendorForm()
    if form.validate_on_submit():
        vendor = Vendor()
        form.populate_obj(vendor)
        try:
            db.session.add(vendor)
            db.session.commit()
            flash('Dostawca został dodany pomyślnie', 'success')
            return redirect(url_for('infrastructure.vendors'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania dostawcy: {str(e)}', 'danger')
    
    return render_template('infrastructure/vendor_form.html',
                         title='Nowy dostawca',
                         form=form)

@bp.route('/vendor/<int:vendor_id>/edit', methods=['GET', 'POST'])
@login_required
def vendor_edit(vendor_id):
    """Edit vendor"""
    vendor = Vendor.query.get_or_404(vendor_id)
    form = VendorForm(obj=vendor)
    
    if request.method == 'POST':
        # Print form data for debugging
        current_app.logger.info(f"Form data: {request.form}")
        
        if form.validate_on_submit():
            try:
                # Update individual fields to match the database structure
                vendor.name = form.name.data
                # Description isn't in DB but we'll keep it in the form
                vendor.contact_person = form.contact_person.data
                vendor.email = form.email.data
                vendor.phone = form.phone.data
                vendor.website = form.website.data
                vendor.address = form.address.data
                vendor.city = form.city.data
                vendor.country = form.country.data
                vendor.is_active = form.is_active.data
                
                # Force the update timestamp
                vendor.updated_at = datetime.utcnow()
                
                db.session.commit()
                flash(f'Dostawca "{vendor.name}" został zaktualizowany pomyślnie.', 'success')
                return redirect(url_for('infrastructure.vendors'))
            except Exception as e:
                db.session.rollback()
                current_app.logger.error(f"Error updating vendor: {str(e)}")
                flash(f'Wystąpił błąd podczas aktualizacji dostawcy: {str(e)}', 'danger')
        else:
            # Log validation errors
            current_app.logger.error(f"Form validation errors: {form.errors}")
            flash('Formularz zawiera błędy. Sprawdź wprowadzone dane.', 'danger')
    
    return render_template('infrastructure/vendor_form.html',
                         title=f'Edytuj dostawcę: {vendor.name}',
                         form=form,
                         vendor=vendor)

@bp.route('/vendor/<int:vendor_id>/delete', methods=['POST'])
@login_required
def vendor_delete(vendor_id):
    """Delete vendor"""
    vendor = Vendor.query.get_or_404(vendor_id)
    try:
        db.session.delete(vendor)
        db.session.commit()
        flash('Dostawca został usunięty', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania dostawcy: {str(e)}', 'danger')
    
    return redirect(url_for('infrastructure.vendors'))

@bp.route('/types')
@login_required
def asset_types_list():  # Changed from asset_types to asset_types_list
    """List all asset types"""
    types = AssetType.query.all()
    return render_template('infrastructure/types.html',
                         title='Typy zasobów',
                         types=types)

@bp.route('/type/create', methods=['GET', 'POST'])
@login_required
def type_create():
    """Create new asset type"""
    form = AssetTypeForm()
    if form.validate_on_submit():
        asset_type = AssetType()
        form.populate_obj(asset_type)
        db.session.add(asset_type)
        db.session.commit()
        flash('Dodano nowy typ zasobu', 'success')
        return redirect(url_for('infrastructure.asset_types'))
    return render_template('infrastructure/type_form.html',
                         title='Nowy typ zasobu',
                         form=form)

@bp.route('/type/<int:type_id>/edit', methods=['GET', 'POST'])
@login_required
def type_edit(type_id):
    """Edit asset type"""
    type = AssetType.query.get_or_404(type_id)
    form = AssetTypeForm(obj=type)
    
    if form.validate_on_submit():
        form.populate_obj(type)
        db.session.commit()
        flash('Typ zasobu został zaktualizowany', 'success')
        return redirect(url_for('infrastructure.asset_types'))
    
    return render_template('infrastructure/type_form.html',
                         title='Edycja typu zasobu',
                         form=form,
                         type=type)

@bp.route('/type/<int:type_id>/delete', methods=['POST'])
@login_required
def type_delete(type_id):
    """Delete asset type"""
    type = AssetType.query.get_or_404(type_id)
    db.session.delete(type)
    db.session.commit()
    flash('Typ zasobu został usunięty', 'success')
    return redirect(url_for('infrastructure.asset_types'))

@bp.route('/settings')
@login_required
def settings():
    """Infrastructure settings page"""
    asset_types = AssetType.query.order_by(AssetType.name).all()
    vendors = Vendor.query.order_by(Vendor.name).all()
    locations = Location.query.order_by(Location.name).all()
    statuses = AssetStatus.query.order_by(AssetStatus.name).all()
    
    return render_template('infrastructure/settings.html',
                         title='Ustawienia Infrastruktury',
                         asset_types=asset_types,
                         vendors=vendors,
                         locations=locations,
                         statuses=statuses)

@bp.route('/settings/type/add', methods=['POST'])
@login_required
def type_add():
    """Add new asset type"""
    try:
        name = request.form.get('name')
        description = request.form.get('description', '')
        
        asset_type = AssetType(name=name, description=description)
        db.session.add(asset_type)
        db.session.commit()
        flash('Typ zasobu został dodany', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas dodawania typu zasobu: {str(e)}', 'danger')
    return redirect(url_for('infrastructure.settings'))

@bp.route('/settings/vendor/add', methods=['POST'])
@login_required
def vendor_add():
    """Add new vendor"""
    try:
        name = request.form.get('name')
        contact_person = request.form.get('contact_person', '')
        email = request.form.get('email', '')
        phone = request.form.get('phone', '')
        
        vendor = Vendor(name=name, contact_person=contact_person,
                       email=email, phone=phone)
        db.session.add(vendor)
        db.session.commit()
        flash('Dostawca został dodany', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas dodawania dostawcy: {str(e)}', 'danger')
    return redirect(url_for('infrastructure.settings'))

@bp.route('/settings/location/add', methods=['POST'])
@login_required
def location_add():
    """Add new location"""
    try:
        name = request.form.get('name')
        address = request.form.get('address', '')
        description = request.form.get('description', '')
        
        location = Location(name=name, address=address, description=description)
        db.session.add(location)
        db.session.commit()
        flash('Lokalizacja została dodana', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas dodawania lokalizacji: {str(e)}', 'danger')
    return redirect(url_for('infrastructure.settings'))

@bp.route('/settings/<string:item_type>/<int:item_id>/edit', methods=['POST'])
@login_required
def settings_edit(item_type, item_id):
    """Edit settings item"""
    try:
        if item_type == 'type':
            item = AssetType.query.get_or_404(item_id)
        elif item_type == 'vendor':
            item = Vendor.query.get_or_404(item_id)
        elif item_type == 'location':
            item = Location.query.get_or_404(item_id)
        elif item_type == 'status':
            item = AssetStatus.query.get_or_404(item_id)
        else:
            flash('Nieprawidłowy typ elementu', 'danger')
            return redirect(url_for('infrastructure.settings'))
            
        for key, value in request.form.items():
            if hasattr(item, key):
                setattr(item, key, value)
                
        db.session.commit()
        flash('Element został zaktualizowany', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas aktualizacji: {str(e)}', 'danger')
    return redirect(url_for('infrastructure.settings'))

@bp.route('/settings/<string:item_type>/<int:item_id>/delete', methods=['POST'])
@login_required
def settings_delete(item_type, item_id):
    """Delete settings item"""
    try:
        if item_type == 'type':
            item = AssetType.query.get_or_404(item_id)
        elif item_type == 'vendor':
            item = Vendor.query.get_or_404(item_id)
        elif item_type == 'location':
            item = Location.query.get_or_404(item_id)
        elif item_type == 'status':
            item = AssetStatus.query.get_or_404(item_id)
        else:
            flash('Nieprawidłowy typ elementu', 'danger')
            return redirect(url_for('infrastructure.settings'))
            
        db.session.delete(item)
        db.session.commit()
        flash('Element został usunięty', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania: {str(e)}', 'danger')
    return redirect(url_for('infrastructure.settings'))

@bp.route('/locations')
@login_required
def locations():
    """List all locations"""
    locations = Location.query.order_by(Location.name).all()
    return render_template('infrastructure/locations.html',
                         title='Lokalizacje',
                         locations=locations)

@bp.route('/location/create', methods=['GET', 'POST'])
@login_required
def location_create():
    """Create new location"""
    form = LocationForm()
    if form.validate_on_submit():
        location = Location()
        form.populate_obj(location)
        try:
            db.session.add(location)
            db.session.commit()
            flash('Lokalizacja została dodana pomyślnie.', 'success')
            return redirect(url_for('infrastructure.locations'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania lokalizacji: {str(e)}', 'danger')
    
    return render_template('infrastructure/location_form.html',
                         title='Nowa lokalizacja',
                         form=form)

@bp.route('/location/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def location_edit(id):
    """Edit location"""
    location = Location.query.get_or_404(id)
    form = LocationForm(obj=location)
    if form.validate_on_submit():
        form.populate_obj(location)
        try:
            db.session.commit()
            flash('Lokalizacja została zaktualizowana.', 'success')
            return redirect(url_for('infrastructure.locations'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji lokalizacji: {str(e)}', 'danger')
    
    return render_template('infrastructure/location_form.html',
                         title='Edycja lokalizacji',
                         form=form)

@bp.route('/location/<int:id>/delete', methods=['POST'])
@login_required
def location_delete(id):
    """Delete location"""
    location = Location.query.get_or_404(id)
    try:
        db.session.delete(location)
        db.session.commit()
        flash('Lokalizacja została usunięta.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania lokalizacji: {str(e)}', 'danger')
    
    return redirect(url_for('infrastructure.locations'))

@bp.route('/license-types')
@login_required
def license_types():
    """List all license types"""
    types = LicenseType.query.order_by(LicenseType.name).all()
    return render_template('infrastructure/license_types.html',
                         title='Typy licencji',
                         types=types)

@bp.route('/license-type/create', methods=['GET', 'POST'])
@login_required
def license_type_create():
    """Create new license type"""
    form = LicenseTypeForm()
    if form.validate_on_submit():
        type = LicenseType()
        form.populate_obj(type)
        try:
            db.session.add(type)
            db.session.commit()
            flash('Typ licencji został dodany pomyślnie.', 'success')
            return redirect(url_for('infrastructure.license_types'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania typu licencji: {str(e)}', 'danger')
    
    return render_template('infrastructure/license_type_form.html',
                         title='Nowy typ licencji',
                         form=form)

@bp.route('/license-type/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def license_type_edit(id):
    """Edit license type"""
    type = LicenseType.query.get_or_404(id)
    form = LicenseTypeForm(obj=type)
    
    if form.validate_on_submit():
        form.populate_obj(type)
        try:
            db.session.commit()
            flash('Typ licencji został zaktualizowany.', 'success')
            return redirect(url_for('infrastructure.license_types'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji typu licencji: {str(e)}', 'danger')
    
    return render_template('infrastructure/license_type_form.html',
                         title='Edycja typu licencji',
                         form=form)

@bp.route('/license-type/<int:id>/delete', methods=['POST'])
@login_required
def license_type_delete(id):
    """Delete license type"""
    type = LicenseType.query.get_or_404(id)
    if type.licenses:
        flash('Nie można usunąć typu licencji, który jest używany.', 'danger')
        return redirect(url_for('infrastructure.license_types'))
        
    try:
        db.session.delete(type)
        db.session.commit()
        flash('Typ licencji został usunięty.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania typu licencji: {str(e)}', 'danger')
    
    return redirect(url_for('infrastructure.license_types'))

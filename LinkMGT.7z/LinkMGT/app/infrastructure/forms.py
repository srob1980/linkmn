from flask_wtf import FlaskForm
from wtforms import (
    StringField, TextAreaField, SelectField, IntegerField, 
    DecimalField, DateField, SubmitField, BooleanField
)
from wtforms.validators import DataRequired, Optional, Length, NumberRange, ValidationError, Email
from app.models.infrastructure import AssetType, Location, Vendor, Asset, AssetStatus, LicenseType  # Add missing imports

class AssetForm(FlaskForm):
    """Form for creating and editing assets"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    asset_tag = StringField('Tag', validators=[Optional(), Length(max=50)])
    serial_number = StringField('Numer seryjny', validators=[Optional(), Length(max=100)])
    model = StringField('Model', validators=[Optional(), Length(max=100)])
    manufacturer = StringField('Producent', validators=[Optional(), Length(max=100)])
    asset_type_id = SelectField('Typ zasobu', coerce=int, validators=[DataRequired()])
    location_id = SelectField('Lokalizacja', coerce=int, validators=[Optional()])
    vendor_id = SelectField('Dostawca', coerce=int, validators=[Optional()])
    status_id = SelectField('Status', coerce=int, validators=[DataRequired()])  # Changed from status to status_id
    purchase_date = DateField('Data zakupu', validators=[Optional()], format='%Y-%m-%d')
    warranty_start = DateField('Początek gwarancji', validators=[Optional()], format='%Y-%m-%d')
    warranty_end = DateField('Koniec gwarancji', validators=[Optional()], format='%Y-%m-%d')
    warranty_years = IntegerField('Okres gwarancji (lata)', validators=[Optional(), NumberRange(min=0, max=10)])
    value = DecimalField('Wartość', validators=[Optional()], places=2)
    description = TextAreaField('Opis', validators=[Optional(), Length(max=1000)])
    ip_address = StringField('Adres IP', validators=[Optional(), Length(max=45)])
    mac_address = StringField('Adres MAC', validators=[Optional(), Length(max=17)])
    operating_system = StringField('System operacyjny', validators=[Optional(), Length(max=100)])
    cpu = StringField('Procesor', validators=[Optional(), Length(max=100)])
    memory_gb = IntegerField('Pamięć RAM (GB)', validators=[Optional(), NumberRange(min=0)])
    storage_gb = IntegerField('Dysk (GB)', validators=[Optional(), NumberRange(min=0)])
    submit = SubmitField('Zapisz')

    def __init__(self, *args, **kwargs):
        super(AssetForm, self).__init__(*args, **kwargs)
        
        # Update choices based on database values
        self.asset_type_id.choices = [(t.id, t.name) for t in AssetType.query.order_by(AssetType.name).all()]
        self.location_id.choices = [(0, '-- Wybierz lokalizację --')] + \
            [(l.id, l.name) for l in Location.query.filter_by(is_active=True).order_by(Location.name).all()]
        self.vendor_id.choices = [(0, '-- Wybierz dostawcę --')] + \
            [(v.id, v.name) for v in Vendor.query.filter_by(is_active=True).order_by(Vendor.name).all()]
        self.status_id.choices = [(s.id, s.name) for s in AssetStatus.query.order_by(AssetStatus.name).all()]

class LicenseTypeForm(FlaskForm):
    """Form for creating and editing license types"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=200)])
    is_active = BooleanField('Aktywny', default=True)
    submit = SubmitField('Zapisz')

    def validate_name(self, field):
        type = LicenseType.query.filter_by(name=field.data).first()
        if type and type.id != getattr(self._obj, 'id', None):
            raise ValidationError('Typ licencji o tej nazwie już istnieje.')

class LicenseForm(FlaskForm):
    """Form for creating and editing licenses"""
    name = StringField('Nazwa', validators=[DataRequired()])
    software = StringField('Oprogramowanie', validators=[DataRequired()])
    license_key = TextAreaField('Klucz licencyjny', validators=[Optional()])
    license_type_id = SelectField('Typ licencji', coerce=int, validators=[Optional()])
    vendor_id = SelectField('Dostawca', coerce=int, validators=[Optional()])
    purchase_date = DateField('Data zakupu', validators=[Optional()])
    expiry_date = DateField('Data wygaśnięcia', validators=[Optional()])
    seats = IntegerField('Liczba stanowisk', validators=[Optional(), NumberRange(min=1)], default=1)
    used_seats = IntegerField('Wykorzystane stanowiska', validators=[Optional(), NumberRange(min=0)], default=0)
    cost = IntegerField('Koszt', validators=[Optional()])
    notes = TextAreaField('Uwagi', validators=[Optional()])
    submit = SubmitField('Zapisz')  # Add this line
    
    def validate_expiry_date(self, field):
        if field.data and self.purchase_date.data and field.data < self.purchase_date.data:
            raise ValidationError('Expiry date cannot be earlier than purchase date.')
    
    def validate_used_seats(self, field):
        if self.seats.data and field.data > self.seats.data:
            raise ValidationError('Used seats cannot exceed total seats.')

    def __init__(self, *args, **kwargs):
        super(LicenseForm, self).__init__(*args, **kwargs)
        self.license_type_id.choices = [(0, '-- Wybierz typ --')] + \
            [(t.id, t.name) for t in LicenseType.query.filter_by(is_active=True).order_by(LicenseType.name).all()]

class SupportContractForm(FlaskForm):
    """Form for creating and editing support contracts"""
    name = StringField('Nazwa', validators=[DataRequired()])
    vendor_id = SelectField('Dostawca', coerce=int, validators=[Optional()])
    contract_number = StringField('Numer umowy', validators=[Optional()])
    start_date = DateField('Data rozpoczęcia', validators=[DataRequired()])
    end_date = DateField('Data zakończenia', validators=[DataRequired()])
    status = SelectField('Status', validators=[DataRequired()], choices=[
        ('ACTIVE', 'Aktywna'),
        ('EXPIRED', 'Wygasła'),
        ('PENDING', 'Oczekująca'),
        ('CANCELLED', 'Anulowana')
    ])
    cost = IntegerField('Koszt', validators=[Optional()])
    description = TextAreaField('Opis', validators=[Optional()])
    contact_info = TextAreaField('Informacje kontaktowe', validators=[Optional()])
    
    def validate_end_date(self, field):
        if field.data and self.start_date.data and field.data < self.start_date.data:
            raise ValidationError('Data zakończenia nie może być wcześniejsza niż data rozpoczęcia.')

class MaintenanceForm(FlaskForm):
    """Form for creating and editing maintenance logs"""
    asset_id = SelectField('Zasób', coerce=int, validators=[DataRequired()])
    title = StringField('Tytuł', validators=[DataRequired()])
    description = TextAreaField('Opis', validators=[Optional()])
    maintenance_type = StringField('Typ konserwacji', validators=[Optional()])
    priority = SelectField('Priorytet', validators=[DataRequired()], choices=[
        ('LOW', 'Niski'),
        ('MEDIUM', 'Średni'),
        ('HIGH', 'Wysoki'),
        ('CRITICAL', 'Krytyczny')
    ])
    start_date = DateField('Data rozpoczęcia', validators=[DataRequired()])
    end_date = DateField('Data zakończenia', validators=[Optional()])
    status = SelectField('Status', validators=[DataRequired()], choices=[
        ('PLANNED', 'Planowana'),
        ('IN_PROGRESS', 'W trakcie'),
        ('COMPLETED', 'Zakończona'),
        ('CANCELLED', 'Anulowana')
    ])
    technician = StringField('Technik', validators=[Optional()])
    cost = IntegerField('Koszt', validators=[Optional()])
    
    def validate_end_date(self, field):
        if field.data and self.start_date.data and field.data < self.start_date.data:
            raise ValidationError('Data zakończenia nie może być wcześniejsza niż data rozpoczęcia.')

class VendorForm(FlaskForm):
    """Form for vendor management"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=500)])
    contact_person = StringField('Osoba kontaktowa', validators=[Optional(), Length(max=100)])
    email = StringField('Email', validators=[Optional(), Email(), Length(max=120)])
    phone = StringField('Telefon', validators=[Optional(), Length(max=30)])
    website = StringField('Strona WWW', validators=[Optional(), Length(max=200)])
    address = TextAreaField('Adres', validators=[Optional(), Length(max=200)])
    city = StringField('Miasto', validators=[Optional(), Length(max=50)])
    country = StringField('Kraj', validators=[Optional(), Length(max=50)])
    is_active = BooleanField('Aktywny', default=True)
    submit = SubmitField('Zapisz')

class LocationForm(FlaskForm):
    """Form for creating and editing locations"""
    name = StringField('Nazwa', validators=[DataRequired()])
    address = TextAreaField('Adres', validators=[Optional()])
    city = StringField('Miasto', validators=[Optional()])
    country = StringField('Kraj', validators=[Optional()])
    postal_code = StringField('Kod pocztowy', validators=[Optional()])
    is_active = BooleanField('Aktywny', default=True)
    submit = SubmitField('Zapisz')  # Add this line

class AssetStatusForm(FlaskForm):
    """Form for creating and editing asset statuses"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=50)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=200)])
    color = StringField('Kolor', validators=[Optional(), Length(max=20)], default='secondary')
    is_default = BooleanField('Status domyślny')
    submit = SubmitField('Zapisz')
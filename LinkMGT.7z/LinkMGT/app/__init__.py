from flask import Flask, current_app, request, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect
from config import Config
import os
import datetime

# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'
csrf = CSRFProtect()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Initialize Flask extensions here
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    
    # Register Blueprints
    from app.errors import bp as errors_bp
    app.register_blueprint(errors_bp)
    
    from app.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')
    
    from app.main import bp as main_bp
    app.register_blueprint(main_bp)
    
    from app.admin import bp as admin_bp
    app.register_blueprint(admin_bp, url_prefix='/admin')
    
    from app.infrastructure import bp as infrastructure_bp
    app.register_blueprint(infrastructure_bp, url_prefix='/infrastructure')
    
    from app.links import bp as links_bp
    app.register_blueprint(links_bp, url_prefix='/links')
    
    from app.categories import bp as categories_bp
    app.register_blueprint(categories_bp, url_prefix='/categories')
    
    from app.teams import bp as teams_bp
    app.register_blueprint(teams_bp, url_prefix='/teams')
    
    # Register template filters and functions
    from app.utils.template_helpers import format_date, humanize_date, currency, format_filesize, asset_status_color, warranty_status_color
    
    app.jinja_env.filters['format_date'] = format_date
    app.jinja_env.filters['humanize_date'] = humanize_date
    app.jinja_env.filters['currency'] = currency
    app.jinja_env.filters['filesize'] = format_filesize
    
    # Make functions available in templates
    app.jinja_env.globals.update(
        format_date=format_date,
        humanize_date=humanize_date,
        currency=currency,
        filesize=format_filesize,
        asset_status_color=asset_status_color,
        warranty_status_color=warranty_status_color
    )
    
    # Initialize the TaskManager with the app
    from app.utils.background_tasks import TaskManager
    TaskManager.init_app(app)
    
    # Setup logging
    if not app.debug and not app.testing:
        from app.utils.logger import setup_logging
        setup_logging(app)
    
    # Set up relationships after all models are imported
    with app.app_context():
        setup_model_relationships()
    
    return app

def setup_model_relationships():
    """Setup model relationships after all models are imported"""
    from app.models import User, Team, Link, Category, Tag, user_team, link_category, link_tag, link_team
    
    # User relationships
    User.links = db.relationship('Link', backref='creator', lazy='dynamic', 
                               foreign_keys='Link.creator_id')
    User.teams = db.relationship('Team', secondary=user_team, lazy='dynamic', 
                               overlaps="members")
    
    # Team relationships  
    Team.members = db.relationship('User', secondary=user_team, lazy='dynamic', 
                                 overlaps="teams")
    Team.links = db.relationship('Link', secondary=link_team, lazy='dynamic',
                               overlaps="teams")
    
    # Link relationships
    Link.category = db.relationship('Category', back_populates='links')
    Link.categories = db.relationship('Category', secondary=link_category, lazy='dynamic')
    Link.tags = db.relationship('Tag', secondary=link_tag, lazy='dynamic')
    Link.teams = db.relationship('Team', secondary=link_team, lazy='dynamic',
                               overlaps="links")
    
    # Category relationships
    Category.links = db.relationship('Link', back_populates='category', lazy='dynamic')
    
    # Tag relationships
    Tag.links = db.relationship('Link', secondary=link_tag, lazy='dynamic',
                              overlaps="tags")

# Import models at the end to avoid circular imports
from app.models.user import User

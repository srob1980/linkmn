from app import db
from datetime import datetime, date, timedelta
from sqlalchemy import Enum, func
from sqlalchemy.ext.hybrid import hybrid_property
from random import randint

# Asset Status Enum
class AssetStatus(db.Model):
    """Model for asset statuses"""
    __tablename__ = 'asset_statuses'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    description = db.Column(db.String(200))
    color = db.Column(db.String(20))  # Increase the length to 20 characters
    is_default = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<AssetStatus {self.name}>'

# Asset Type
class AssetType(db.Model):
    __tablename__ = 'asset_types'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    icon = db.Column(db.String(50), default='fas fa-server')
    color = db.Column(db.String(7), default='#6b7280')  # Hex color code
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<AssetType {self.name}>'

# Location Model
class Location(db.Model):
    __tablename__ = 'locations'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text)
    city = db.Column(db.String(50))
    country = db.Column(db.String(50))
    postal_code = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Location {self.name}>'

# Vendor Model
class Vendor(db.Model):
    __tablename__ = 'vendors'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_person = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(30))
    address = db.Column(db.Text)
    city = db.Column(db.String(50))
    country = db.Column(db.String(50))
    website = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Fix the relationship to remove the conflicting backref
    assets = db.relationship('Asset', back_populates='vendor')
    
    def __repr__(self):
        return f'<Vendor {self.name}>'

# Asset Model
class Asset(db.Model):
    """Model for IT assets"""
    __tablename__ = 'assets'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    asset_tag = db.Column(db.String(50))  # Remove unique=True constraint
    serial_number = db.Column(db.String(100))
    model = db.Column(db.String(100))
    manufacturer = db.Column(db.String(100))
    asset_type_id = db.Column(db.Integer, db.ForeignKey('asset_types.id'))
    location_id = db.Column(db.Integer, db.ForeignKey('locations.id'))
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendors.id'))
    status_id = db.Column(db.Integer, db.ForeignKey('asset_statuses.id'))
    warranty_years = db.Column(db.Integer)
    purchase_date = db.Column(db.Date)
    warranty_start = db.Column(db.Date)
    warranty_end = db.Column(db.Date)
    value = db.Column(db.Numeric(10, 2))
    description = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    mac_address = db.Column(db.String(17))
    operating_system = db.Column(db.String(100))
    cpu = db.Column(db.String(100))
    memory_gb = db.Column(db.Integer)
    storage_gb = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    location = db.relationship('Location', backref='assets')
    vendor = db.relationship('Vendor', back_populates='assets')
    asset_type = db.relationship('AssetType', backref='assets')
    status = db.relationship('AssetStatus', backref='assets')
    
    # Status relationship
    def get_status_obj(self):
        from app import db
        return AssetStatus.query.filter_by(name=self.status).first()
    
    @property
    def warranty_status(self):
        """Get warranty status"""
        if not self.warranty_end:
            return 'no_warranty'
            
        today = date.today()
        days_left = (self.warranty_end - today).days
        
        if days_left < 0:
            return 'expired'
        elif days_left <= 30:
            return 'expiring_soon'
        else:
            return 'active'
    
    @property
    def warranty_days_left(self):
        """Get days left until warranty expiration"""
        if not self.warranty_end:
            return 0
        return (self.warranty_end - date.today()).days

    def calculate_warranty_end(self):
        """Calculate warranty end date based on purchase date and warranty period"""
        if self.purchase_date and self.warranty_years:
            return self.purchase_date + timedelta(days=365 * self.warranty_years)
        return None

    def save_warranty_info(self):
        """Update warranty end date when warranty info changes"""
        if self.purchase_date and self.warranty_years:
            self.warranty_end = self.calculate_warranty_end()

    @property
    def status_name(self):
        """Get status name as string"""
        return self.status.name if self.status else 'UNKNOWN'
    
    @classmethod
    def generate_asset_tag(cls):
        """Generate a unique asset tag"""
        while True:
            tag = f'A{randint(10000, 99999)}'
            if not cls.query.filter_by(asset_tag=tag).first():
                return tag

    def __repr__(self):
        return f'<Asset {self.name}>'

# License Type Model
class LicenseType(db.Model):
    __tablename__ = 'license_types'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    licenses = db.relationship('License', back_populates='license_type')

# License Model
class License(db.Model):
    __tablename__ = 'licenses'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    software = db.Column(db.String(100), nullable=False)
    license_key = db.Column(db.Text)
    license_type_id = db.Column(db.Integer, db.ForeignKey('license_types.id'))
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendors.id'))
    purchase_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date)
    seats = db.Column(db.Integer, default=1)
    used_seats = db.Column(db.Integer, default=0)
    cost = db.Column(db.Numeric(10, 2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    vendor = db.relationship('Vendor', backref='licenses')
    creator = db.relationship('User', foreign_keys=[created_by])
    license_type = db.relationship('LicenseType', back_populates='licenses')
    
    def __repr__(self):
        return f'<License {self.name}>'

# Support Contract Model
class SupportContract(db.Model):
    __tablename__ = 'support_contracts'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    vendor_id = db.Column(db.Integer, db.ForeignKey('vendors.id'))
    contract_number = db.Column(db.String(50))
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default='ACTIVE')
    cost = db.Column(db.Numeric(10, 2))
    description = db.Column(db.Text)
    contact_info = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    vendor = db.relationship('Vendor', backref='support_contracts')
    
    def __repr__(self):
        return f'<SupportContract {self.name}>'

# Maintenance Log Model
class MaintenanceLog(db.Model):
    __tablename__ = 'maintenance_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('assets.id'))
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    maintenance_type = db.Column(db.String(50))
    priority = db.Column(db.String(20))
    
    # Fix column names to match database schema
    started_at = db.Column(db.DateTime)  # Was previously start_date
    completed_at = db.Column(db.DateTime)  # Try this name instead of ended_at
    
    status = db.Column(db.String(20))
    technician = db.Column(db.String(100))
    cost = db.Column(db.Numeric(10, 2))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    asset = db.relationship('Asset', backref='maintenance_logs')
    
    def __repr__(self):
        return f'<MaintenanceLog {self.title}>'

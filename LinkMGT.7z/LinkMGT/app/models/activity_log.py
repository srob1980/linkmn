from app import db
from datetime import datetime

class ActivityLog(db.Model):
    """Model do przechowywania logów aktywności w systemie"""
    __tablename__ = 'activity_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(50), nullable=False)
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    module = db.Column(db.String(50))
    severity = db.Column(db.String(20), default='INFO')
    status = db.Column(db.Integer)
    request_path = db.Column(db.String(255))
    request_method = db.Column(db.String(10))
    response_time = db.Column(db.Float)
    
    # Relacje
    user = db.relationship('User', backref='activity_logs')
    
    def __repr__(self):
        return f'<ActivityLog {self.action}>'

    @classmethod
    def log(cls, action, details=None, severity='INFO', user_id=None):
        """Log an activity"""
        try:
            log = cls(
                action=action,
                details=details,
                severity=severity,
                user_id=user_id,
                timestamp=datetime.utcnow()
            )
            db.session.add(log)
            db.session.commit()
            return log
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating activity log: {str(e)}")
            return None

from app import db
from datetime import datetime

class SystemInfo(db.Model):
    __tablename__ = 'system_info'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    value = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def set(cls, key, value):
        info = cls.query.filter_by(key=key).first()
        if info:
            info.value = value
        else:
            info = cls(key=key, value=value)
            db.session.add(info)
        db.session.commit()
    
    @classmethod
    def get(cls, key, default=None):
        info = cls.query.filter_by(key=key).first()
        return info.value if info else default

from app import db
from datetime import datetime

class SystemLog(db.Model):
    __tablename__ = 'system_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    level = db.Column(db.String(20), index=True)  # DEBUG, INFO, WARNING, ERROR
    source = db.Column(db.String(100))  # Module/component name
    message = db.Column(db.Text)
    details = db.Column(db.JSON)
    hostname = db.Column(db.String(255))
    process_id = db.Column(db.Integer)
    thread_id = db.Column(db.String(50))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    user = db.relationship('User', backref='system_logs')
    
    def __repr__(self):
        return f'<SystemLog {self.timestamp} {self.level}: {self.message}>'

    @staticmethod
    def log(level, message, source=None, details=None, user_id=None):
        """Add a new log entry"""
        import socket
        import os
        import threading
        
        log = SystemLog(
            level=level.upper(),
            message=message,
            source=source,
            details=details,
            hostname=socket.gethostname(),
            process_id=os.getpid(),
            thread_id=threading.current_thread().name,
            user_id=user_id
        )
        
        try:
            db.session.add(log)
            db.session.commit()
            return True
        except Exception as e:
            db.session.rollback()
            print(f"Error saving log: {e}")
            return False

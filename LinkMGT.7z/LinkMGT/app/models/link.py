from app import db
from datetime import datetime

class Link(db.Model):
    __tablename__ = 'links'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text)
    icon = db.Column(db.String(50), default='link')
    is_public = db.Column(db.Boolean, default=True)
    is_active = db.Column(db.Boolean, default=True)
    
    # Add these fields to match the database
    click_count = db.Column(db.Integer, default=0)
    last_accessed = db.Column(db.DateTime)
    favicon_url = db.Column(db.String(500))
    status_code = db.Column(db.Integer)
    last_checked = db.Column(db.DateTime)
    
    # Foreign keys
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    owner_team_id = db.Column(db.Integer, db.ForeignKey('teams.id'))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - Fix for backref conflict
    category = db.relationship('Category', foreign_keys=[category_id])
    link_creator = db.relationship('User', foreign_keys=[creator_id], backref=db.backref('created_links', lazy='dynamic'))
    owner_team = db.relationship('Team', foreign_keys=[owner_team_id])
    
    # Many-to-many relationships
    categories = db.relationship('Category', secondary='link_category', 
                               backref=db.backref('links', lazy='dynamic'))
    tags = db.relationship('Tag', secondary='link_tag',
                         backref=db.backref('links', lazy='dynamic'))
    teams = db.relationship('Team', secondary='link_team',
                          backref=db.backref('shared_links', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Link {self.title}>'

class Tag(db.Model):
    __tablename__ = 'tags'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), nullable=False, unique=True)
    color = db.Column(db.String(7), default='#64748b')  # Hex color code
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Tag {self.name}>'

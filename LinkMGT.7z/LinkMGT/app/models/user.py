from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import uuid
import string
import random

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True, nullable=False)
    email = db.Column(db.String(120), index=True, unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    ad_dn = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_global_admin = db.Column(db.Boolean, default=False)  # Nowa flaga dla administratora globalnego
    login_count = db.Column(db.Integer, default=0)
    failed_login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships will be set up in __init__.py setup_model_relationships()
    teams = db.relationship('Team', secondary='user_team', back_populates='users')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @property
    def full_name(self):
        """Return user's full name or username if not available"""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        elif self.first_name:
            return self.first_name
        elif self.last_name:
            return self.last_name
        return self.username
    
    @property
    def is_ad_user(self):
        """Check if user is from Active Directory"""
        return bool(self.ad_dn)
    
    @classmethod
    def generate_password(cls, length=16):
        """Generate a random password"""
        chars = string.ascii_letters + string.digits + "!@#$%^&*()"
        return ''.join(random.choice(chars) for _ in range(length))
    
    def get_role_in_team(self, team_id):
        """Get user's role in specific team"""
        # Import here to avoid circular imports
        from app.models import user_team
        user_team_record = db.session.query(user_team).filter(
            user_team.c.user_id == self.id,
            user_team.c.team_id == team_id
        ).first()
        
        if user_team_record:
            return user_team_record.role
        return 0  # Default role is member (0)
    
    @property
    def has_admin_rights(self):
        """Check if user has any admin rights"""
        return self.is_admin or self.is_global_admin
    
    def __repr__(self):
        return f'<User {self.username}>'

@login_manager.user_loader
def load_user(id):
    try:
        return User.query.get(int(id))
    except Exception as e:
        print(f"Error loading user: {e}")
        return None

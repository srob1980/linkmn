from app import db
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Table

# Definicja ról w zespole
ROLE_MEMBER = 0
ROLE_MODERATOR = 1
ROLE_ADMIN = 2

# Tabela asocjacyjna dla udostępniania elementów między zespołami
team_resource_share = db.Table('team_resource_share',
    db.Column('team_id', db.Integer, db.ForeignKey('teams.id'), primary_key=True),
    db.Column('resource_team_id', db.Integer, db.ForeignKey('teams.id'), primary_key=True),
    db.Column('resource_type', db.String(50), primary_key=True),
    db.Column('created_at', db.DateTime, default=datetime.utcnow),
    db.Column('created_by', db.Integer, db.ForeignKey('users.id'))
)

class Team(db.Model):
    __tablename__ = 'teams'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Primary relationship for updates
    users = db.relationship('User', secondary='user_team', back_populates='teams')
    
    # Secondary read-only relationship with overlaps parameter to silence the warning
    members = db.relationship('User', secondary='user_team', viewonly=True, overlaps="users")
    
    # Zespoły, którym udostępniamy zasoby
    shared_with_teams = db.relationship(
        'Team', 
        secondary=team_resource_share,
        primaryjoin=(id == team_resource_share.c.team_id),
        secondaryjoin=(id == team_resource_share.c.resource_team_id),
        backref=db.backref('teams_sharing_with_me', lazy='dynamic')
    )
    
    def __repr__(self):
        return f'<Team {self.name}>'
    
    def get_user_role(self, user_id):
        """Pobierz rolę użytkownika w zespole"""
        # Sprawdź, czy tabela user_team istnieje w metadanych
        if 'user_team' not in db.Model.metadata.tables:
            return None
            
        try:
            # Użyj bezpiecznej metody wykonania zapytania
            result = db.session.execute(
                db.select([db.Model.metadata.tables['user_team'].c.role])
                .where(db.and_(
                    db.Model.metadata.tables['user_team'].c.user_id == user_id,
                    db.Model.metadata.tables['user_team'].c.team_id == self.id
                ))
            ).first()
            
            if result:
                return result[0]  # Zwróć rolę
        except Exception as e:
            current_app.logger.error(f"Error getting user role: {str(e)}")
        
        return None
    
    def is_user_admin(self, user_id):
        """Sprawdź czy użytkownik jest administratorem zespołu"""
        role = self.get_user_role(user_id)
        return role == ROLE_ADMIN
    
    def is_user_moderator(self, user_id):
        """Sprawdź czy użytkownik jest moderatorem zespołu"""
        role = self.get_user_role(user_id)
        return role in [ROLE_ADMIN, ROLE_MODERATOR]
    
    def can_user_manage_members(self, user_id):
        """Sprawdź czy użytkownik może zarządzać członkami zespołu"""
        # Import tutaj, aby uniknąć circular imports
        from flask_login import current_user
        
        # Globalny administrator zawsze może zarządzać członkami
        if hasattr(current_user, 'is_admin') and current_user.is_admin:
            return True
            
        # Administrator zespołu może zarządzać członkami
        return self.is_user_admin(user_id)
    
    def can_user_manage_resources(self, user_id):
        """Sprawdź czy użytkownik może zarządzać zasobami zespołu"""
        from flask_login import current_user
    
        # Globalny administrator zawsze może zarządzać zasobami
        if hasattr(current_user, 'is_global_admin') and current_user.is_global_admin:
            return True
            
        # Administrator zawsze może zarządzać zasobami
        if hasattr(current_user, 'is_admin') and current_user.is_admin:
            return True
            
        # Administrator lub moderator zespołu może zarządzać zasobami
        return self.is_user_moderator(user_id)
    
    def can_user_share_resources(self, user_id):
        """Sprawdź czy użytkownik może udostępniać zasoby innym zespołom"""
        return self.can_user_manage_resources(user_id)

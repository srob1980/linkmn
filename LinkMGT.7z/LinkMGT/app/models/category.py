from app import db
from datetime import datetime

class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    icon = db.Column(db.String(50), default='folder')
    color = db.Column(db.String(7), default='#6c757d')  # HEX color
    sort_order = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    
    # Hierarchia kategorii
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    
    # Add owner_team_id field
    owner_team_id = db.Column(db.Integer, db.ForeignKey('teams.id'))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - defined in __init__.py setup
    children = db.relationship('Category', backref=db.backref('parent', remote_side=[id]))
    
    # Add relationship to Team
    owner_team = db.relationship('Team', foreign_keys=[owner_team_id])
    
    def __repr__(self):
        return f'<Category {self.name}>'

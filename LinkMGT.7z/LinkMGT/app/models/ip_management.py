from app import db
from datetime import datetime
import socket
import ipaddress
from sqlalchemy.dialects.postgresql import INET, MACADDR
from sqlalchemy.types import TypeDecorator, VARCHAR
from flask import current_app
import re

# Custom type for MACADDR that handles NULL values properly
class MacAddr(TypeDecorator):
    impl = VARCHAR
    
    def load_dialect_impl(self, dialect):
        if dialect.name == 'postgresql':
            return dialect.type_descriptor(MACADDR())
        else:
            return dialect.type_descriptor(VARCHAR(17))
    
    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if dialect.name == 'postgresql':
            # Ensure correct format for PostgreSQL's macaddr type
            if re.match(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$', value):
                return value
            else:
                return None
        return value

# Custom type for INET that handles IP addresses properly
class InetAddress(TypeDecorator):
    impl = VARCHAR
    
    def load_dialect_impl(self, dialect):
        if dialect.name == 'postgresql':
            return dialect.type_descriptor(INET())
        else:
            return dialect.type_descriptor(VARCHAR(45))
    
    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        return value

class Subnet(db.Model):
    """Model for IP subnets"""
    __tablename__ = 'subnets'
    
    id = db.Column(db.Integer, primary_key=True)
    network = db.Column(db.String(50), nullable=False, unique=True)  # e.g. "192.168.1.0/24"
    description = db.Column(db.Text)
    vlan = db.Column(db.Integer)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    ip_addresses = db.relationship('IPAddress', backref='subnet', lazy='dynamic', cascade='all, delete-orphan')
    
    @property
    def total_ip_count(self):
        """Get total number of possible IPs in subnet"""
        try:
            network = ipaddress.ip_network(self.network)
            # Exclude network and broadcast addresses
            return network.num_addresses - 2
        except Exception:
            return 0

    @property
    def stats(self):
        """Get subnet statistics"""
        try:
            # Get all IP addresses for this subnet
            all_ips = self.ip_addresses
            
            # Count by status
            used = sum(1 for ip in all_ips if ip.status == 'used')
            reserved = sum(1 for ip in all_ips if ip.status == 'reserved')
            free = sum(1 for ip in all_ips if ip.status == 'free')
            
            # Calculate total available IPs in subnet
            network = ipaddress.ip_network(self.network)
            total = network.num_addresses - 2  # Exclude network and broadcast addresses
            
            # If there are unallocated IPs, add them to free count
            unallocated = total - self.ip_addresses.count()
            if unallocated > 0:
                free += unallocated
            
            return {
                'total': total,
                'used': used,
                'reserved': reserved,
                'free': free
            }
            
        except Exception as e:
            current_app.logger.error(f"Error calculating subnet stats: {str(e)}")
            return {
                'total': 0,
                'used': 0,
                'reserved': 0,
                'free': 0
            }

    def get_next_available_ip(self):
        """Get next available IP in subnet"""
        available = self.get_available_ips()
        return available[0] if available else None

class IPAddress(db.Model):
    """Model for managing IP addresses"""
    __tablename__ = 'ip_addresses'
    
    id = db.Column(db.Integer, primary_key=True)
    address = db.Column(InetAddress, nullable=False)  # Use custom type for PostgreSQL compatibility
    subnet_id = db.Column(db.Integer, db.ForeignKey('subnets.id'), nullable=False)
    hostname = db.Column(db.String(255))
    status = db.Column(db.String(20), default='free')
    description = db.Column(db.Text)
    mac_address = db.Column(MacAddr)  # Using custom type for PostgreSQL compatibility
    dns_ptr = db.Column(db.String(255))
    last_seen = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    notes = db.Column(db.Text)
    
    __table_args__ = (
        db.UniqueConstraint('address', 'subnet_id', name='_address_subnet_uc'),
    )
    
    @staticmethod
    def get_ptr(address):
        """Get PTR record for IP address"""
        try:
            import socket
            return socket.gethostbyaddr(str(address))[0]
        except (socket.herror, socket.gaierror):
            return None
        except Exception:
            return None

    def is_alive(self):
        """Check if IP responds to ping"""
        try:
            import platform
            import subprocess
            
            # Ensure address is string
            ip_str = str(self.address)
            
            if platform.system().lower() == 'windows':
                command = ['ping', '-n', '1', '-w', '1000', ip_str]
            else:
                command = ['ping', '-c', '1', '-W', '1', ip_str]
            
            result = subprocess.run(command, 
                                stdout=subprocess.DEVNULL, 
                                stderr=subprocess.DEVNULL,
                                timeout=2)  # 2 second timeout
            return result.returncode == 0
        except Exception:
            return False

    def update_status(self):
        """Update IP status based on ping and PTR"""
        try:
            self.last_seen = None
            is_alive = self.is_alive()
            
            if is_alive:
                self.status = 'used'
                self.last_seen = datetime.utcnow()
                
                # Try to get hostname from PTR
                ptr_hostname = self.get_ptr(self.address)
                if ptr_hostname and not self.hostname:
                    self.hostname = ptr_hostname
            else:
                # Only change to free if it was previously used
                if self.status == 'used':
                    self.status = 'free'
                    
            return True
        except Exception as e:
            current_app.logger.error(f"Error updating IP status: {str(e)}")
            return False
    
    def __repr__(self):
        return f'<IPAddress {self.address}>'

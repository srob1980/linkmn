from app import db

# Association tables - define them first before models
user_team = db.Table('user_team',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('team_id', db.Integer, db.ForeignKey('teams.id'), primary_key=True),
    db.Column('role', db.Integer, default=0),
    db.Column('joined_at', db.DateTime, default=db.func.current_timestamp())
)

link_category = db.Table('link_category',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('category_id', db.Integer, db.ForeignKey('categories.id'), primary_key=True)
)

link_tag = db.Table('link_tag',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tags.id'), primary_key=True)
)

link_team = db.Table('link_team',
    db.Column('link_id', db.Integer, db.ForeignKey('links.id'), primary_key=True),
    db.Column('team_id', db.Integer, db.ForeignKey('teams.id'), primary_key=True),
    db.Column('added_at', db.DateTime, default=db.func.current_timestamp())
)

# Import the models after association tables are defined
from app.models.user import User
from app.models.team import Team
from app.models.link import Link, Tag
from app.models.category import Category

# Try to import other models
try:
    from app.models.config import AppConfig
    from app.models.activity_log import ActivityLog
    from app.models.infrastructure import Asset, License, SupportContract
    from app.models.ip_management import Subnet, IPAddress
    
    # Try to import additional infrastructure models
    try:
        from app.models.infrastructure import (
            AssetType, AssetStatus, Location, Vendor, 
            MaintenanceLog
        )
        __all__ = [
            'User', 'Team', 'Link', 'Category', 'Tag',
            'Asset', 'AssetType', 'AssetStatus', 'Location', 'Vendor',
            'License', 'SupportContract', 'MaintenanceLog',
            'AppConfig', 'ActivityLog', 'Subnet', 'IPAddress',
            'user_team', 'link_category', 'link_tag', 'link_team'
        ]
    except ImportError:
        __all__ = [
            'User', 'Team', 'Link', 'Category', 'Tag',
            'Asset', 'License', 'SupportContract',
            'AppConfig', 'ActivityLog', 'Subnet', 'IPAddress',
            'user_team', 'link_category', 'link_tag', 'link_team'
        ]
except ImportError:
    # Minimal set if infrastructure models are not available
    __all__ = [
        'User', 'Team', 'Link', 'Category', 'Tag',
        'user_team', 'link_category', 'link_tag', 'link_team'
    ]

# Dodanie kolumny owner_team_id do tabeli linków
if 'links' in db.Model.metadata.tables:
    if 'owner_team_id' not in db.Model.metadata.tables['links'].columns:
        from sqlalchemy import Column, Integer, ForeignKey
        db.Model.metadata.tables['links'].append_column(
            Column('owner_team_id', Integer, ForeignKey('teams.id'))
        )

# Podobnie dla kategorii
if 'categories' in db.Model.metadata.tables:
    if 'owner_team_id' not in db.Model.metadata.tables['categories'].columns:
        from sqlalchemy import Column, Integer, ForeignKey
        db.Model.metadata.tables['categories'].append_column(
            Column('owner_team_id', Integer, ForeignKey('teams.id'))
        )

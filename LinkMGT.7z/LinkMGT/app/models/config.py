from app import db
from datetime import datetime
import json

class AppConfig(db.Model):
    """Configuration model"""
    __tablename__ = 'app_config'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), nullable=False, unique=True)
    value = db.Column(db.Text, nullable=False)
    description = db.Column(db.String(256))
    category = db.Column(db.String(50), default='general')
    type = db.Column(db.String(20), default='string')
    is_sensitive = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_value(cls, key, default=None, as_type=None):
        """Get configuration value with type conversion"""
        config = cls.query.filter_by(key=key).first()
        if not config:
            return default
            
        value = config.value
        
        # Convert value based on type
        if as_type == bool or config.type == 'bool':
            return value.lower() in ('true', '1', 't', 'yes')
        elif as_type == int or config.type == 'int':
            try:
                return int(value)
            except ValueError:
                return default
        elif as_type == 'json' or config.type == 'json':
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return default
                
        return value
    
    @classmethod
    def set_value(cls, key, value, description=None, category='general', type='string', is_sensitive=False):
        """Set configuration value"""
        config = cls.query.filter_by(key=key).first()
        
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
            type = 'json'
        elif isinstance(value, bool):
            value = str(value).lower()
            type = 'bool'
        elif isinstance(value, int):
            value = str(value)
            type = 'int'
        else:
            value = str(value)
        
        if config:
            config.value = value
            if description:
                config.description = description
            config.category = category
            config.type = type
            config.is_sensitive = is_sensitive
            config.updated_at = datetime.utcnow()
        else:
            config = cls(
                key=key,
                value=value,
                description=description,
                category=category,
                type=type,
                is_sensitive=is_sensitive
            )
            db.session.add(config)
        
        try:
            db.session.commit()
            return True
        except Exception:
            db.session.rollback()
            return False

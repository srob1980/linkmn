from app import db
from datetime import datetime

class DatabaseBackup(db.Model):
    """Model to track database backups"""
    __tablename__ = 'database_backups'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    path = db.Column(db.String(512), nullable=False)
    db_type = db.Column(db.String(50), nullable=False)
    size_bytes = db.Column(db.BigInteger, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    description = db.Column(db.Text)
    is_auto = db.Column(db.Boolean, default=False)
    status = db.Column(db.String(20), default='completed')  # completed, failed
    
    # Relationships
    creator = db.relationship('User', foreign_keys=[created_by])
    
    def __repr__(self):
        return f'<DatabaseBackup {self.filename}>'
    
    @property
    def size_formatted(self):
        """Return human-readable file size"""
        size = self.size_bytes
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024 or unit == 'TB':
                return f"{size:.2f} {unit}"
            size /= 1024

from flask import render_template, redirect, url_for, flash, request, current_app, jsonify, send_from_directory
from flask_login import login_required, current_user
from sqlalchemy import text, desc, create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os
import shutil
from app import db
from app.admin import bp
from app.auth.decorators import admin_required
from app.models.config import AppConfig
from app.utils.system_monitor import SystemMonitor
from app.models.activity_log import ActivityLog
from app.models.system_log import SystemLog
from app.models.user import User  # Add this import
from app.models.ip_management import Subnet, IPAddress
import ipaddress
from flask import Response
from app.utils.background_tasks import TaskManager
import socket

@bp.route('/')
@login_required
@admin_required
def index():
    """Admin dashboard"""
    try:
        raw_metrics = SystemMonitor.get_system_metrics()
        
        # Format system metrics for template
        system_resources = {
            'cpu': {
                'usage_percent': round(raw_metrics['cpu']['percent'], 1),
                'cores': raw_metrics['cpu']['cores']
            },
            'memory': {
                'percent': round(raw_metrics['memory']['percent'], 1),
                'used_gb': round(raw_metrics['memory']['used'] / (1024**3), 1),
                'total_gb': round(raw_metrics['memory']['total'] / (1024**3), 1)
            },
            'disk': {
                'percent': round(raw_metrics['disk']['percent'], 1),
                'used_gb': round(raw_metrics['disk']['used'] / (1024**3), 1),
                'total_gb': round(raw_metrics['disk']['total'] / (1024**3), 1)
            }
        }
        
        recent_logs = SystemLog.query.order_by(desc(SystemLog.timestamp)).limit(10).all()
        recent_activity = ActivityLog.query.order_by(desc(ActivityLog.timestamp)).limit(10).all()
        
        return render_template('admin/index.html',
                         title='Panel Administracyjny',
                         system_resources=system_resources,
                         recent_logs=recent_logs,
                         recent_activity=recent_activity)
                         
    except Exception as e:
        current_app.logger.error(f"Error in admin dashboard: {str(e)}")
        return render_template('admin/index.html',
                         title='Panel Administracyjny',
                         system_resources={
                             'cpu': {'usage_percent': 0, 'cores': 0},
                             'memory': {'percent': 0, 'used_gb': 0, 'total_gb': 0},
                             'disk': {'percent': 0, 'used_gb': 0, 'total_gb': 0}
                         },
                         recent_logs=[],
                         recent_activity=[])

@bp.route('/monitor')
@login_required
@admin_required
def monitor():
    """System monitoring page"""
    try:
        metrics = SystemMonitor.get_system_metrics()
        return render_template('admin/monitor.html', 
                            title='System Monitor',
                            metrics=metrics)
    except Exception as e:
        current_app.logger.error(f"Error in system monitor: {str(e)}")
        flash('Error loading system metrics', 'danger')
        return redirect(url_for('admin.index'))

@bp.route('/metrics')
@login_required
@admin_required
def metrics():
    """Get system metrics"""
    try:
        metrics = SystemMonitor.get_system_metrics()
        return jsonify({
            'success': True,
            'data': {
                'cpu': {
                    'usage': metrics['cpu']['percent'],
                    'cores': metrics['cpu']['cores']
                },
                'memory': {
                    'total': metrics['memory']['total'],
                    'used': metrics['memory']['used'],
                    'percent': metrics['memory']['percent']
                },
                'disk': {
                    'total': metrics['disk']['total'],
                    'used': metrics['disk']['used'],
                    'percent': metrics['disk']['percent']
                },
                'timestamp': datetime.now().isoformat()
            }
        })
    except Exception as e:
        current_app.logger.error(f"Error getting metrics: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@bp.route('/system-monitor')
@login_required
@admin_required
def system_monitor():
    """System monitoring page"""
    metrics = SystemMonitor.get_system_metrics()
    latest_logs = SystemLog.query.order_by(SystemLog.timestamp.desc()).limit(50).all()
    return render_template('admin/system_monitor.html',
                         title='Monitoring systemu',
                         metrics=metrics,
                         logs=latest_logs)

@bp.route('/configuration')
@login_required
@admin_required
def configuration():
    """System configuration page"""
    try:
        # Get current database config
        db_config = {
            'type': 'sqlite',  # default value
            'host': '',
            'port': '',
            'name': '',
            'user': '',
            'path': ''
        }

        # Parse current database URL
        db_url = AppConfig.get_value('DATABASE_URL', '')
        if db_url:
            if db_url.startswith('sqlite:///'):
                db_config['type'] = 'sqlite'
                db_config['path'] = db_url.replace('sqlite:///', '')
            else:
                # Parse other database URLs
                import re
                match = re.match(r'(\w+)://(\w+):(.+)@([^:]+):?(\d*)/(.+)', db_url)
                if match:
                    db_config.update({
                        'type': match.group(1),
                        'user': match.group(2),
                        'host': match.group(4),
                        'port': match.group(5),
                        'name': match.group(6)
                    })

        # Get AD configuration
        ad_config = {
            'enabled': AppConfig.get_value('AD_ENABLED', 'false') == 'true',
            'server': AppConfig.get_value('AD_SERVER', ''),
            'domain': AppConfig.get_value('AD_DOMAIN', ''),
            'base_dn': AppConfig.get_value('AD_BASE_DN', ''),
            'admin_group': AppConfig.get_value('AD_ADMIN_GROUP', ''),
            'sync_groups': AppConfig.get_value('AD_SYNC_GROUPS', 'false') == 'true'
        }

        # Get system configuration
        system_config = {
            'app_name': AppConfig.get_value('APP_NAME', 'LinkMGT'),
            'app_version': AppConfig.get_value('APP_VERSION', '1.0.0'),
            'app_description': AppConfig.get_value('APP_DESCRIPTION', ''),
            'items_per_page': AppConfig.get_value('ITEMS_PER_PAGE', '10')
        }

        # Get all configs grouped by category
        configs_by_category = {}
        for config in AppConfig.query.order_by(AppConfig.category, AppConfig.key).all():
            category = config.category or 'other'
            if category not in configs_by_category:
                configs_by_category[category] = []
            configs_by_category[category].append(config)

        context = {
            'title': 'Konfiguracja systemu',
            'db_config': db_config,
            'ad_config': ad_config,
            'system_config': system_config,
            'configs_by_category': configs_by_category,
            'categories': sorted(configs_by_category.keys())
        }

        return render_template('admin/configuration.html', **context)

    except Exception as e:
        current_app.logger.error(f"Error in configuration view: {str(e)}")
        flash('Błąd podczas ładowania konfiguracji.', 'danger')
        return redirect(url_for('admin.index'))

@bp.route('/system/logs')
@login_required
@admin_required
def system_logs():
    """System logs view - renamed from 'logs' to avoid conflict"""
    page = request.args.get('page', 1, type=int)
    level = request.args.get('level')
    source = request.args.get('source')
    
    query = SystemLog.query
    
    if level:
        query = query.filter_by(level=level)
    if source:
        query = query.filter_by(source=source)
        
    logs = query.order_by(SystemLog.timestamp.desc()).paginate(
        page=page, per_page=current_app.config.get('ITEMS_PER_PAGE', 50)
    )
    
    return render_template('admin/logs.html',
                         title='Logi systemowe',
                         logs=logs,
                         level=level,
                         source=source)

@bp.route('/activity/logs')
@login_required
@admin_required
def activity_logs():
    """Activity logs view - separate from system logs"""
    page = request.args.get('page', 1, type=int)
    user_id = request.args.get('user_id', type=int)
    action = request.args.get('action')
    
    query = ActivityLog.query
    
    if user_id:
        query = query.filter_by(user_id=user_id)
    if action:
        query = query.filter_by(action=action)
        
    logs = query.order_by(ActivityLog.timestamp.desc()).paginate(
        page=page, per_page=current_app.config.get('ITEMS_PER_PAGE', 50)
    )
    
    return render_template('admin/activity_logs.html',
                         title='Logi aktywności',
                         logs=logs,
                         user_id=user_id,
                         action=action)

@bp.route('/users')
@login_required
@admin_required
def users():
    """Lista użytkowników i zarządzanie nimi"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('ITEMS_PER_PAGE', 10)
    query = User.query
    
    search = request.args.get('q', '')
    if search:
        query = query.filter(
            (User.username.ilike(f'%{search}%')) | 
            (User.email.ilike(f'%{search}%')) |
            (User.first_name.ilike(f'%{search}%')) |
            (User.last_name.ilike(f'%{search}%'))
        )
    
    users = query.order_by(User.username).paginate(page=page, per_page=per_page)
    
    return render_template('admin/users.html',
                          title='Zarządzanie Użytkownikami',
                          users=users,
                          search=search)

@bp.route('/users/<int:id>/toggle-admin', methods=['POST'])
@login_required
@admin_required
def toggle_admin(id):
    """Włącz/wyłącz uprawnienia administratora dla użytkownika"""
    user = User.query.get_or_404(id)
    
    # Prevent removing admin from yourself
    if user.id == current_user.id:
        flash('Nie możesz odebrać uprawnień administratora samemu sobie.', 'warning')
        return redirect(url_for('admin.users'))
    
    user.is_admin = not user.is_admin
    db.session.commit()
    
    action = 'przyznane' if user.is_admin else 'odebrane'
    flash(f'Uprawnienia administratora zostały {action} dla użytkownika {user.username}.', 'success')
    
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:id>/toggle-global-admin', methods=['POST'])
@login_required
@admin_required
def toggle_global_admin(id):
    """Włącz/wyłącz uprawnienia administratora globalnego dla użytkownika"""
    user = User.query.get_or_404(id)
    
    # Tylko globalny admin może nadawać/odbierać uprawnienia globalnego admina
    if not current_user.is_global_admin:
        flash('Nie masz uprawnień do zarządzania administratorami globalnymi.', 'warning')
        return redirect(url_for('admin.users'))
    
    # Prevent removing global admin from yourself
    if user.id == current_user.id:
        flash('Nie możesz odebrać uprawnień administratora globalnego samemu sobie.', 'warning')
        return redirect(url_for('admin.users'))
    
    user.is_global_admin = not user.is_global_admin
    db.session.commit()
    
    action = 'przyznane' if user.is_global_admin else 'odebrane'
    flash(f'Uprawnienia administratora globalnego zostały {action} dla użytkownika {user.username}.', 'success')
    
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:id>/toggle-active', methods=['POST'])
@login_required
@admin_required
def toggle_active(id):
    """Toggle user active status"""
    user = User.query.get_or_404(id)
    
    # Prevent deactivating yourself
    if user.id == current_user.id:
        flash('Nie możesz dezaktywować własnego konta.', 'warning')
        return redirect(url_for('admin.users'))
    
    user.is_active = not user.is_active
    db.session.commit()
    
    status = 'aktywowane' if user.is_active else 'dezaktywowane'
    flash(f'Konto użytkownika {user.username} zostało {status}.', 'success')
    
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:id>/reset-password', methods=['POST'])
@login_required
@admin_required
def reset_user_password(id):
    """Resetuj hasło użytkownika"""
    user = User.query.get_or_404(id)
    
    # Generate a random password - in production you might want to email this
    # or implement a more secure reset mechanism
    new_password = 'ResetPassword123!'
    user.set_password(new_password)
    db.session.commit()
    
    flash(f'Hasło użytkownika {user.username} zostało zresetowane. Nowe hasło: {new_password}', 'success')
    
    return redirect(url_for('admin.users'))

@bp.route('/ssl-config', methods=['GET', 'POST'])
@login_required
@admin_required
def ssl_config():
    """SSL configuration"""
    ssl_manager = SSLManager()
    if request.method == 'POST':
        action = request.form.get('action')
        try:
            if action == 'upload_cert':
                cert_file = request.files.get('ssl_cert')
                success, message = ssl_manager.save_certificate(cert_file, 'cert')
            elif action == 'upload_key':
                key_file = request.files.get('ssl_key')
                success, message = ssl_manager.save_certificate(key_file, 'key')
            elif action == 'save_config':
                # Save SSL configuration
                AppConfig.set_value('USE_SSL', request.form.get('use_ssl', 'false'))
                AppConfig.set_value('SSL_PORT', request.form.get('ssl_port', '443'))
                success, message = True, 'Konfiguracja zapisana'
            
            flash(message, 'success' if success else 'danger')
        except Exception as e:
            flash(f'Błąd: {str(e)}', 'danger')
            
        return redirect(url_for('admin.ssl_config'))
    
    return render_template('admin/ssl_config.html',
                         title='Konfiguracja SSL',
                         current_cert=ssl_manager.get_certificate_info('cert.pem'),
                         current_key=ssl_manager.get_certificate_info('key.pem'),
                         ssl_enabled=AppConfig.get_value('USE_SSL', 'false').lower() == 'true',
                         ssl_port=AppConfig.get_value('SSL_PORT', '443'))

@bp.route('/system-info')
@login_required
@admin_required
def system_info():
    """System information page"""
    from app.utils.system import get_system_info
    info = get_system_info()
    return render_template('admin/system_info.html',
                         title='Informacje o systemie',
                         system_info=info)

@bp.route('/update_config', methods=['POST'])
@login_required
@admin_required
def update_config():
    """Update application configuration"""
    from app.models.config import AppConfig
    
    config_id = request.form.get('id')
    new_value = request.form.get('value')
    
    if not config_id or not new_value:
        flash('Brak wymaganych danych', 'danger')
        return redirect(url_for('admin.configuration'))
    
    try:
        config = AppConfig.query.get(config_id)
        if not config:
            flash('Nie znaleziono konfiguracji', 'danger')
            return redirect(url_for('admin.configuration'))
        
        config.value = new_value
        config.updated_at = datetime.utcnow()
        db.session.commit()
        
        flash(f'Konfiguracja {config.key} została zaktualizowana', 'success')
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error updating config: {e}")
        flash(f'Błąd: {str(e)}', 'danger')
    
    return redirect(url_for('admin.configuration'))

@bp.route('/update_db_config', methods=['POST'])
@login_required
@admin_required
def update_db_config():
    """Update database configuration"""
    from app.models.config import AppConfig
    
    # Build database URL based on form data
    db_type = request.form.get('db_type')
    
    try:
        if db_type == 'sqlite':
            # SQLite configuration
            sqlite_path = request.form.get('sqlite_path')
            if not sqlite_path:
                flash('Ścieżka do pliku SQLite jest wymagana', 'danger')
                return redirect(url_for('admin.configuration'))
            
            # Ensure correct format
            if sqlite_path.startswith('sqlite:///'):
                db_url = sqlite_path
            else:
                db_url = f'sqlite:///{sqlite_path}'
        else:
            # Other database types
            db_host = request.form.get('db_host')
            db_port = request.form.get('db_port')
            db_name = request.form.get('db_name')
            db_user = request.form.get('db_user')
            db_password = request.form.get('db_password')
            
            if not all([db_host, db_name, db_user]):
                flash('Host, nazwa bazy danych i użytkownik są wymagane', 'danger')
                return redirect(url_for('admin.configuration'))
            
            # Build connection URL
            if db_port:
                db_url = f'{db_type}://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}'
            else:
                db_url = f'{db_type}://{db_user}:{db_password}@{db_host}/{db_name}'
            
            # Special handling for Oracle
            if db_type == 'oracle' and request.form.get('oracle_thick_mode'):
                db_url += '?thick_mode=True'
        
        # Save to AppConfig
        db_config = AppConfig.query.filter_by(key='DATABASE_URL').first()
        if not db_config:
            db_config = AppConfig(
                key='DATABASE_URL',
                value=db_url,
                description='Database connection URL',
                category='database',
                is_sensitive=True
            )
            db.session.add(db_config)
        else:
            db_config.value = db_url
        
        # Save fallback URL
        db_fallback = request.form.get('db_fallback')
        fallback_config = AppConfig.query.filter_by(key='DATABASE_URL_FALLBACK').first()
        if not fallback_config:
            fallback_config = AppConfig(
                key='DATABASE_URL_FALLBACK',
                value=db_fallback,
                description='Fallback database URL',
                category='database',
                is_sensitive=True
            )
            db.session.add(fallback_config)
        else:
            fallback_config.value = db_fallback
        
        # Save pool settings
        pool_pre_ping = request.form.get('db_pool_pre_ping', 'off') == 'on'
        pool_recycle = request.form.get('db_pool_recycle', '300')
        pool_timeout = request.form.get('db_pool_timeout', '30')
        
        for key, value in [
            ('DB_POOL_PRE_PING', 'true' if pool_pre_ping else 'false'),
            ('DB_POOL_RECYCLE', pool_recycle),
            ('DB_POOL_TIMEOUT', pool_timeout)
        ]:
            config = AppConfig.query.filter_by(key=key).first()
            if not config:
                config = AppConfig(
                    key=key,
                    value=str(value),
                    description=f'Database pool setting: {key}',
                    category='database'
                )
                db.session.add(config)
            else:
                config.value = str(value)
        
        db.session.commit()
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='update_database_config',
            details=f'Updated database configuration to {db_type}',
            severity='INFO'
        )
        
        flash('Konfiguracja bazy danych została zaktualizowana', 'success')
        
        # Note that database changes will apply after restart
        flash('Zmiany zostaną zastosowane po ponownym uruchomieniu aplikacji', 'info')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error updating DB config: {e}")
        flash(f'Błąd podczas aktualizacji konfiguracji bazy danych: {str(e)}', 'danger')
    
    return redirect(url_for('admin.configuration'))

@bp.route('/update_ad_config', methods=['POST'])
@login_required
@admin_required
def update_ad_config():
    """Update Active Directory configuration"""
    from app.models.config import AppConfig
    
    # Get form data
    ad_enabled = request.form.get('ad_enabled', '0') == '1'
    ad_server = request.form.get('ad_server', '')
    ad_domain = request.form.get('ad_domain', '')
    ad_base_dn = request.form.get('ad_base_dn', '')
    ad_user_prefix = request.form.get('ad_user_prefix', '')
    ad_use_upn = request.form.get('ad_use_upn', '0') == '1'
    ad_service_user = request.form.get('ad_service_user', '')
    ad_service_password = request.form.get('ad_service_password', '')
    ad_admin_group = request.form.get('ad_admin_group', '')
    ad_sync_groups = request.form.get('ad_sync_groups', '0') == '1'
    ad_auto_create_teams = request.form.get('ad_auto_create_teams', '0') == '1'
    ad_team_prefix = request.form.get('ad_team_prefix', '')
    
    try:
        # Update or create each config item
        config_items = [
            ('AD_ENABLED', 'true' if ad_enabled else 'false', 'Enable Active Directory integration'),
            ('AD_SERVER', ad_server, 'AD server LDAP URL'),
            ('AD_DOMAIN', ad_domain, 'AD domain name'),
            ('AD_BASE_DN', ad_base_dn, 'AD base DN for searches'),
            ('AD_USER_PREFIX', ad_user_prefix, 'AD user prefix (CN= or empty)'),
            ('AD_USE_UPN', 'true' if ad_use_upn else 'false', 'Use UPN for login (user@domain)'),
            ('AD_ADMIN_GROUP', ad_admin_group, 'AD group for admin users'),
            ('AD_SYNC_GROUPS', 'true' if ad_sync_groups else 'false', 'Sync AD groups to teams'),
            ('AD_AUTO_CREATE_TEAMS', 'true' if ad_auto_create_teams else 'false', 'Auto-create teams from AD groups'),
            ('AD_TEAM_PREFIX', ad_team_prefix, 'AD group prefix for team creation')
        ]
        
        for key, value, description in config_items:
            config = AppConfig.query.filter_by(key=key).first()
            if not config:
                config = AppConfig(
                    key=key,
                    value=value,
                    description=description,
                    category='ad'
                )
                db.session.add(config)
            else:
                config.value = value
                
        # Handle service account credentials (sensitive data)
        if ad_service_user:
            service_user_config = AppConfig.query.filter_by(key='AD_SERVICE_USER').first()
            if not service_user_config:
                service_user_config = AppConfig(
                    key='AD_SERVICE_USER',
                    value=ad_service_user,
                    description='AD service account username',
                    category='ad',
                    is_sensitive=True
                )
                db.session.add(service_user_config)
            else:
                service_user_config.value = ad_service_user
                
        # Only update password if provided (to avoid clearing it)
        if ad_service_password:
            service_pw_config = AppConfig.query.filter_by(key='AD_SERVICE_PASSWORD').first()
            if not service_pw_config:
                service_pw_config = AppConfig(
                    key='AD_SERVICE_PASSWORD',
                    value=ad_service_password,
                    description='AD service account password',
                    category='ad',
                    is_sensitive=True
                )
                db.session.add(service_pw_config)
            else:
                service_pw_config.value = ad_service_password
                
        db.session.commit()
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='update_ad_config',
            details=f'Updated Active Directory configuration (enabled: {ad_enabled})',
            severity='INFO'
        )
        
        flash('Konfiguracja Active Directory została zaktualizowana', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error updating AD config: {e}")
        flash(f'Błąd podczas aktualizacji konfiguracji: {str(e)}', 'danger')
        
    return redirect(url_for('admin.configuration'))

@bp.route('/update_system_config', methods=['POST'])
@login_required
@admin_required
def update_system_config():
    """Update system configuration"""
    from app.models.config import AppConfig
    
    # Get form data
    app_name = request.form.get('app_name', 'LinkMGT')
    app_version = request.form.get('app_version', '1.0.0')
    enable_registration = request.form.get('enable_registration', '0') == '1'
    allow_password_reset = request.form.get('allow_password_reset', '0') == '1'
    items_per_page = request.form.get('items_per_page', '10')
    allow_public_links = request.form.get('allow_public_links', '0') == '1'
    max_links_per_user = request.form.get('max_links_per_user', '1000')
    
    try:
        # Update or create each config item
        config_items = [
            ('APP_NAME', app_name, 'Application name'),
            ('APP_VERSION', app_version, 'Application version'),
            ('ENABLE_REGISTRATION', 'true' if enable_registration else 'false', 'Allow new user registration'),
            ('ALLOW_PASSWORD_RESET', 'true' if allow_password_reset else 'false', 'Allow users to reset passwords'),
            ('ITEMS_PER_PAGE', items_per_page, 'Items per page in lists'),
            ('ALLOW_PUBLIC_LINKS', 'true' if allow_public_links else 'false', 'Allow users to create public links'),
            ('MAX_LINKS_PER_USER', max_links_per_user, 'Maximum links per user')
        ]
        
        for key, value, description in config_items:
            config = AppConfig.query.filter_by(key=key).first()
            if not config:
                config = AppConfig(
                    key=key,
                    value=value,
                    description=description,
                    category='system'
                )
                db.session.add(config)
            else:
                config.value = value
                
        db.session.commit()
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='update_system_config',
            details=f'Updated system configuration',
            severity='INFO'
        )
        
        flash('Konfiguracja systemu została zaktualizowana', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error updating system config: {e}")
        flash(f'Błąd podczas aktualizacji konfiguracji: {str(e)}', 'danger')
        
    return redirect(url_for('admin.configuration'))

@bp.route('/add_config', methods=['POST'])
@login_required
@admin_required
def add_config():
    """Add new configuration item"""
    from app.models.config import AppConfig
    
    key = request.form.get('key', '').strip().upper()
    value = request.form.get('value', '')
    description = request.form.get('description', '')
    category = request.form.get('category', 'custom').lower()
    is_sensitive = request.form.get('is_sensitive', '0') == '1'
    
    # Validate input
    if not key or not value:
        flash('Klucz i wartość są wymagane', 'danger')
        return redirect(url_for('admin.configuration'))
    
    # Check if key already exists
    existing = AppConfig.query.filter_by(key=key).first()
    if existing:
        flash(f'Klucz konfiguracji "{key}" już istnieje', 'danger')
        return redirect(url_for('admin.configuration'))
    
    try:
        config = AppConfig(
            key=key,
            value=value,
            description=description,
            category=category,
            is_sensitive=is_sensitive
        )
        db.session.add(config)
        db.session.commit()
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='add_config',
            details=f'Added new configuration key: {key}',
            severity='INFO'
        )
        
        flash(f'Dodano nowy klucz konfiguracji: {key}', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error adding config: {e}")
        flash(f'Błąd podczas dodawania konfiguracji: {str(e)}', 'danger')
    
    return redirect(url_for('admin.configuration'))

@bp.route('/delete_config/<int:config_id>', methods=['POST'])
@login_required
@admin_required
def delete_config(config_id):
    """Delete configuration item"""
    from app.models.config import AppConfig
    
    config = AppConfig.query.get_or_404(config_id)
    
    # Prevent deletion of critical system configs
    critical_keys = ['APP_NAME', 'APP_VERSION', 'DATABASE_URL']
    if config.key in critical_keys:
        flash(f'Nie można usunąć kluczowej konfiguracji: {config.key}', 'danger')
        return redirect(url_for('admin.configuration'))
    
    try:
        key = config.key  # Save for logging
        db.session.delete(config)
        db.session.commit()
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='delete_config',
            details=f'Deleted configuration key: {key}',
            severity='WARNING'
        )
        
        flash(f'Usunięto klucz konfiguracji: {key}', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting config: {e}")
        flash(f'Błąd podczas usuwania konfiguracji: {str(e)}', 'danger')
    
    return redirect(url_for('admin.configuration'))

@bp.route('/export_config', methods=['GET'])
@login_required
@admin_required
def export_config():
    """Export configuration to a file"""
    from app.models.config import AppConfig
    import json
    from flask import make_response
    
    try:
        # Get all non-sensitive configs
        configs = AppConfig.query.filter_by(is_sensitive=False).all()
        
        # Convert to dictionary
        config_dict = {config.key: {
            'value': config.value,
            'description': config.description,
            'category': config.category
        } for config in configs}
        
        # Generate JSON
        config_json = json.dumps(config_dict, indent=2)
        
        # Create response
        response = make_response(config_json)
        response.headers['Content-Type'] = 'application/json'
        response.headers['Content-Disposition'] = 'attachment; filename=linkmgt_config.json'
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='export_config',
            details=f'Exported configuration ({len(configs)} items)',
            severity='INFO'
        )
        
        return response
    except Exception as e:
        current_app.logger.error(f"Error exporting config: {e}")
        flash(f'Błąd podczas eksportu konfiguracji: {str(e)}', 'danger')
        return redirect(url_for('admin.configuration'))

@bp.route('/import_config', methods=['POST'])
@login_required
@admin_required
def import_config():
    """Import configuration from a file"""
    from app.models.config import AppConfig
    import json
    
    # Check if file was uploaded
    if 'config_file' not in request.files:
        flash('Brak pliku konfiguracyjnego', 'danger')
        return redirect(url_for('admin.configuration'))
    
    file = request.files['config_file']
    if file.filename == '':
        flash('Nie wybrano pliku', 'danger')
        return redirect(url_for('admin.configuration'))
    
    try:
        # Parse JSON
        config_dict = json.load(file)
        
        # Validate format
        if not isinstance(config_dict, dict):
            flash('Nieprawidłowy format pliku konfiguracyjnego', 'danger')
            return redirect(url_for('admin.configuration'))
        
        # Import configs
        imported_count = 0
        updated_count = 0
        
        for key, data in config_dict.items():
            value = data.get('value', '')
            description = data.get('description', '')
            category = data.get('category', 'imported')
            
            existing = AppConfig.query.filter_by(key=key).first()
            if existing:
                existing.value = value
                existing.description = description
                existing.category = category
                updated_count += 1
            else:
                config = AppConfig(
                    key=key,
                    value=value,
                    description=description,
                    category=category,
                    is_sensitive=False
                )
                db.session.add(config)
                imported_count += 1
        
        db.session.commit()
        
        # Log the activity
        from app.utils.logger import log_activity
        log_activity(
            action='import_config',
            details=f'Imported configuration ({imported_count} added, {updated_count} updated)',
            severity='INFO'
        )
        
        flash(f'Pomyślnie zaimportowano konfigurację: {imported_count} dodanych, {updated_count} zaktualizowanych', 'success')
    except json.JSONDecodeError:
        flash('Nieprawidłowy format JSON', 'danger')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error importing config: {e}")
        flash(f'Błąd podczas importu konfiguracji: {str(e)}', 'danger')
    
    return redirect(url_for('admin.configuration'))

@bp.route('/logs/download/<filename>')
@login_required
@admin_required
def download_log(filename):
    """Download log file"""
    try:
        log_dir = current_app.config['LOG_DIR']
        return send_from_directory(
            log_dir, 
            filename,
            as_attachment=True
        )
    except Exception as e:
        flash(f'Error downloading log file: {str(e)}', 'danger')
        return redirect(url_for('admin.system_logs'))

@bp.route('/logs/clear/<filename>', methods=['POST'])
@login_required
@admin_required
def clear_log(filename):
    """Clear log file contents"""
    try:
        log_dir = current_app.config['LOG_DIR']
        log_path = os.path.join(log_dir, filename)
        
        # Create backup before clearing
        backup_name = f"{filename}.{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"
        backup_path = os.path.join(log_dir, backup_name)
        
        shutil.copy2(log_path, backup_path)
        
        # Clear the file
        with open(log_path, 'w') as f:
            f.write('')
            
        flash('Log file cleared successfully. Backup created.', 'success')
    except Exception as e:
        flash(f'Error clearing log file: {str(e)}', 'danger')
        
    return redirect(url_for('admin.view_log', filename=filename))

@bp.route('/monitor/metrics')
@login_required
@admin_required
def monitor_metrics():
    """Get system metrics for monitoring"""
    try:
        period = request.args.get('period', 'hour')
        metrics = SystemMonitor.get_system_metrics()
        
        return jsonify({
            'success': True,
            'data': {
                'cpu': {
                    'usage': metrics['cpu']['percent'],
                    'cores': metrics['cpu']['cores']
                },
                'memory': {
                    'total': metrics['memory']['total'],
                    'used': metrics['memory']['used'],
                    'percent': metrics['memory']['percent']
                },
                'disk': {
                    'total': metrics['disk']['total'],
                    'used': metrics['disk']['used'],
                    'percent': metrics['disk']['percent']
                },
                'timestamp': datetime.now().isoformat()
            }
        })
    except Exception as e:
        current_app.logger.error(f"Error getting metrics: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@bp.route('/users/<int:user_id>/view')
@login_required
@admin_required
def user_view(user_id):
    """User details view"""
    user = User.query.get_or_404(user_id)
    activity_logs = ActivityLog.query.filter_by(user_id=user_id)\
        .order_by(ActivityLog.timestamp.desc())\
        .limit(50).all()
    return render_template('admin/user_view.html',
                         title=f'Użytkownik: {user.username}',
                         user=user,
                         activity_logs=activity_logs)

@bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def user_edit(user_id):
    """Edit user details"""
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        try:
            user.username = request.form.get('username')
            user.email = request.form.get('email')
            user.is_active = request.form.get('is_active') == 'on'
            user.is_admin = request.form.get('is_admin') == 'on'
            
            # Only global admin can set global admin flag
            if current_user.is_global_admin:
                user.is_global_admin = request.form.get('is_global_admin') == 'on'
            
            db.session.commit()
            flash('Użytkownik został zaktualizowany', 'success')
            return redirect(url_for('admin.users'))
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji użytkownika: {str(e)}', 'danger')
    
    return render_template('admin/user_edit.html',
                         title=f'Edycja użytkownika: {user.username}',
                         user=user)

@bp.route('/migrate_database', methods=['POST'])
@login_required
@admin_required
def migrate_database():
    """Handle database migration"""
    try:
        # Get configuration from form
        source_type = request.form.get('source_type')
        target_url = request.form.get('target_url')
        create_tables = request.form.get('create_tables') == 'on'
        drop_existing = request.form.get('drop_existing') == 'on'
        verify_data = request.form.get('verify_data') == 'on'

        # Get source URL
        if source_type == 'current':
            source_url = AppConfig.get_value('DATABASE_URL')
        else:
            source_url = request.form.get('source_url')

        if not source_url or not target_url:
            flash('Źródłowy i docelowy URL bazy danych są wymagane', 'danger')
            return redirect(url_for('admin.configuration'))

        # Create engines
        source_engine = create_engine(source_url)
        target_engine = create_engine(target_url)

        # Create sessions
        SourceSession = sessionmaker(bind=source_engine)
        TargetSession = sessionmaker(bind=target_engine)

        source_session = SourceSession()
        target_session = TargetSession()

        try:
            # Create tables if requested
            if create_tables:
                if drop_existing:
                    db.Model.metadata.drop_all(target_engine)
                db.Model.metadata.create_all(target_engine)

            # Get all models
            models = db.Model.__subclasses__()

            # Migrate each model
            for model in models:
                # Get all records from source
                records = source_session.query(model).all()
                
                # Insert into target
                for record in records:
                    # Create new instance for target DB
                    new_record = model()
                    for column in model.__table__.columns:
                        setattr(new_record, column.name, getattr(record, column.name))
                    target_session.add(new_record)
                
                target_session.commit()

                if verify_data:
                    # Verify record count
                    source_count = source_session.query(model).count()
                    target_count = target_session.query(model).count()
                    if source_count != target_count:
                        raise Exception(f"Verification failed for {model.__name__}: {source_count} != {target_count}")

            flash('Migracja bazy danych zakończona pomyślnie', 'success')
            
            # Log the activity
            log_activity(
                action='database_migration',
                details=f'Database migrated from {source_url} to {target_url}',
                severity='INFO'
            )

        finally:
            source_session.close()
            target_session.close()

    except Exception as e:
        flash(f'Błąd podczas migracji bazy danych: {str(e)}', 'danger')
        current_app.logger.error(f"Database migration error: {str(e)}")
        
    return redirect(url_for('admin.configuration'))

@bp.route('/ip-management')
@login_required
@admin_required
def ip_management():
    """IP Management dashboard"""
    subnets = Subnet.query.all()
    return render_template('admin/ip_management/index.html',
                         title='Zarządzanie IP',
                         subnets=subnets)

@bp.route('/ip-management/subnet/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_subnet():
    """Add new subnet"""
    if request.method == 'POST':
        try:
            network = request.form.get('network')
            description = request.form.get('description', '')
            vlan = request.form.get('vlan')
            
            # Validate network format
            ipaddress.ip_network(network)
            
            # Convert vlan to integer or None
            vlan = int(vlan) if vlan and vlan.strip() else None
            
            subnet = Subnet(
                network=network,
                description=description,
                vlan=vlan
            )
            db.session.add(subnet)
            db.session.commit()
            
            flash('Podsieć została dodana pomyślnie', 'success')
            return redirect(url_for('admin.ip_management'))
            
        except ValueError as e:
            db.session.rollback()
            if 'network' in str(e):
                flash('Nieprawidłowy format podsieci', 'danger')
            else:
                flash('Nieprawidłowy format VLAN', 'danger')
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas dodawania podsieci: {str(e)}', 'danger')
            
    return render_template('admin/ip_management/add_subnet.html',
                         title='Dodaj podsieć')

@bp.route('/ip-management/subnet/<int:subnet_id>')
@login_required
@admin_required
def view_subnet(subnet_id):
    """View subnet details and IPs"""
    subnet = Subnet.query.get_or_404(subnet_id)
    stats = subnet.stats
    return render_template('admin/ip_management/view_subnet.html',
                         title=f'Podsieć {subnet.network}',
                         subnet=subnet,
                         stats=stats)

@bp.route('/ip-management/ip/add', methods=['POST'])
@login_required
@admin_required
def add_ip():
    """Add new IP address"""
    try:
        subnet_id = request.form.get('subnet_id')
        address = request.form.get('address')
        description = request.form.get('description')
        
        # Validate IP format
        ipaddress.ip_address(address)
        
        ip = IPAddress(
            address=address,
            description=description,
            subnet_id=subnet_id
        )
        db.session.add(ip)
        db.session.commit()
        
        # Check status
        ip.update_status()
        db.session.commit()
        
        flash('Adres IP został dodany pomyślnie', 'success')
    except ValueError:
        flash('Nieprawidłowy format adresu IP', 'danger')
    except Exception as e:
        flash(f'Błąd podczas dodawania adresu IP: {str(e)}', 'danger')
    
    return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))

@bp.route('/ip-management/subnet/<int:subnet_id>/add-range', methods=['POST'])
@login_required
@admin_required
def add_ip_range():
    """Add range of IP addresses"""
    try:
        subnet_id = request.form.get('subnet_id')
        start_ip = request.form.get('start_ip')
        end_ip = request.form.get('end_ip')
        description = request.form.get('description')
        
        subnet = Subnet.query.get_or_404(subnet_id)
        
        # Generate IP range
        start = ipaddress.ip_address(start_ip)
        end = ipaddress.ip_address(end_ip)
        
        added_count = 0
        for ip_int in range(int(start), int(end) + 1):
            ip = ipaddress.ip_address(ip_int)
            if str(ip) not in [existing.address for existing in subnet.ip_addresses]:
                ip_addr = IPAddress(
                    address=str(ip),
                    description=description,
                    subnet_id=subnet_id
                )
                db.session.add(ip_addr)
                added_count += 1
        
        db.session.commit()
        flash(f'Dodano {added_count} adresów IP', 'success')
        
    except ValueError as e:
        flash('Nieprawidłowy format adresu IP', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas dodawania zakresu IP: {str(e)}', 'danger')
    
    return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))

@bp.route('/api/ip-management/subnet/<int:subnet_id>/scan')
@login_required
@admin_required
def scan_subnet(subnet_id):
    """Scan subnet for active hosts"""
    try:
        subnet = Subnet.query.get_or_404(subnet_id)
        
        # Update status of all IPs
        for ip in subnet.ip_addresses:
            ip.update_status()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Skanowanie zakończone'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        })

@bp.route('/ip-management/subnet/<int:subnet_id>/scan/cancel', methods=['POST'])
@login_required
@admin_required
def cancel_subnet_scan(subnet_id):
    """Cancel subnet scanning"""
    try:
        # Get task ID from session or query parameter
        task_id = request.args.get('task_id') or session.get(f'subnet_scan_task_{subnet_id}')
        
        if not task_id:
            return jsonify({
                'success': False,
                'message': 'No active scan task found'
            })

        if TaskManager.cancel_task(task_id):
            if f'subnet_scan_task_{subnet_id}' in session:
                session.pop(f'subnet_scan_task_{subnet_id}')
            return jsonify({
                'success': True,
                'message': 'Scan cancelled successfully'
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Task not found or already completed'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        })

@bp.route('/ip-management/subnet/<int:subnet_id>/scan-all', methods=['GET', 'POST'])
@login_required
@admin_required
def subnet_scan_all(subnet_id):
    """Start subnet scan in background"""
    if request.method == 'POST':
        app = current_app._get_current_object()  # Get current app instance
        
        def scan_subnet_task(task, subnet_id):
            subnet = Subnet.query.get_or_404(subnet_id)
            network = ipaddress.ip_network(subnet.network)
            total_ips = list(network.hosts())
            total = len(total_ips)
            found = 0
            processed = 0

            task['details'] = f"Scanning subnet {subnet.network}"

            for ip in total_ips:
                if task['status'] == 'cancelled':
                    break

                ip_str = str(ip)
                processed += 1
                task['progress'] = (processed / total) * 100
                task['details'] = f"Scanning {ip_str}"

                # Get or create IP address
                ip_addr = IPAddress.query.filter_by(address=ip_str, subnet_id=subnet_id).first()
                if not ip_addr:
                    ip_addr = IPAddress(address=ip_str, subnet_id=subnet_id, status='free')
                    db.session.add(ip_addr)

                if ip_addr.update_status():
                    if ip_addr.status == 'used':
                        found += 1

                if processed % 10 == 0:
                    try:
                        db.session.commit()
                        task['events'].put({
                            'progress': task['progress'],
                            'current_ip': ip_str,
                            'found': found,
                            'total': total
                        })
                    except Exception:
                        db.session.rollback()

            db.session.commit()
            return {'scanned': processed, 'found': found}

        task_id = TaskManager.start_task(scan_subnet_task, subnet_id)
        return jsonify({'task_id': task_id})
    
    # Handle SSE for GET requests
    task_id = request.args.get('task_id')
    if not task_id:
        return "No task ID provided", 400

    def generate():
        return TaskManager.get_task_events(task_id)

    return Response(generate(), mimetype='text/event-stream')

@bp.route('/tasks/status/<task_id>')
@login_required
@admin_required
def task_status(task_id):
    """Get task status"""
    task = TaskManager.get_task(task_id)
    if task:
        return jsonify(task)
    return jsonify({'error': 'Task not found'}), 404

@bp.route('/tasks/cancel/<task_id>', methods=['POST'])
@login_required
@admin_required
def cancel_task(task_id):
    """Cancel running task"""
    if TaskManager.cancel_task(task_id):
        return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Task not found or already completed'})

@bp.route('/tasks')
@login_required
@admin_required
def view_tasks():
    """View background tasks"""
    active_tasks = TaskManager.get_active_tasks()
    task_history = TaskManager.get_task_history()
    return render_template('admin/tasks.html',
                         active_tasks=active_tasks,
                         task_history=task_history)

@bp.route('/ip-management/ip/<int:ip_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_ip(ip_id):
    """Edit IP address details"""
    ip = IPAddress.query.get_or_404(ip_id)
    
    if request.method == 'POST':
        try:
            ip.hostname = request.form.get('hostname')
            ip.description = request.form.get('description')
            ip.status = request.form.get('status', ip.status)
            
            db.session.commit()
            
            flash('Adres IP został zaktualizowany', 'success')
            return redirect(url_for('admin.view_subnet', subnet_id=ip.subnet_id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji IP: {str(e)}', 'danger')
    
    # For AJAX requests, return JSON with IP details
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'id': ip.id,
            'address': ip.address,
            'hostname': ip.hostname or '',
            'status': ip.status,
            'description': ip.description or ''
        })
    
    # For regular requests, render the edit template
    return render_template('admin/ip_management/edit_ip.html',
                         ip=ip,
                         subnet=ip.subnet)

@bp.route('/ip-management/ip/<int:ip_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_ip(ip_id):
    """Delete IP address"""
    try:
        ip = IPAddress.query.get_or_404(ip_id)
        subnet_id = ip.subnet_id
        
        db.session.delete(ip)
        db.session.commit()
        
        flash('Adres IP został usunięty', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Błąd podczas usuwania adresu IP: {str(e)}', 'danger')
        
    return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))

@bp.route('/ip-management/subnet/<int:subnet_id>/generate', methods=['POST'])
@login_required
@admin_required
def generate_subnet_ips(subnet_id):
    """Generate range of IPs for subnet"""
    try:
        start_ip = request.form.get('start_ip')
        end_ip = request.form.get('end_ip')
        
        if not start_ip or not end_ip:
            flash('Początkowy i końcowy adres IP są wymagane', 'danger')
            return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))
            
        # Validate IP addresses
        start = ipaddress.ip_address(start_ip)
        end = ipaddress.ip_address(end_ip)
        
        if int(start) > int(end):
            flash('Początkowy adres IP nie może być większy niż końcowy', 'danger')
            return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))
            
        subnet = Subnet.query.get_or_404(subnet_id)
        network = ipaddress.ip_network(subnet.network)
        
        # Validate IPs are within subnet
        if start not in network or end not in network:
            flash('Adresy IP muszą znajdować się w podsieci', 'danger')
            return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))
        
        # Generate IPs
        added_count = 0
        existing_ips = {ip.address for ip in subnet.ip_addresses}
        
        for ip_int in range(int(start), int(end) + 1):
            ip = str(ipaddress.ip_address(ip_int))
            if ip not in existing_ips:
                # Create IPAddress with None for mac_address (not empty string)
                ip_addr = IPAddress(
                    address=ip,
                    subnet_id=subnet_id,
                    status='free',
                    mac_address=None  # Use None, not empty string
                )
                db.session.add(ip_addr)
                added_count += 1
                
            # Commit every 100 IPs to avoid memory issues
            if added_count % 100 == 0:
                db.session.commit()
        
        db.session.commit()
        flash(f'Wygenerowano {added_count} adresów IP', 'success')
        
    except ValueError:
        flash('Nieprawidłowy format adresu IP', 'danger')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error generating IPs: {str(e)}")
        flash(f'Wystąpił błąd podczas generowania adresów IP: {str(e)}', 'danger')
        
    return redirect(url_for('admin.view_subnet', subnet_id=subnet_id))

@bp.route('/api/ip/<int:ip_id>/details')
@login_required
@admin_required
def get_ip_details(ip_id):
    """Get IP address details"""
    try:
        ip = IPAddress.query.get_or_404(ip_id)
        if not ip:
            return jsonify({
                'error': 'IP not found'
            }), 404

        data = {
            'id': ip.id,
            'address': ip.address,
            'hostname': getattr(ip, 'hostname', '') or '',
            'status': ip.status,
            'description': getattr(ip, 'description', '') or '',
            'notes': getattr(ip, 'notes', '') or '',  # Add this line
            'ptr': getattr(ip, 'dns_ptr', '') or '',
            'last_seen': ip.last_seen.isoformat() if getattr(ip, 'last_seen', None) else None,
            'mac_address': getattr(ip, 'mac_address', '') or ''
        }
        return jsonify(data)
        
    except Exception as e:
        current_app.logger.error(f"Error getting IP details: {str(e)}")
        db.session.rollback()
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500

@bp.route('/users/add', methods=['POST'])
@login_required
@admin_required
def user_add():
    """Add new user"""
    try:
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        is_admin = request.form.get('is_admin') == 'on'
        is_global_admin = request.form.get('is_global_admin') == 'on' and current_user.is_global_admin
        is_active = request.form.get('is_active', 'on') == 'on'

        # Basic validation
        if not username or not email or not password:
            flash('Wszystkie pola są wymagane', 'danger')
            return redirect(url_for('admin.users'))

        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Użytkownik o tej nazwie już istnieje', 'danger')
            return redirect(url_for('admin.users'))

        if User.query.filter_by(email=email).first():
            flash('Email jest już używany', 'danger')
            return redirect(url_for('admin.users'))

        # Create new user
        user = User(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name,
            is_admin=is_admin,
            is_global_admin=is_global_admin,
            is_active=is_active
        )
        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        log_activity(
            action='user_created',
            user_id=current_user.id,
            details=f'Created new user: {username}',
            severity='INFO'
        )

        flash(f'Użytkownik {username} został utworzony pomyślnie', 'success')

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creating user: {str(e)}")
        flash('Wystąpił błąd podczas tworzenia użytkownika', 'danger')

    return redirect(url_for('admin.users'))

@bp.route('/ip-management/subnet/<int:subnet_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_subnet(subnet_id):
    """Delete subnet and all its IP addresses"""
    try:
        subnet = Subnet.query.get_or_404(subnet_id)
        subnet_network = subnet.network  # Save for flash message
        
        # First delete all IP addresses in this subnet
        IPAddress.query.filter_by(subnet_id=subnet_id).delete()
        
        # Then delete the subnet itself
        db.session.delete(subnet)
        db.session.commit()
        
        flash(f'Podsieć {subnet_network} została usunięta wraz z wszystkimi adresami IP', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting subnet: {str(e)}")
        flash(f'Błąd podczas usuwania podsieci: {str(e)}', 'danger')
        
    return redirect(url_for('admin.ip_management'))

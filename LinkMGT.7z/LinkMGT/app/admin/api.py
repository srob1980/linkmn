from flask import Blueprint, jsonify, request
from flask_login import login_required
from app.auth.decorators import admin_required
from app.utils.system_monitor import SystemMonitor
from app.models.system_log import SystemLog
from datetime import datetime, timedelta

bp = Blueprint('admin_api', __name__, url_prefix='/api/admin')

@bp.route('/metrics/system')
@login_required
@admin_required
def system_metrics():
    """Get system metrics"""
    period = request.args.get('period', 'hour')
    metrics = SystemMonitor.get_historical_metrics(period)
    return jsonify(metrics)

@bp.route('/metrics/resources')
@login_required
@admin_required
def resource_metrics():
    """Get current resource usage"""
    metrics = SystemMonitor.get_system_metrics()
    return jsonify(metrics)

@bp.route('/logs/stats')
@login_required
@admin_required
def get_log_stats():
    """Get log statistics"""
    try:
        today = datetime.utcnow().date()
        stats = {
            'today': SystemLog.query.filter(SystemLog.timestamp >= today).count(),
            'errors': SystemLog.query.filter_by(level='ERROR').count(),
            'warnings': SystemLog.query.filter_by(level='WARNING').count()
        }
        return jsonify({'success': True, 'data': stats})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/system/info')
@login_required
@admin_required
def get_system_info():
    """Get detailed system information"""
    try:
        from app.utils.system import get_system_info
        info = get_system_info()
        return jsonify({'success': True, 'data': info})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/system/services')
@login_required
@admin_required
def get_services_status():
    """Get status of system services"""
    try:
        services = SystemMonitor.get_service_status()
        return jsonify({'success': True, 'data': services})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/monitor/processes')
@login_required
@admin_required
def get_processes():
    """Get list of running processes"""
    try:
        processes = SystemMonitor.get_process_metrics()
        return jsonify({'success': True, 'data': processes})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/monitor/disk')
@login_required
@admin_required
def get_disk_usage():
    """Get detailed disk usage information"""
    try:
        disk_info = SystemMonitor.get_disk_metrics()
        return jsonify({'success': True, 'data': disk_info})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/config/test_db', methods=['POST'])
@login_required
@admin_required
def test_database():
    """Test database connection with provided settings"""
    try:
        from app.utils.config_manager import ConfigManager
        result = ConfigManager.test_database_connection(request.get_json())
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@bp.route('/logs/system/export')
@login_required
@admin_required
def export_system_logs():
    """Export system logs"""
    format = request.args.get('format', 'csv')
    # Implementation for exporting logs
    pass

@bp.route('/logs/activity/export')
@login_required
@admin_required
def export_activity_logs():
    """Export activity logs"""
    format = request.args.get('format', 'csv')
    # Implementation for exporting logs
    pass

from flask import Blueprint, render_template

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/system-monitor', endpoint='system_monitor')
def system_monitor():
    # Your monitoring code here
    return render_template('admin/system_monitor.html')

# If there's another route that was conflicting, it should be removed or renamed
# For example, if you had this:
# @admin_bp.route('/monitor', endpoint='system_monitor_alt')
# def another_monitor():
#     # Your monitoring code here
#     return render_template('admin/another_monitor.html')
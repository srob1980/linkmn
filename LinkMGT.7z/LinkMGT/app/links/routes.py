from flask import render_template, redirect, url_for, flash, request, current_app, jsonify
from flask_login import login_required, current_user
from app import db
from app.links import bp
from app.links.forms import LinkForm  # Dodajemy import formularza
from app.models import Link, Category, Tag, Team, link_category, link_tag, user_team
from app.models.team import team_resource_share  # Add this import
from sqlalchemy import or_, inspect, text, select

@bp.route('/')
@login_required
def index():
    """View all links"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('ITEMS_PER_PAGE', 10)
    
    # Get query filters
    search = request.args.get('search', '')
    category_id = request.args.get('category', '')
    tag_id = request.args.get('tag', '')
    
    try:
        # Check if owner_team_id column exists before using it
        inspector = inspect(db.engine)
        columns = [c['name'] for c in inspector.get_columns('links')]
        has_owner_team_id = 'owner_team_id' in columns
        
        # Build query using only existing columns
        if has_owner_team_id:
            # Use all columns including owner_team_id
            query = db.session.query(Link).filter(Link.is_active == True)
        else:
            # Explicitly select only existing columns to avoid the error
            query = db.session.query(
                Link.id, Link.title, Link.url, Link.description, 
                Link.icon, Link.is_public, Link.is_active,
                Link.category_id, Link.creator_id, Link.created_at, Link.updated_at
            ).filter(Link.is_active == True)
            
        # Global admin widzi wszystko, zwykli użytkownicy widzą tylko swoje i publiczne
        if not current_user.is_global_admin:
            # Basic conditions (always use these)
            query = query.filter(or_(Link.is_public == True, Link.creator_id == current_user.id))
            
            # Add team-based access if columns exist
            if has_owner_team_id and 'link_team' in inspector.get_table_names():
                user_team_ids = [team.id for team in current_user.teams]
                if user_team_ids:
                    # Also include links from user's teams if team features are available
                    team_conditions = []
                    
                    # Owner team condition
                    team_conditions.append(Link.owner_team_id.in_(user_team_ids))
                    
                    # Shared with team condition via link_team association
                    team_conditions.append(Link.teams.any(Team.id.in_(user_team_ids)))
                    
                    # Team resource sharing if available
                    if 'team_resource_share' in inspector.get_table_names():
                        team_conditions.append(
                            Link.owner_team_id.in_(
                                db.session.query(team_resource_share.c.team_id).filter(
                                    team_resource_share.c.resource_team_id.in_(user_team_ids),
                                    team_resource_share.c.resource_type == 'links'
                                )
                            )
                        )
                    
                    # Add team conditions to the main query
                    query = query.filter(or_(Link.is_public == True, 
                                           Link.creator_id == current_user.id,
                                           *team_conditions))
        
        # Apply search filter if provided
        if search:
            query = query.filter(or_(
                Link.title.ilike(f'%{search}%'),
                Link.description.ilike(f'%{search}%'),
                Link.url.ilike(f'%{search}%')
            ))
        
        # Apply category filter if applicable
        if category_id and category_id.isdigit():
            category_id = int(category_id)
            if 'category_id' in columns:
                query = query.filter(Link.category_id == category_id)
            elif 'link_category' in inspector.get_table_names():
                query = query.join(link_category).filter(link_category.c.category_id == category_id)
        
        # Apply tag filter if applicable
        if tag_id and tag_id.isdigit():
            tag_id = int(tag_id)
            if 'link_tag' in inspector.get_table_names():
                query = query.join(link_tag).filter(link_tag.c.tag_id == tag_id)
        
        # Get paginated results
        links = query.order_by(Link.title).paginate(page=page, per_page=per_page)
        
    except Exception as e:
        current_app.logger.error(f"Error querying links: {str(e)}")
        db.session.rollback()
        
        # Fallback to a very simple query that won't use any potentially missing columns
        fallback_query = text("""
            SELECT id, title, url, description, icon, is_public, is_active, 
                   category_id, creator_id, created_at, updated_at 
            FROM links 
            WHERE is_active = true 
            ORDER BY title 
            LIMIT :limit OFFSET :offset
        """)
        
        result = db.session.execute(fallback_query, {'limit': per_page, 'offset': (page-1)*per_page})
        items = [dict(row) for row in result]
        
        # Create a simple pagination object
        from collections import namedtuple
        Pagination = namedtuple('Pagination', ['items', 'page', 'per_page', 'total', 'pages', 'has_next', 'has_prev', 'next_num', 'prev_num'])
        links = Pagination(
            items=items,
            page=page,
            per_page=per_page,
            total=len(items),  # This is not accurate but we have limited data
            pages=1,
            has_next=False,
            has_prev=page > 1,
            next_num=page + 1,
            prev_num=page - 1 if page > 1 else None
        )
    
    # Get categories and tags for filter dropdowns
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    tags = Tag.query.order_by(Tag.name).all()
    
    return render_template('links/index.html',
                          title='Wszystkie linki',
                          links=links,
                          categories=categories,
                          tags=tags,
                          search=search,
                          selected_category=category_id,
                          selected_tag=tag_id)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Tworzenie nowego linku"""
    form = LinkForm()
    
    # Pobierz kategorie i zespoły do list wyboru
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    
    # Only show teams where user is a member and can add content
    teams = []
    for team in current_user.teams:
        if team.can_user_manage_resources(current_user.id):
            teams.append(team)
    
    # Ustaw opcje wyboru dla pól SelectMultipleField przed walidacją
    form.categories.choices = [(c.id, c.name) for c in categories]
    form.teams.choices = [(t.id, t.name) for t in teams]
    
    if form.validate_on_submit():
        try:
            # Utwórz nowy link
            link = Link(
                title=form.title.data,
                url=form.url.data,
                description=form.description.data,
                icon=form.icon.data,
                is_public=form.is_public.data,
                is_active=True,
                creator_id=current_user.id
            )
            
            # Przypisz link do zespołu, jeśli wybrano
            selected_team_id = request.form.get('owner_team_id')
            if selected_team_id:
                # Sprawdź czy kolumna owner_team_id istnieje w tabeli links
                inspector = inspect(db.engine)
                columns = [c['name'] for c in inspector.get_columns('links')]
                if 'owner_team_id' in columns:
                    link.owner_team_id = int(selected_team_id)
            
            # Dodaj wybrane kategorie
            for category_id in form.categories.data:
                category = Category.query.get(category_id)
                if category:
                    link.categories.append(category)
            
            # Dodaj wybrane zespoły
            for team_id in form.teams.data:
                team = Team.query.get(team_id)
                if team:
                    link.teams.append(team)
            
            # Przetwórz tagi
            if form.tags.data:
                tag_names = [t.strip() for t in form.tags.data.split(',') if t.strip()]
                for tag_name in tag_names:
                    # Znajdź lub utwórz tag
                    tag = Tag.query.filter_by(name=tag_name).first()
                    if not tag:
                        tag = Tag(name=tag_name)
                        db.session.add(tag)
                    link.tags.append(tag)
            
            # Zapisz link
            db.session.add(link)
            db.session.commit()
            
            flash('Link został pomyślnie utworzony', 'success')
            return redirect(url_for('links.index'))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating link: {str(e)}")
            flash(f'Wystąpił błąd podczas tworzenia linku: {str(e)}', 'danger')
    
    return render_template('links/create.html',
                         title='Dodaj link',
                         form=form,
                         categories=categories,
                         teams=teams)

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    """Edycja istniejącego linku"""
    link = Link.query.get_or_404(id)
    
    # Global admin może edytować wszystkie linki
    if not current_user.is_global_admin:
        # Sprawdź uprawnienia - tylko właściciel lub admin może edytować
        if link.creator_id != current_user.id and not current_user.is_admin:
            flash('Nie masz uprawnień do edycji tego linku.', 'warning')
            return redirect(url_for('links.index'))
    
    form = LinkForm(obj=link)
    
    # Pobierz kategorie i zespoły do listy
    form.categories.choices = [(c.id, c.name) for c in Category.query.filter_by(is_active=True).order_by(Category.name).all()]
    form.teams.choices = [(t.id, t.name) for t in Team.query.filter_by(is_active=True).order_by(Team.name).all()]
    
    if request.method == 'GET':
        # Ustaw początkowe wartości formularza
        form.categories.data = [c.id for c in link.categories]
        form.teams.data = [t.id for t in link.teams]
        form.tags.data = ', '.join([t.name for t in link.tags])
    
    if form.validate_on_submit():
        # Aktualizuj link
        link.title = form.title.data
        link.url = form.url.data
        link.description = form.description.data
        link.is_public = form.is_public.data
        
        # Aktualizuj kategorie
        link.categories = []
        for category_id in form.categories.data:
            category = Category.query.get(category_id)
            if category:
                link.categories.append(category)
        
        # Aktualizuj zespoły
        link.teams = []
        for team_id in form.teams.data:
            team = Team.query.get(team_id)
            if team:
                link.teams.append(team)
        
        # Aktualizuj tagi
        link.tags = []
        if form.tags.data:
            tag_names = [t.strip() for t in form.tags.data.split(',') if t.strip()]
            for tag_name in tag_names:
                tag = Tag.query.filter_by(name=tag_name).first()
                if not tag:
                    tag = Tag(name=tag_name)
                    db.session.add(tag)
                link.tags.append(tag)
        
        # Zapisz zmiany
        db.session.commit()
        
        flash('Link został pomyślnie zaktualizowany.', 'success')
        return redirect(url_for('links.index'))
    
    return render_template('links/edit.html',
                         title='Edytuj link',
                         form=form,
                         link=link)

@bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    """Usunięcie linku"""
    link = Link.query.get_or_404(id)
    
    # Global admin może usuwać wszystkie linki
    if not current_user.is_global_admin:
        # Sprawdź uprawnienia - tylko właściciel lub admin może usunąć
        if link.creator_id != current_user.id and not current_user.is_admin:
            flash('Nie masz uprawnień do usunięcia tego linku.', 'warning')
            return redirect(url_for('links.index'))
    
    # Usuń link
    db.session.delete(link)
    db.session.commit()
    
    flash('Link został pomyślnie usunięty.', 'success')
    return redirect(url_for('links.index'))

@bp.route('/tags')
@login_required
def get_tags():
    """API do pobierania listy tagów (dla autocomplete)"""
    query = request.args.get('q', '')
    
    tags = []
    if query:
        tags = Tag.query.filter(Tag.name.ilike(f'{query}%')).limit(10).all()
    else:
        tags = Tag.query.limit(20).all()
    
    return jsonify([{'id': tag.id, 'name': tag.name} for tag in tags])

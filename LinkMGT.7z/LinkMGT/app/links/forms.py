from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, BooleanField, SubmitField, SelectMultipleField
from wtforms.validators import DataRequired, URL, Length, Optional
from flask_wtf.file import FileField, FileAllowed
from app.models import Category, Tag, Team

class LinkForm(FlaskForm):
    """Formularz do tworzenia i edycji linków"""
    title = StringField('Tytuł', validators=[DataRequired(), Length(max=100)])
    url = StringField('URL', validators=[DataRequired(), URL(), Length(max=500)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=500)])
    icon = StringField('Ikona (Font Awesome)', validators=[Optional(), Length(max=50)], default='link')
    is_public = BooleanField('Publiczny', default=True)
    
    # Pola dla relacji wiele-do-wielu - zostaną uzupełnione w widoku
    categories = SelectMultipleField('Kategorie', coerce=int, validators=[Optional()])
    teams = SelectMultipleField('Zespoły', coerce=int, validators=[Optional()])
    tags = StringField('Tagi (oddzielone przecinkami)', validators=[Optional(), Length(max=200)])
    
    submit = SubmitField('Zapisz')

class LinkFilterForm(FlaskForm):
    """Formularz do filtrowania linków"""
    q = StringField('Szukana fraza', validators=[Optional()])
    category = SelectMultipleField('Kategoria', coerce=int, validators=[Optional()])
    tag = StringField('Tag', validators=[Optional()])
    team = SelectMultipleField('Zespół', coerce=int, validators=[Optional()])
    submit = SubmitField('Filtruj')

class CategoryForm(FlaskForm):
    """Formularz do tworzenia i edycji kategorii"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=64)])
    description = TextAreaField('Opis', validators=[Optional(), Length(max=500)])
    parent_id = SelectMultipleField('Kategoria nadrzędna', coerce=int)
    color = StringField('Kolor', default='#2563eb', validators=[Length(max=7)])
    icon = StringField('Ikona', default='fas fa-folder', validators=[Length(max=50)])
    is_active = BooleanField('Aktywna', default=True)
    sort_order = StringField('Kolejność sortowania', default=0)
    submit = SubmitField('Zapisz')

class TagForm(FlaskForm):
    """Formularz do tworzenia i edycji tagów"""
    name = StringField('Nazwa', validators=[DataRequired(), Length(max=32)])
    color = StringField('Kolor', default='#64748b', validators=[Length(max=7)])
    submit = SubmitField('Zapisz')

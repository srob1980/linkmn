import os
import sys
import subprocess

# Dodaj ścieżkę projektu
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

def fix_missing_blueprints():
    """Napraw brakujące blueprinty"""
    
    # Utwórz brakujące foldery
    folders_to_create = [
        'app/forms',
        'app/routes',
    ]
    
    for folder in folders_to_create:
        folder_path = os.path.join(project_path, folder)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
            print(f"Utworzono folder: {folder}")
            
            # Utwórz __init__.py
            init_file = os.path.join(folder_path, '__init__.py')
            with open(init_file, 'w') as f:
                f.write('# Package initializer\n')

def main():
    """Napraw całą aplikację"""
    
    print("🔧 Naprawianie aplikacji LinkMGT...")
    
    # Napraw brakujące foldery
    fix_missing_blueprints()
    
    # Uruchom setup
    print("📦 Konfigurowanie bazy danych...")
    try:
        from setup_complete import setup_application
        if setup_application():
            print("✅ Aplikacja została naprawiona!")
            print("\n🚀 Możesz teraz uruchomić aplikację używając: python run.py")
        else:
            print("❌ Wystąpiły błędy podczas naprawy")
    except Exception as e:
        print(f"❌ Błąd: {e}")

if __name__ == '__main__':
    main()

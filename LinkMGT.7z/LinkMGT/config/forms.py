from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SubmitField, BooleanField, PasswordField, SelectField
from wtforms.validators import DataRequired, Length, URL, Optional, NumberRange

class ConfigForm(FlaskForm):
    key = StringField('Klucz', 
                     validators=[DataRequired(), Length(min=1, max=64)],
                     render_kw={'placeholder': 'CONFIG_KEY'})
    
    value = StringField('Wartość', 
                       validators=[DataRequired(), Length(max=256)],
                       render_kw={'placeholder': 'Wartość konfiguracji'})
    
    description = TextAreaField('Opis', 
                               validators=[Optional(), Length(max=500)],
                               render_kw={'placeholder': 'Opis konfiguracji', 'rows': 3})
    
    is_sensitive = BooleanField('Poufne dane', 
                               default=False,
                               description='Czy wartość zawiera wrażliwe dane (hasła, klucze)')
    
    submit = SubmitField('Zapisz')

class ADConfigForm(FlaskForm):
    ad_enabled = BooleanField('Włącz uwierzytelnianie Active Directory',
                             default=False,
                             description='Włącz logowanie przez Active Directory')
    
    ad_server = StringField('Serwer AD',
                           validators=[Optional()],
                           render_kw={'placeholder': 'ldap://your-ad-server.com'})
    
    ad_domain = StringField('Domena',
                           validators=[Optional()],
                           render_kw={'placeholder': 'yourdomain.com'})
    
    ad_base_dn = StringField('Base DN',
                            validators=[Optional()],
                            render_kw={'placeholder': 'DC=yourdomain,DC=com'})
    
    ad_username = StringField('Nazwa użytkownika',
                             validators=[Optional()],
                             render_kw={'placeholder': 'service-account'})
    
    ad_password = PasswordField('Hasło',
                               validators=[Optional()],
                               render_kw={'placeholder': 'Zostaw puste aby nie zmieniać'})
    
    ad_fallback = BooleanField('Fallback do lokalnego uwierzytelniania',
                              default=True,
                              description='Pozwól na logowanie lokalne jeśli AD nie działa')
    
    test_connection = SubmitField('Testuj połączenie')
    submit = SubmitField('Zapisz konfigurację')

class SSLConfigForm(FlaskForm):
    enabled = BooleanField('Włącz SSL/TLS')
    cert_file = FileField('Certyfikat', validators=[
        Optional(),
        FileAllowed(['crt', 'pem'], 'Tylko pliki .crt lub .pem!')
    ])
    key_file = FileField('Klucz prywatny', validators=[
        Optional(),
        FileAllowed(['key'], 'Tylko pliki .key!')
    ])

class SSOConfigForm(FlaskForm):
    sso_enabled = BooleanField('Włącz Single Sign-On',
                              default=False,
                              description='Włącz uwierzytelnianie SSO')
    
    provider = SelectField('Dostawca SSO', choices=[
        ('azure', 'Azure AD'),
        ('google', 'Google Workspace'),
        ('okta', 'Okta'),
        ('saml', 'SAML 2.0')
    ], default='azure')
    
    client_id = StringField('Client ID',
                           validators=[Optional()],
                           render_kw={'placeholder': 'Client ID aplikacji'})
    
    client_secret = PasswordField('Client Secret',
                                 validators=[Optional()],
                                 render_kw={'placeholder': 'Client Secret aplikacji'})
    
    tenant_id = StringField('Tenant ID',
                           validators=[Optional()],
                           render_kw={'placeholder': 'Tenant ID (dla Azure)'})

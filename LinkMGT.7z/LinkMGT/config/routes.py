from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.config import bp
from app import db
from app.models import AppConfig
from app.auth.decorators import admin_required
from app.config.forms import ConfigForm, ADConfigForm

@bp.route('/')
@login_required
@admin_required
def index():
    """Panel ustawień - strona główna"""
    
    configs = AppConfig.query.order_by(AppConfig.key).all()
    
    return render_template('config/index.html',
                          title='Konfiguracja systemu',
                          configs=configs)

@bp.route('/edit/<int:config_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit(config_id):
    """Edycja konfiguracji"""
    
    config = AppConfig.query.get_or_404(config_id)
    form = ConfigForm()
    
    if request.method == 'GET':
        form.key.data = config.key
        form.value.data = config.value
        form.description.data = config.description
        form.is_sensitive.data = config.is_sensitive
    
    if form.validate_on_submit():
        try:
            config.key = form.key.data
            config.value = form.value.data
            config.description = form.description.data
            config.is_sensitive = form.is_sensitive.data
            
            db.session.commit()
            
            flash(f'Konfiguracja "{config.key}" została zaktualizowana.', 'success')
            return redirect(url_for('config.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Błąd podczas aktualizacji: {str(e)}', 'danger')
    
    return render_template('config/edit.html',
                          title='Edytuj konfigurację',
                          form=form,
                          config=config)

@bp.route('/ad_config', methods=['GET', 'POST'])
@login_required
@admin_required
def ad_config():
    """Konfiguracja Active Directory"""
    
    form = ADConfigForm()
    
    if request.method == 'GET':
        # Załaduj obecne ustawienia AD
        form.ad_enabled.data = AppConfig.get_value('AUTH_USE_AD', 'False').lower() == 'true'
        form.ad_server.data = AppConfig.get_value('AD_SERVER', '')
        form.ad_domain.data = AppConfig.get_value('AD_DOMAIN', '')
        form.ad_base_dn.data = AppConfig.get_value('AD_BASE_DN', '')
        form.ad_username.data = AppConfig.get_value('AD_USERNAME', '')
        form.ad_fallback.data = AppConfig.get_value('AUTH_AD_FALLBACK', 'True').lower() == 'true'
    
    if form.validate_on_submit():
        try:
            # Zapisz ustawienia AD
            AppConfig.set_value('AUTH_USE_AD', 'True' if form.ad_enabled.data else 'False', 'Włącz uwierzytelnianie AD')
            AppConfig.set_value('AD_SERVER', form.ad_server.data, 'Serwer Active Directory')
            AppConfig.set_value('AD_DOMAIN', form.ad_domain.data, 'Domena Active Directory')
            AppConfig.set_value('AD_BASE_DN', form.ad_base_dn.data, 'Base DN dla Active Directory')
            AppConfig.set_value('AD_USERNAME', form.ad_username.data, 'Nazwa użytkownika dla połączenia z AD')
            AppConfig.set_value('AUTH_AD_FALLBACK', 'True' if form.ad_fallback.data else 'False', 'Fallback do lokalnego uwierzytelniania')
            
            if form.ad_password.data:
                AppConfig.set_value('AD_PASSWORD', form.ad_password.data, 'Hasło dla połączenia z AD', is_sensitive=True)
            
            flash('Konfiguracja Active Directory została zapisana.', 'success')
            return redirect(url_for('config.ad_config'))
            
        except Exception as e:
            flash(f'Błąd podczas zapisywania konfiguracji AD: {str(e)}', 'danger')
    
    return render_template('config/ad_config.html',
                          title='Konfiguracja Active Directory',
                          form=form)

@bp.route('/test_ad', methods=['POST'])
@login_required
@admin_required
def test_ad():
    """Testuj połączenie z Active Directory"""
    
    try:
        from app.auth.ad_auth import test_ad_connection
        
        server = request.json.get('server')
        domain = request.json.get('domain')
        username = request.json.get('username')
        password = request.json.get('password')
        
        success, message = test_ad_connection(server, domain, username, password)
        
        return jsonify({
            'success': success,
            'message': message
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Błąd podczas testowania połączenia: {str(e)}'
        })

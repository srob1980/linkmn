from datetime import timedelta
import os
from dotenv import load_dotenv
from flask import Blueprint

# Load environment variables from .env file
load_dotenv()

bp = Blueprint('config', __name__)

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-key-change-in-production')
    
    # Database Configuration
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost/linkmgt')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Flask Configuration
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() in ('true', '1', 't')
    HOST = os.environ.get('FLASK_HOST', '127.0.0.1')
    PORT = int(os.environ.get('FLASK_PORT', 5000))
    
    # AD Configuration
    AD_SERVER = os.environ.get('AD_SERVER', 'ldap://your-ad-server.com')
    AD_DOMAIN = os.environ.get('AD_DOMAIN', 'yourdomain.com')
    AD_BASE_DN = os.environ.get('AD_BASE_DN', 'DC=yourdomain,DC=com')
    
    # SSL Configuration
    USE_SSL = os.environ.get('USE_SSL', 'False').lower() in ('true', '1', 't')
    SSL_CERT = os.environ.get('SSL_CERT', 'cert.pem')
    SSL_KEY = os.environ.get('SSL_KEY', 'key.pem')
    
    # Session Configuration
    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)

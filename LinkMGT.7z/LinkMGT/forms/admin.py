from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField, IntegerField
from wtforms.validators import DataRequired, NumberRange, Optional

class NetworkConfigForm(FlaskForm):
    http_port = IntegerField('Port HTTP', 
                            validators=[DataRequired(), NumberRange(min=1, max=65535)],
                            default=5000)
    https_enabled = BooleanField('Włącz HTTPS')
    https_port = IntegerField('Port HTTPS', 
                             validators=[NumberRange(min=1, max=65535), Optional()],
                             default=5443)
    ssl_cert_path = StringField('Ścieżka do certyfikatu SSL',
                               default='certificate/cert.pem')
    ssl_key_path = StringField('Ścieżka do klucza SSL',
                              default='certificate/key.pem')
    submit = SubmitField('Zapisz ustawienia')
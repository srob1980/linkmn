import os
import sys

# Dodaj ścieżkę projektu do PYTHONPATH
project_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_path)

from app import create_app, db
from sqlalchemy import text

def add_is_public_column():
    """Dodaj kolumnę is_public do tabeli links"""
    
    app = create_app()
    
    with app.app_context():
        try:
            print("🔧 Sprawdzanie kolumny is_public w tabeli links...")
            
            # Sprawdź czy kolumna is_public istnieje
            result = db.session.execute(text("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = 'links' 
                AND table_schema = 'public'
                AND column_name = 'is_public'
            """))
            
            if not result.fetchone():
                print("Dodaję kolumnę is_public...")
                db.session.execute(text("ALTER TABLE links ADD COLUMN is_public BOOLEAN DEFAULT FALSE"))
                
                # Dodaj indeks
                db.session.execute(text("CREATE INDEX idx_links_is_public ON links(is_public)"))
                
                # Zaktualizuj istniejące linki na publiczne dla przykładu
                db.session.execute(text("UPDATE links SET is_public = TRUE WHERE creator_id = 1"))
                
                db.session.commit()
                print("✅ Kolumna is_public została dodana!")
            else:
                print("✅ Kolumna is_public już istnieje!")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Błąd: {e}")
            return False
        
        return True

if __name__ == '__main__':
    add_is_public_column()
